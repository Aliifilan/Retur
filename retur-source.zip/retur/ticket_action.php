<?php
declare(strict_types=1);

/* Tindakan tiket kendala (POST) — pola POST → Redirect → GET. */

require_once __DIR__ . '/includes/init.php';
ret_require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('tickets.php');
}
csrf_verify();

$do = (string)post('do');
$id = (int)post('id', 0);
$t = ret_ticket_find($id);
if (!$t) {
    flash('Tiket tidak ditemukan.', 'error');
    redirect('tickets.php');
}

$u = current_user();
$uid = $u ? (int)$u['id'] : null;

switch ($do) {
    case 'reply':
        ret_require('edit', 'mengubah status tiket');
        $res = ret_ticket_reply($id, (string)post('status', 'open'), (string)post('message'), $uid);
        if (empty($res['ok'])) {
            flash(e(implode(' ', (array)$res['errors'])), 'error');
        } else {
            flash('Riwayat tiket tersimpan — status sekarang: <strong>'
                . e(ret_ticket_status_label((string)post('status', 'open'))) . '</strong>.');
        }
        redirect('ticket_view.php?id=' . $id);

    case 'delete':
        ret_require('void', 'menghapus tiket');
        $res = ret_ticket_delete($id);
        if (empty($res['ok'])) {
            flash(e(implode(' ', (array)$res['errors'])), 'error');
            redirect('ticket_view.php?id=' . $id);
        }
        flash('Tiket <strong>' . e((string)$t['subject']) . '</strong> dihapus.');
        redirect('tickets.php');

    default:
        flash('Tindakan tidak dikenal.', 'error');
        redirect('tickets.php');
}
