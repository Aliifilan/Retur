<?php
declare(strict_types=1);

/* ============================================================
 * Daftar seluruh retur + filter (marketplace, status, periode, pencarian bebas).
 * ============================================================ */

require_once __DIR__ . '/includes/init.php';
ret_require_login();

$filter = [
    'q' => (string)get('q', ''),
    'marketplace' => (string)get('marketplace', ''),
    'status' => (string)get('status', ''),
    'from' => ret_date_input((string)get('from', '')) ?: '',
    'to' => ret_date_input((string)get('to', '')) ?: '',
    'inv_problem' => (int)get('inv_problem', 0) === 1,
];
if (!isset(ret_markets()[$filter['marketplace']])) $filter['marketplace'] = '';
if (!in_array($filter['status'], ['pending', 'received', ''], true)) $filter['status'] = '';

$data = ret_list($filter, 25);
$rows = $data['rows'];
$itemsMap = $data['items'];
$activeFilter = $filter['q'] !== '' || $filter['marketplace'] !== '' || $filter['status'] !== ''
    || $filter['from'] !== '' || $filter['to'] !== '' || $filter['inv_problem'];

$query = http_build_query(array_filter([
    'q' => $filter['q'], 'marketplace' => $filter['marketplace'], 'status' => $filter['status'],
    'from' => $filter['from'], 'to' => $filter['to'], 'inv_problem' => $filter['inv_problem'] ? 1 : '',
], static fn($v) => $v !== '' && $v !== 0));
$actions = '<a class="btn" href="export.php?type=retur' . ($query !== '' ? '&amp;' . e($query) : '') . '">Export Excel</a>'
    . (ret_can('create') ? ' <a class="btn btn-primary" href="form.php">+ Catat Retur</a>' : '');

ret_page_start('Daftar Retur', 'returns.php', [
    'label'   => 'returns',
    'sub'     => 'Semua retur marketplace yang tercatat — ' . fmt_num($data['total']) . ' data sesuai filter.',
    'actions' => $actions,
]);
?>

<form class="card filter-card" method="get" action="returns.php">
  <label class="field">
    <span>Cari</span>
    <input type="text" name="q" value="<?= e($filter['q']) ?>" placeholder="Resi / pesanan / artikel / pembeli" autocomplete="off">
  </label>
  <label class="field">
    <span>Marketplace</span>
    <select name="marketplace">
      <option value="">Semua</option>
      <?php foreach (ret_markets() as $code => $label): ?>
        <option value="<?= e($code) ?>" <?= $filter['marketplace'] === $code ? 'selected' : '' ?>><?= e($label) ?></option>
      <?php endforeach; ?>
    </select>
  </label>
  <label class="field">
    <span>Status</span>
    <select name="status">
      <option value="">Semua</option>
      <option value="pending" <?= $filter['status'] === 'pending' ? 'selected' : '' ?>>Belum diterima</option>
      <option value="received" <?= $filter['status'] === 'received' ? 'selected' : '' ?>>Sudah diterima</option>
    </select>
  </label>
  <label class="field">
    <span>Terbit dari</span>
    <input type="date" name="from" value="<?= e($filter['from']) ?>">
  </label>
  <label class="field">
    <span>Sampai</span>
    <input type="date" name="to" value="<?= e($filter['to']) ?>">
  </label>
  <div class="filter-actions">
    <button class="btn btn-primary" type="submit">Terapkan</button>
    <?php if ($activeFilter): ?>
      <a class="btn" href="returns.php">Bersihkan</a>
    <?php endif; ?>
  </div>
</form>

<?php if ($filter['inv_problem']): ?>
  <?= ret_notice('Menampilkan hanya retur yang <strong>stoknya gagal masuk Inventory</strong>. '
      . 'Buka catatannya lalu pakai tombol <em>Kirim ulang ke Inventory</em>.', 'warn') ?>
<?php endif; ?>

<section class="card">
  <?php if (!$rows): ?>
    <p class="muted">
      <?= $activeFilter ? 'Tidak ada retur yang cocok dengan filter ini.' : 'Belum ada retur yang tercatat.' ?>
      <?php if (ret_can('create')): ?> Mulai dengan <a href="form.php">mencatat retur baru</a>.<?php endif; ?>
    </p>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table table-rows">
        <thead>
          <tr>
            <th>Terbit</th>
            <th>Diterima</th>
            <th>Umur</th>
            <th>Marketplace</th>
            <th>Resi</th>
            <th>Artikel</th>
            <th>Pembeli</th>
            <th>Stok</th>
            <th class="act-col">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rows as $r): ?>
            <?php
            $id = (int)$r['id'];
            $its = $itemsMap[$id] ?? [];
            $received = (string)$r['status'] === 'received';
            /* Umur = lama menunggu: untuk yang belum diterima dihitung sampai hari ini,
               untuk yang sudah diterima dihitung sampai tanggal diterimanya. */
            $age = ret_age_days(
                (string)$r['issued_date'],
                $received && (string)$r['received_date'] !== '' ? (string)$r['received_date'] : null
            );
            ?>
            <tr>
              <td><?= e(fmt_date((string)$r['issued_date'])) ?></td>
              <td><?= $received ? e(fmt_date((string)$r['received_date'])) : '<span class="muted">—</span>' ?></td>
              <td><span class="age <?= e(ret_age_class($age)) ?>" title="Lama menunggu"><?= e(ret_age_text($age)) ?></span></td>
              <td><?php if ((int)($r['manual'] ?? 0) === 1): ?>
                <span class="badge badge-muted" title="Retur manual (bukan dari marketplace)">Manual</span>
              <?php else: ?><?= ret_market_badge((string)$r['marketplace']) ?><?php endif; ?></td>
              <td>
                <a class="sku" href="view.php?id=<?= $id ?>"><?= e((string)$r['resi']) ?></a>
                <?php if ((string)$r['order_no'] !== ''): ?>
                  <div class="muted tiny"><?= e((string)$r['order_no']) ?></div>
                <?php endif; ?>
              </td>
              <td><?= ret_items_summary($its) ?></td>
              <td><?= (string)$r['buyer'] !== '' ? e((string)$r['buyer']) : '<span class="muted">—</span>' ?></td>
              <td><?= ret_inv_badge($r) ?></td>
              <td class="act-cell">
                <a class="btn btn-sm" href="view.php?id=<?= $id ?>">Buka</a>
                <?php if (!$received && ret_can('receive')): ?>
                  <form method="post" action="action.php" class="inline-form">
                    <?= csrf_field() ?>
                    <input type="hidden" name="do" value="receive">
                    <input type="hidden" name="id" value="<?= $id ?>">
                    <input type="hidden" name="back" value="returns.php">
                    <button class="btn btn-sm btn-primary" type="submit"
                            title="Isi tanggal diterima hari ini &amp; masukkan artikel bertanda ke stok"
                            data-confirm="<?= e(ret_quick_receive_confirm($r, $its)) ?>">Terima</button>
                  </form>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?= render_pager($data['pager']) ?>
  <?php endif; ?>
</section>

<?php ret_page_end(); ?>
