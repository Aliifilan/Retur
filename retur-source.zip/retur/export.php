<?php
declare(strict_types=1);

/* ============================================================
 * Export data retur marketplace ke Excel (.xlsx).
 *
 * Jenis berkas:
 *   retur     → daftar retur (satu baris per artikel), mengikuti filter di halaman daftar
 *   rekap     → 3 sheet: Ringkasan, Per Artikel (dengan pembeli), Per Pembeli
 *   template  → template import kosong + satu contoh baris
 *
 * Penulis Excel memakai milik aplikasi Inventory (includes/xlsx.php) supaya format kedua
 * aplikasi sama: judul kolom tebal, baris judul dibekukan, angka tetap angka.
 * Semua export hanya MEMBACA data.
 * ============================================================ */

require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/retur_import.php';
ret_require_login();

/** Filter dari query string (sama bentuknya dengan halaman daftar retur). */
function ret_export_filter(): array
{
    $f = [
        'q' => (string)get('q', ''),
        'marketplace' => (string)get('marketplace', ''),
        'status' => (string)get('status', ''),
        'from' => ret_date_input((string)get('from', '')) ?: '',
        'to' => ret_date_input((string)get('to', '')) ?: '',
        'inv_problem' => (int)get('inv_problem', 0) === 1,
    ];
    if (!isset(ret_markets()[$f['marketplace']])) $f['marketplace'] = '';
    if (!in_array($f['status'], ['pending', 'received', ''], true)) $f['status'] = '';
    return $f;
}

/** Keterangan filter untuk ditulis di baris atas berkas (supaya berkas tidak menyesatkan). */
function ret_export_filter_note(array $f): string
{
    $parts = [];
    if ($f['q'] !== '') $parts[] = 'pencarian "' . $f['q'] . '"';
    if ($f['marketplace'] !== '') $parts[] = 'marketplace ' . ret_market_label($f['marketplace']);
    if ($f['status'] !== '') $parts[] = 'status ' . ($f['status'] === 'received' ? 'sudah diterima' : 'belum diterima');
    if ($f['from'] !== '') $parts[] = 'terbit dari ' . fmt_date($f['from']);
    if ($f['to'] !== '') $parts[] = 'sampai ' . fmt_date($f['to']);
    if ($f['inv_problem']) $parts[] = 'hanya yang stoknya gagal masuk Inventory';
    return $parts ? ('Filter: ' . implode(', ', $parts)) : 'Semua data (tanpa filter)';
}

$type = (string)get('type', '');
if ($type !== '') {
    $f = ret_export_filter();
    $stamp = date('Ymd');

    if ($type === 'template') {
        xlsx_send_multi('template-import-retur-' . $stamp, [[
            'name' => 'Retur',
            'header' => ret_import_template_header(),
            'rows' => [ret_import_template_sample()],
        ]]);
        exit;
    }

    if ($type === 'retur') {
        $rows = ret_export_rows($f);
        $header = ['Resi', 'Sumber', 'Marketplace', 'Tanggal Terbit', 'Klaim Diterima (marketplace)',
                   'Tanggal Diterima Gudang', 'Selisih (hari)', 'Umur (hari)', 'Status',
                   'Pembeli', 'No. Pesanan', 'Kurir', 'Alasan', 'Artikel / SKU', 'Jumlah', 'Kondisi',
                   'Masuk Stok', 'Stok Inventory', 'Tukar Size', 'Catatan'];
        $data = [];
        $data[] = $header;
        foreach ($rows as $r) {
            $data[] = [
                (string)$r['resi'], (string)$r['sumber'], (string)$r['marketplace'], (string)$r['tanggal_terbit'],
                (string)$r['klaim_diterima'], (string)$r['tanggal_diterima'], $r['selisih_hari'],
                (int)$r['umur_hari'], (string)$r['status'], (string)$r['pembeli'], (string)$r['no_pesanan'],
                (string)$r['kurir'], (string)$r['alasan'], (string)$r['sku'], (float)$r['qty'],
                (string)$r['kondisi'], (string)$r['masuk_stok'], (string)$r['stok'],
                (string)$r['tukar'], (string)$r['catatan'],
            ];
        }
        if (!$rows) $data[] = ['(tidak ada data sesuai filter)'];
        $data[] = [];
        $data[] = ['Jumlah catatan retur', count(array_unique(array_column($rows, 'resi')))];
        $data[] = ['Jumlah baris artikel', count($rows)];
        $data[] = ['Catatan', ret_export_filter_note($f) . ' — dicetak ' . fmt_dt(now()) . ' oleh ' . (string)(current_user()['name'] ?? '')];

        $blob = xlsx_build_multi([['name' => 'Daftar Retur', 'rows' => $data]]);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . xlsx_filename('daftar-retur-' . $stamp) . '"');
        header('Content-Length: ' . strlen($blob));
        header('Cache-Control: no-store');
        echo $blob;
        exit;
    }

    if ($type === 'rekap') {
        $stats = ret_stats($f);
        $markets = ret_market_stats($f);
        $skus = ret_top_sku($f, 50);
        $buyers = ret_top_buyer($f, 50);
        $note = 'Periode: ' . ret_export_filter_note($f) . ' — dicetak ' . fmt_dt(now());

        $ringkasan = [
            [$note],
            [],
            ['Ringkasan', 'Jumlah'],
            ['Total retur', $stats['total']],
            ['Sudah diterima', $stats['received']],
            ['Belum diterima', $stats['pending']],
            ['Total artikel', $stats['qty']],
            ['Artikel tidak layak jual (rusak/kurang)', $stats['bad_qty']],
            ['Tunggakan seluruh periode', $stats['pending_all']],
            ['Umur tunggakan tertua (hari)', $stats['oldest_days']],
            [],
            ['Marketplace', 'Retur', 'Diterima', 'Belum diterima', 'Artikel'],
        ];
        foreach ($markets as $m) {
            $ringkasan[] = [$m['label'], $m['total'], $m['received'], $m['pending'], $m['qty']];
        }

        $perArtikel = [['Artikel / SKU', 'Jumlah retur', 'Jumlah artikel', 'Rusak/kurang', 'Pembeli yang meretur']];
        foreach ($skus as $s) {
            $perArtikel[] = [
                (string)$s['sku'],
                (int)$s['docs'],
                (float)$s['qty'],
                (int)$s['bad'],
                implode('; ', array_map(static fn($b) => $b['buyer'] . ' (' . $b['docs'] . '×)', $s['buyers'] ?? [])),
            ];
        }
        if (count($perArtikel) === 1) $perArtikel[] = ['(tidak ada data sesuai filter)'];

        $perPembeli = [['Pembeli', 'Jumlah retur', 'Jumlah artikel', 'Artikel berbeda', 'Rusak/kurang', 'Retur terakhir']];
        foreach ($buyers as $b) {
            $perPembeli[] = [
                (string)$b['buyer'], (int)$b['docs'], (float)$b['qty'], (int)$b['skus'],
                (int)$b['bad'], (string)$b['last_date'],
            ];
        }
        if (count($perPembeli) === 1) $perPembeli[] = ['(tidak ada data sesuai filter)'];

        /* Tiket kendala (periode yang sama dengan rekap) */
        $tickets = ret_ticket_list($f, 500);
        $perTiket = [['Dibuat', 'Marketplace', 'No. Tiket', 'Jenis', 'Judul', 'Status', 'Tenggat', 'Nilai', 'Pembeli', 'Pesanan']];
        foreach ($tickets['rows'] as $t) {
            $perTiket[] = [
                (string)$t['opened_date'], ret_market_label((string)$t['marketplace']),
                (string)$t['ticket_no'], ret_ticket_category_label((string)$t['category']),
                (string)$t['subject'], ret_ticket_status_label((string)$t['status']),
                (string)$t['due_date'], (float)$t['refund_amount'],
                (string)$t['buyer'], (string)$t['order_no'],
            ];
        }
        if (count($perTiket) === 1) $perTiket[] = ['(tidak ada tiket)'];

        /* Retur manual (termasuk tukar size) */
        $manuals = ret_export_rows(array_merge($f, ['source' => 'manual']));
        $perManual = [['Resi', 'Tanggal kejadian', 'Jenis', 'Pihak terkait', 'Artikel', 'Jumlah', 'Kondisi',
                       'Tukar Size', 'Diterima Gudang', 'Stok Inventory', 'Catatan']];
        foreach ($manuals as $m) {
            $perManual[] = [
                (string)$m['resi'], (string)$m['tanggal_terbit'], (string)$m['alasan'], (string)$m['pembeli'],
                (string)$m['sku'], (float)$m['qty'], (string)$m['kondisi'],
                (string)$m['tukar'], (string)$m['tanggal_diterima'], (string)$m['stok'], (string)$m['catatan'],
            ];
        }
        if (count($perManual) === 1) $perManual[] = ['(tidak ada retur manual)'];

        $blob = xlsx_build_multi([
            ['name' => 'Ringkasan', 'rows' => $ringkasan],
            ['name' => 'Per Artikel', 'rows' => $perArtikel],
            ['name' => 'Per Pembeli', 'rows' => $perPembeli],
            ['name' => 'Tiket Kendala', 'rows' => $perTiket],
            ['name' => 'Retur Manual', 'rows' => $perManual],
        ]);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . xlsx_filename('rekap-retur-' . $stamp) . '"');
        header('Content-Length: ' . strlen($blob));
        header('Cache-Control: no-store');
        echo $blob;
        exit;
    }

    http_response_code(400);
    exit('Jenis export tidak dikenal.');
}

/* ---------------- halaman ---------------- */

$f = ret_export_filter();
$note = ret_export_filter_note($f);
$q = http_build_query(array_filter([
    'q' => $f['q'], 'marketplace' => $f['marketplace'], 'status' => $f['status'],
    'from' => $f['from'], 'to' => $f['to'], 'inv_problem' => $f['inv_problem'] ? 1 : '',
], static fn($v) => $v !== '' && $v !== 0));
$suffix = $q !== '' ? '&' . $q : '';
$stats = ret_stats($f);

$actions = '<a class="btn" href="returns.php' . ($q !== '' ? '?' . $q : '') . '">← Kembali ke daftar</a>';

ret_page_start('Export & Import', '', [
    'label'   => 'data',
    'sub'     => 'Unduh data retur ke Excel, atau masukkan riwayat retur dari file Excel (bisa uji coba dulu tanpa menyimpan).',
    'actions' => $actions,
]);
?>

<section class="card">
  <div class="card-head">
    <h2>Export ke Excel (.xlsx)</h2>
    <span class="muted small"><?= e($note) ?></span>
  </div>
  <p class="muted small">
    Filter export mengikuti filter yang sedang aktif di halaman daftar retur
    (<?= fmt_num($stats['total']) ?> data sesuai filter saat ini). Ingin semua data? Bersihkan filter di halaman daftar.
  </p>
  <div class="tag-list">
    <a class="btn btn-primary" href="export.php?type=retur<?= e($suffix) ?>">Daftar retur (per artikel)</a>
    <a class="btn" href="export.php?type=rekap<?= e($suffix) ?>">Rekap: ringkasan + per artikel + per pembeli</a>
    <a class="btn" href="export.php?type=template">Template import (kosong)</a>
  </div>
  <p class="muted small">
    Berkas berformat <strong>Excel .xlsx asli</strong> (bukan CSV bernama xlsx): judul kolom tebal &amp; dibekukan,
    angka tetap terbaca sebagai angka, dan kolom tanggal berformat tanggal.
  </p>
</section>

<?php if (ret_can('create')): ?>
<section class="card" id="import">
  <div class="card-head"><h2>Import dari Excel / CSV</h2></div>
  <p>
    Satu baris berkas = satu <strong>artikel</strong>. Baris dengan <strong>nomor resi yang sama digabung</strong>
    menjadi satu catatan retur. Nomor resi yang sudah ada di aplikasi dilewati seluruhnya, jadi mengimpor berkas
    yang sama dua kali tidak membuat data ganda.
  </p>
  <ul class="muted small">
    <li>Kolom wajib: <?= implode(', ', array_map(static fn($c) => '<code>' . e($c) . '</code>', ret_import_required())) ?>
      — pembeli wajib diisi.</li>
    <li>Kolom lain: marketplace, tanggal_terbit, tanggal_diterima, no_pesanan, kurir, alasan, kondisi
      (Bagus / Barang ditukar / Rusak / Kurang lengkap), masuk_stok (Ya/Tidak), catatan.</li>
    <li><strong>Tanggal diterima yang terisi</strong> berarti retur sudah diterima — saat import sebenarnya,
      stok artikel bertanda <em>Masuk stok</em> langsung ditambahkan ke aplikasi Inventory.</li>
    <li><strong>Pengaman stok ganda:</strong> bila nomor resi itu sudah pernah tercatat sebagai dokumen retur
      di aplikasi Inventory, stoknya <em>tidak</em> ditambahkan lagi (hanya dicatat di sini) — supaya barang yang
      sama tidak menambah stok dua kali. Isi kolom <code>masuk_stok</code> = Tidak bila Anda ingin memastikan sendiri.</li>
    <li>Unduh <a href="export.php?type=template">template import</a> untuk contoh format yang pasti terbaca.</li>
  </ul>

  <form class="row-form" method="post" action="import.php" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <label class="field field-grow">
      <span>Berkas retur (.xlsx, .csv, .txt)</span>
      <input type="file" name="file" accept=".xlsx,.csv,.txt" required>
    </label>
    <label class="chk">
      <input type="checkbox" name="dry_run" value="1" checked>
      <span>Mode uji coba (tidak menyimpan &amp; tidak menyentuh stok)</span>
    </label>
    <button class="btn btn-primary" type="submit">Proses berkas</button>
  </form>
</section>
<?php else: ?>
  <section class="card">
    <p class="muted">Peran akun Anda hanya boleh <strong>mengunduh</strong> data. Minta Admin bila perlu memasukkan
      data dari berkas Excel.</p>
  </section>
<?php endif; ?>

<?php ret_page_end(); ?>
