<?php
declare(strict_types=1);

/* ============================================================
 * Tindakan (POST) atas catatan retur — pola POST → Redirect → GET.
 *
 * Semua tindakan mengembalikan pesan lewat flash() supaya halaman yang dituju selalu
 * bisa dimuat ulang tanpa mengirim ulang POST (menghindari dobel aksi).
 * ============================================================ */

require_once __DIR__ . '/includes/init.php';
ret_require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('index.php');
}
csrf_verify();

$do = (string)post('do');
$id = (int)post('id', 0);

/** Halaman tujuan setelah aksi (hanya halaman yang dikenal, supaya tidak bisa dialihkan ke luar). */
$back = (string)post('back', 'returns.php');
if (!in_array($back, ['index.php', 'returns.php', 'view.php'], true)) $back = 'returns.php';
$target = $back === 'view.php' && $id > 0 ? 'view.php?id=' . $id : $back;

$row = ret_find($id);
if (!$row) {
    flash('Catatan retur tidak ditemukan.', 'error');
    redirect($back);
}

$u = current_user();
$uid = $u ? (int)$u['id'] : null;

switch ($do) {
    case 'receive':
        ret_require('receive', 'menandai retur diterima');
        /* Pilihan per artikel (kondisi & masuk stok) diputuskan di halaman rincian saat
           paket benar-benar sampai gudang — sebelum tanggal diterima diisi. */
        $stocks = (array)post('item_stock', []);
        $conds = (array)post('item_cond', []);
        if ($stocks || $conds) {
            $set = ret_set_item_choices($id, $stocks, $conds);
            if (empty($set['ok'])) {
                flash(e(implode(' ', (array)$set['errors'])), 'error');
                break;
            }
        }

        $tanggal = (string)post('date') !== '' ? (string)post('date') : today();
        $res = ret_receive($id, $tanggal, $uid);
        if (empty($res['ok'])) {
            flash(e(implode(' ', (array)$res['errors'])), 'error');
            break;
        }

        /* Apa saja yang benar-benar masuk stok — dihitung dari pilihan yang tersimpan. */
        $masuk = [];
        foreach (ret_items($id) as $it) {
            if ((int)$it['to_stock'] === 1) $masuk[] = (string)$it['sku'] . ' ×' . fmt_qty($it['qty']);
        }

        $push = $res['push'] ?? null;
        $awal = 'Retur <strong>' . e((string)$row['resi']) . '</strong> ditandai DITERIMA ' . e(fmt_date($tanggal)) . '.';
        if (is_array($push) && !empty($push['ok']) && ($push['state'] ?? '') === RET_INV_POSTED) {
            flash($awal . ' ' . count($masuk) . ' artikel masuk stok Inventory ('
                . e(implode(', ', $masuk)) . ') — dokumen <strong>' . e((string)$push['doc_no']) . '</strong>.');
        } elseif (is_array($push) && !empty($push['ok']) && ($push['state'] ?? '') === RET_INV_SKIPPED) {
            flash($awal . ' Tidak ada artikel yang ditandai masuk stok, jadi Inventory tidak diubah.', 'warn');
        } elseif (is_array($push) && empty($push['ok'])) {
            flash($awal . ' Namun stok BELUM masuk Inventory: ' . e(implode(' ', (array)$push['errors']))
                . ' Perbaiki lalu pakai tombol <em>Kirim ulang ke Inventory</em>.', 'error');
        } else {
            flash($awal);
        }
        break;

    case 'repost':
        ret_require('receive', 'mengirim ulang ke Inventory');
        $push = ret_push_inventory($id, $uid);
        if (!empty($push['ok']) && ($push['state'] ?? '') === RET_INV_POSTED) {
            flash('Stok masuk Inventory (' . e((string)$push['doc_no']) . ').');
        } elseif (!empty($push['ok'])) {
            flash('Tidak ada artikel yang ditandai masuk stok untuk retur ini.', 'warn');
        } else {
            flash('Masih gagal: ' . e(implode(' ', (array)$push['errors'])), 'error');
        }
        break;

    case 'swap_save':
        ret_require('edit', 'mengubah data penukaran');
        $res = ret_swap_save($id, ['from_sku' => (string)post('from_sku'), 'to_sku' => (string)post('to_sku'), 'qty' => parse_num((string)post('qty', '1'))], $uid);
        if (empty($res['ok'])) {
            flash(e(implode(' ', (array)$res['errors'])), 'error');
        } else {
            $dari = strtoupper(trim((string)post('from_sku')));
            $ke = strtoupper(trim((string)post('to_sku')));
            flash('Data penukaran tersimpan: <strong>' . e($dari) . '</strong> ditukar dengan <strong>' . e($ke) . '</strong>.');
        }
        break;

    case 'swap_send':
        ret_require('edit', 'mengirim barang pengganti');
        $res = ret_swap_send($id, $uid);
        if (empty($res['ok'])) {
            flash(e(implode(' ', (array)$res['errors'])), 'error');
        } else {
            flash('Barang pengganti dikirim lewat dokumen <strong>' . e((string)$res['doc_no']) . '</strong> '
                . '(Barang Keluar di aplikasi Inventory).');
        }
        break;

    case 'swap_mark':
        ret_require('edit', 'mengubah keadaan penukaran');
        $res = ret_swap_mark($id, (string)post('state'), $uid);
        if (empty($res['ok'])) {
            flash(e(implode(' ', (array)$res['errors'])), 'error');
        } else {
            flash('Penukaran ditandai: <strong>' . e(ret_swap_label((string)post('state'))) . '</strong>.');
        }
        break;

    case 'cancel':
        ret_require('void', 'membatalkan penerimaan');
        $res = ret_cancel_receive($id, (string)post('reason'), $uid);
        if (empty($res['ok'])) {
            flash(e(implode(' ', (array)$res['errors'])), 'error');
        } else {
            flash('Penerimaan retur <strong>' . e((string)$row['resi']) . '</strong> dibatalkan. '
                . 'Stok di Inventory sudah dikembalikan seperti semula.', 'warn');
        }
        break;

    case 'delete':
        ret_require('void', 'menghapus catatan retur');
        $res = ret_delete($id);
        if (empty($res['ok'])) {
            flash(e(implode(' ', (array)$res['errors'])), 'error');
        } else {
            flash('Catatan retur <strong>' . e((string)$row['resi']) . '</strong> dihapus.');
        }
        $target = 'returns.php';
        break;

    default:
        flash('Tindakan tidak dikenal.', 'error');
}

redirect($target);
