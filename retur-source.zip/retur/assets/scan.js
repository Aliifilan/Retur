/* ============================================================
 * Scan barcode/QR lewat kamera HP (BarcodeDetector).
 *
 * Dipakai untuk kolom nomor resi dan kolom artikel. Di iPhone/Safari (dan sebagian
 * desktop) API ini belum ada — pesannya menjelaskan agar memakai scanner
 * Bluetooth/USB atau mengetik langsung, jadi pekerjaan tidak pernah terhenti.
 *
 * Tombol yang mengaktifkan:
 *   <button data-cam-open data-cam-target="#fResi" data-cam-next="last-sku">Scan</button>
 * Nilai target khusus "last-sku" = kolom artikel terakhir (baris baru dibuat otomatis).
 * ============================================================ */
(function () {
  'use strict';

  var stream = null;
  var timer = null;
  var lastCode = '';
  var nextTarget = null;

  function el(sel, root) { return (root || document).querySelector(sel); }

  function setStatus(text) {
    var s = el('[data-cam-status]');
    if (s) s.textContent = text;
  }

  function stop() {
    if (timer) { clearInterval(timer); timer = null; }
    if (stream) {
      stream.getTracks().forEach(function (t) { t.stop(); });
      stream = null;
    }
    var ov = el('[data-cam-overlay]');
    if (ov) ov.hidden = true;
    var v = el('[data-cam-video]');
    if (v) v.srcObject = null;
    lastCode = '';
  }

  /** Kolom tujuan: selektor biasa, atau kata kunci "last-sku" untuk baris artikel terakhir. */
  function resolveField(target, addRowIfFilled) {
    if (target === 'last-sku') {
      if (!window.RetForm) return null;
      window.RetForm.ensureTrailingRow();
      var input = window.RetForm.lastSkuInput();
      if (input && addRowIfFilled && String(input.value || '').trim() !== '') {
        window.RetForm.addRow(false);
        window.RetForm.ensureTrailingRow();
        input = window.RetForm.lastSkuInput();
      }
      return input;
    }
    if (!target) return null;
    return el(target);
  }

  function apply(field, value) {
    if (!field) return;
    field.value = value;
    field.dispatchEvent(new Event('input', { bubbles: true }));
    field.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function focusNext() {
    if (!nextTarget) return;
    var target = resolveField(nextTarget, false);
    if (window.RetForm && target) target.focus();
    nextTarget = null;
  }

  function start(btn) {
    var ov = el('[data-cam-overlay]');
    var video = el('[data-cam-video]');
    if (!ov || !video) return;

    var target = btn.getAttribute('data-cam-target') || '';
    var addRow = btn.getAttribute('data-cam-add-row') === '1';
    var field = resolveField(target, addRow);
    nextTarget = btn.getAttribute('data-cam-next') || '';
    if (!field) { window.alert('Kolom tujuan scan tidak ditemukan. Muat ulang halaman lalu coba lagi.'); return; }

    ov.hidden = false;

    if (!('BarcodeDetector' in window)) {
      setStatus('Browser ini belum mendukung scan lewat kamera (iPhone/Safari dan sebagian desktop). '
        + 'Pakai scanner barcode/QR Bluetooth atau USB, atau ketik nomornya langsung di kolom.');
      return;
    }
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setStatus('Kamera tidak bisa diakses. Buka halaman ini lewat alamat HTTPS lalu coba lagi.');
      return;
    }

    var formats = ['code_128', 'code_39', 'code_93', 'ean_13', 'ean_8', 'upc_a', 'upc_e', 'itf', 'codabar', 'qr_code', 'data_matrix', 'pdf417'];
    setStatus('Menyalakan kamera…');
    navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 } }, audio: false })
      .then(function (s) {
        stream = s;
        video.srcObject = s;
        return video.play();
      })
      .then(function () {
        var detector = new window.BarcodeDetector({ formats: formats });
        setStatus('Arahkan kamera ke barcode / QR. Terbaca: belum ada.');
        timer = setInterval(function () {
          if (video.readyState < 2) return;
          detector.detect(video).then(function (codes) {
            if (!codes || !codes.length) {
              /* Tidak ada kode di frame = barang dijauhkan, jadi kode yang sama boleh
                 terbaca lagi (mis. beberapa paket dengan nomor resi sama tidak mungkin,
                 tetapi scan ulang setelah barang diletakkan lagi tetap bisa). */
              lastCode = '';
              return;
            }
            var value = String(codes[0].rawValue || '').trim();
            if (value === '' || value === lastCode) return;
            lastCode = value;
            apply(field, value);
            stop();
            focusNext();
          }).catch(function () { /* frame gagal dibaca: coba lagi di frame berikutnya */ });
        }, 350);
      })
      .catch(function (err) {
        var msg = 'Kamera tidak bisa dipakai.';
        if (err && (err.name === 'NotAllowedError' || err.name === 'SecurityError')) {
          msg = 'Izin kamera ditolak. Buka pengaturan browser → izinkan kamera untuk situs ini, lalu coba lagi.';
        } else if (err && err.name === 'NotFoundError') {
          msg = 'Tidak ada kamera yang terdeteksi di perangkat ini.';
        }
        setStatus(msg + ' Sebagai pengganti, pakai scanner Bluetooth/USB atau ketik manual.');
      });
  }

  document.addEventListener('click', function (ev) {
    var open = ev.target.closest('[data-cam-open]');
    if (open) {
      ev.preventDefault();
      start(open);
      return;
    }
    if (ev.target.closest('[data-cam-close]')) {
      ev.preventDefault();
      stop();
      return;
    }
    var ov = el('[data-cam-overlay]');
    if (ov && !ov.hidden && ev.target === ov) {
      stop();
      return;
    }
    /* Overlay pernah menutupi seluruh halaman dan memblokir klik — pastikan
       kamera berhenti begitu pengguna berpindah halaman. */
    var link = ev.target.closest('a[href]');
    if (link) stop();
  });

  window.addEventListener('pagehide', stop);
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) stop();
  });
})();
