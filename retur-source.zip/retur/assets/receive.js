/* ============================================================
 * Halaman rincian retur — bagian "Tandai retur diterima".
 *
 * Tugasnya satu: memberi tahu petugas gudang berapa artikel yang akan masuk stok
 * sebelum ia menekan tombol — supaya tidak ada barang rusak yang ikut kembali ke stok jual
 * dan tidak ada titik yang terlewat.
 * ============================================================ */
(function () {
  'use strict';

  function els(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function init() {
    var form = document.querySelector('[data-receive]');
    if (!form) return;
    var summary = form.querySelector('[data-receive-summary]');
    if (!summary) return;

    function refresh() {
      var masuk = 0, ditahan = 0, qty = 0, qtyTahan = 0;
      els('tr', form).forEach(function (row) {
        var chk = row.querySelector('.stock-check');
        if (!chk) return;
        var qtyCell = row.querySelector('td.num');
        var n = qtyCell ? parseFloat(String(qtyCell.textContent).replace(/[^0-9.,]/g, '').replace(',', '.')) || 0 : 0;
        if (chk.checked) { masuk++; qty += n; } else { ditahan++; qtyTahan += n; }
      });
      summary.innerHTML = '<strong>' + masuk + ' artikel</strong> masuk stok jual (' + qty + ' pcs)'
        + (ditahan > 0 ? '<br><span class="muted">' + ditahan + ' artikel tidak masuk stok (' + qtyTahan + ' pcs)</span>' : '');
      summary.className = 'receive-summary' + (masuk === 0 ? ' is-warn' : '');
    }

    /* Ganti kondisi memengaruhi pilihan masuk stok:
       rusak / kurang lengkap → jangan masuk stok jual (masih bisa dicentang ulang). */
    els('.cond-select', form).forEach(function (sel) {
      sel.addEventListener('change', function () {
        var row = sel.closest('tr');
        var chk = row ? row.querySelector('.stock-check') : null;
        if (chk) chk.checked = sel.value === 'bagus';
        refresh();
      });
    });
    els('.stock-check', form).forEach(function (chk) { chk.addEventListener('change', refresh); });
    refresh();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
