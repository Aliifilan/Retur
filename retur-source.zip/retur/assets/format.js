/* ============================================================
 * Pembaca angka untuk halaman aplikasi retur.
 *
 * Dipisah dari app.js supaya bisa diuji sendiri: aturannya WAJIB sama persis dengan
 * parse_num() di aplikasi Inventory (PHP). Kalau berbeda, tombol − / + pada kolom jumlah
 * bisa mengubah angka menjadi nilai yang tidak dimaksudkan pengguna.
 *   - ada "." dan ","  → pemisah paling belakang = desimal
 *   - hanya satu jenis pemisah, 3 angka di belakang & 1–3 angka (tanpa nol depan) di depan
 *     → pemisah ribuan ("50.000" → 50000)
 *   - selain itu desimal ("1,5" → 1.5)
 * Diuji silang dengan PHP oleh tests/retur_parse_check.sh.
 * ============================================================ */
(function (global) {
  'use strict';

  function num(v) {
    var s = String(v == null ? '' : v).trim();
    if (s === '') return 0;
    var neg = s.charAt(0) === '-';
    s = s.replace(/[^0-9.,]/g, '');
    if (s === '' || s === '.' || s === ',') return 0;

    var hasDot = s.indexOf('.') > -1;
    var hasComma = s.indexOf(',') > -1;
    var value;

    if (hasDot && hasComma) {
      if (s.lastIndexOf(',') > s.lastIndexOf('.')) {
        s = s.replace(/\./g, '').replace(/,/g, '.');
      } else {
        s = s.replace(/,/g, '');
      }
      value = parseFloat(s);
    } else if (!hasDot && !hasComma) {
      value = parseFloat(s);
    } else {
      var sep = hasDot ? '.' : ',';
      var parts = s.split(sep);
      var last = parts[parts.length - 1];
      var first = parts[0].replace(/^0+/, '');
      var isThousands = last !== '' && last.length === 3 && first !== '' && first.length <= 3;
      value = isThousands ? parseFloat(parts.join('')) : parseFloat(parts.join('.'));
    }

    if (isNaN(value)) value = 0;
    return neg ? -value : value;
  }

  global.RetFmt = { num: num };
})(typeof window !== 'undefined' ? window : globalThis);
