/* ============================================================
 * Perilaku halaman aplikasi Monitoring Retur Marketplace.
 *
 * Ditulis tanpa pustaka (mengikuti kebiasaan aplikasi lain di ruang kerja ini) dan
 * sengaja tidak memindahkan fokus dari kolom scan kecuali yang memang diminta:
 * setelah scan resi → fokus ke kolom artikel; setelah artikel → baris baru siap diisi.
 * ============================================================ */
(function () {
  'use strict';

  function el(sel, root) { return (root || document).querySelector(sel); }
  function els(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  /**
   * Angka dari teks. Aturannya ada di assets/format.js (RetFmt.num) yang diuji silang
   * dengan parse_num() PHP — jangan menulis ulang aturannya di sini.
   */
  function num(v) {
    if (window.RetFmt && typeof window.RetFmt.num === 'function') return window.RetFmt.num(v);
    var f = parseFloat(String(v == null ? '' : v).replace(',', '.'));
    return isNaN(f) ? 0 : f;
  }

  function sanitizeQty(input) {
    var v = String(input.value || '').replace(/[^0-9.,]/g, '');
    if (v !== input.value) input.value = v;
    return v;
  }

  /* ---------------- baris artikel ---------------- */

  var body = el('#itemBody');
  var tpl = el('#itemTpl');
  var idx = 0;

  function nextIndex() {
    var max = -1;
    els('input[name^="item_sku["]', body || document).forEach(function (i) {
      var m = /\[(\d+)\]/.exec(i.name);
      if (m) max = Math.max(max, parseInt(m[1], 10));
    });
    idx = Math.max(idx, max + 1);
    return idx++;
  }

  function addRow(focus) {
    if (!body || !tpl) return null;
    var html = tpl.innerHTML.replace(/__IDX__/g, String(nextIndex()));
    var wrap = document.createElement('tbody');
    wrap.innerHTML = html;
    var row = wrap.firstElementChild;
    body.appendChild(row);
    if (focus) {
      var inp = el('.sku-input', row);
      if (inp) inp.focus();
    }
    return row;
  }

  function lastSkuInput() {
    var list = body ? els('.sku-input', body) : [];
    return list.length ? list[list.length - 1] : null;
  }

  function rowsCount() {
    return body ? els('.item-row', body).length : 0;
  }

  /** Pastikan selalu ada satu baris kosong di bawah untuk scan berikutnya. */
  function ensureTrailingRow() {
    if (!body || !tpl) return;
    var rows = els('.item-row', body);
    if (!rows.length) { addRow(false); return; }
    var last = rows[rows.length - 1];
    var sku = el('.sku-input', last);
    if (sku && String(sku.value).trim() !== '') addRow(false);
  }

  function renumber() {
    /* Nomor indeks tidak perlu berurutan (server membacanya per kunci), tetapi
       penomoran ulang membuat HTML hasil simpan mudah dibaca saat menelusuri masalah. */
    if (!body) return;
    els('.item-row', body).forEach(function (row, i) {
      els('input, select', row).forEach(function (f) {
        if (f.name && /\[\d+\]$/.test(f.name)) f.name = f.name.replace(/\[\d+\]$/, '[' + i + ']');
      });
    });
    idx = rowsCount();
  }

  /* ---------------- info SKU (cek ke Inventory) ---------------- */

  function showRowInfo(input, text, isError) {
    var cell = input.closest('td');
    var info = cell ? el('[data-row-info]', cell) : null;
    if (!info) return;
    info.textContent = text || '';
    info.className = 'row-info' + (isError ? ' err' : '');
  }

  function lookupSku(input, done) {
    var sku = String(input.value || '').trim();
    if (sku === '') { showRowInfo(input, '', false); if (done) done(); return; }
    fetch('api.php?op=sku&sku=' + encodeURIComponent(sku), { headers: { 'Accept': 'application/json' } })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d || !d.found) {
          showRowInfo(input, 'Belum terdaftar di Inventory — tetap tercatat, tetapi stoknya tidak bisa ditambahkan.', true);
        } else {
          var bits = [];
          if (d.brand) bits.push(d.brand);
          if (d.size) bits.push(d.size);
          bits.push('stok ' + (d.stock_text || '0') + (d.unit ? ' ' + d.unit : ''));
          if (d.active === false) bits.push('nonaktif');
          showRowInfo(input, bits.join(' • '), false);
        }
        if (done) done(d);
      })
      .catch(function () { showRowInfo(input, '', false); if (done) done(); });
  }

  /* ---------------- cek resi dobel ---------------- */

  function checkResi() {
    var warn = el('[data-resi-warn]');
    var resi = el('#fResi');
    if (!warn || !resi) return;
    var v = String(resi.value || '').trim();
    if (v === '') { warn.textContent = ''; warn.className = 'row-info'; return; }
    var id = warn.getAttribute('data-ret-id') || '0';
    fetch('api.php?op=resi&id=' + encodeURIComponent(id) + '&resi=' + encodeURIComponent(v), { headers: { 'Accept': 'application/json' } })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d || !d.items || !d.items.length) { warn.textContent = ''; warn.className = 'row-info'; return; }
        var txt = 'Resi ini sudah tercatat: ' + d.items.map(function (i) {
          return i.resi + ' (' + i.marketplace + ', ' + i.issued_date + ', ' + i.status + ')';
        }).join('; ');
        warn.textContent = txt + ' — periksa agar tidak dobel.';
        warn.className = 'row-info err';
      })
      .catch(function () {});
  }

  /* ---------------- klik (tombol baris, qty, konfirmasi) ---------------- */

  document.addEventListener('click', function (ev) {
    var stepBtn = ev.target.closest('[data-qty-step]');
    if (stepBtn) {
      ev.preventDefault();
      var group = stepBtn.closest('.qty-group');
      var input = group ? el('.qty-input', group) : null;
      if (input) {
        var step = parseInt(stepBtn.getAttribute('data-qty-step'), 10) || 0;
        var v = Math.round(num(input.value)) + step;
        if (v < 1) v = 1;                 /* jumlah 0 tidak pernah masuk akal pada retur */
        if (v > 999999) v = 999999;
        input.value = String(v);
        input.dispatchEvent(new Event('input', { bubbles: true }));
      }
      return;   // fokus SENGAJA tidak dipindahkan supaya −/+ bisa ditekan berkali-kali
    }

    var add = ev.target.closest('#addRow');
    if (add) { addRow(true); return; }

    var rm = ev.target.closest('[data-row-remove]');
    if (rm) {
      var row = rm.closest('tr');
      if (row && body) {
        row.parentNode.removeChild(row);
        ensureTrailingRow();
        renumber();
      }
      return;
    }

    var conf = ev.target.closest('[data-confirm]');
    if (conf) {
      var msg = conf.getAttribute('data-confirm') || 'Lanjutkan?';
      if (!window.confirm(msg)) { ev.preventDefault(); ev.stopPropagation(); }
    }
  });

  /* ---------------- perubahan nilai ---------------- */

  document.addEventListener('change', function (ev) {
    var cond = ev.target.closest('.cond-select');
    if (cond) {
      /* Kondisi rusak / kurang lengkap: jangan masuk stok jual (masih bisa dicentang ulang). */
      var row = cond.closest('tr');
      var chk = row ? el('.stock-check', row) : null;
      if (chk && !chk.disabled) {
        var layak = cond.value === 'bagus';
        chk.checked = layak;
        if (!layak) {
          var info = el('[data-row-info]', row.querySelector('.sku-cell'));
          if (info && !info.textContent) {
            showRowInfo(el('.sku-input', row), 'Kondisi tidak layak jual — tanda "Masuk stok" dimatikan.', false);
          }
        }
      }
      return;
    }

    var sku = ev.target.closest('.sku-input');
    if (sku) {
      /* Kolom jumlah dikosongkan berarti 1 pcs; isi angkanya begitu artikel jelas. */
      var qtyBox = sku.closest('tr') ? sku.closest('tr').querySelector('.qty-input') : null;
      if (qtyBox && String(qtyBox.value).trim() === '') qtyBox.value = '1';
      lookupSku(sku);
      ensureTrailingRow();
      return;
    }

    var resi = ev.target.closest('#fResi');
    if (resi) { checkResi(); return; }
  });

  document.addEventListener('input', function (ev) {
    if (ev.target.closest('.qty-input')) sanitizeQty(ev.target);
  });

  /* ---------------- tombol Enter (scanner Bluetooth/USB) ---------------- */

  document.addEventListener('keydown', function (ev) {
    if (ev.key !== 'Enter') return;
    var t = ev.target;

    if (t.closest('.qty-input') || t.closest('#fResi')) {
      /* Enter di kolom resi/jumlah jangan mengirim formulir — lanjut ke kolom artikel. */
      ev.preventDefault();
      var last = lastSkuInput();
      if (last) last.focus();
      return;
    }

    if (t.closest('.sku-input')) {
      ev.preventDefault();
      var input = t.closest('.sku-input');
      var sku = String(input.value || '').trim();
      if (sku === '') return;
      lookupSku(input, function () {
        ensureTrailingRow();
        var last = lastSkuInput();
        if (last && last !== input) last.focus();
      });
    }
  }, true);

  /* ---------------- kolom "Ke stok" mengikuti tanggal diterima ---------------- */

  /**
   * Kolom "Ke stok" (dan petunjuknya) hanya muncul bila tanggal retur diterima terisi.
   * Aturan ini cerminan aturan server (ret_save/ret_receive): stok baru dikirim saat
   * tanggal diterima ada — kalau tidak, paketnya belum sampai gudang.
   */
  function syncStockCol() {
    var table = el('[data-items]');
    var dateEl = el('[name="received_date_raw"]');
    if (!table) return;
    var on = !!dateEl && String(dateEl.value || '').trim() !== '' && !dateEl.disabled;
    table.classList.toggle('stock-hidden', !on);
    var note = el('[data-stock-note]');
    if (note) note.hidden = on;
    var noteOn = el('[data-stock-note-on]');
    if (noteOn) noteOn.hidden = !on;
    var hintOff = el('[data-save-hint-muted]');
    if (hintOff) hintOff.hidden = on;
    var hintOn = el('[data-save-hint-stock]');
    if (hintOn) hintOn.hidden = !on;
  }

  /* ---------------- halaman retur manual: petunjuk jenis ---------------- */

  var REASON_HINTS = {
    tukar_size: 'Barang lama nanti ditukar dengan artikel pengganti — penggantinya dikirim lewat tombol di halaman rincian setelah barang lama diterima.',
    salah_kirim: 'Barang yang salah kirim akan kembali; tulis juga koreksinya di catatan.',
    rusak_kirim: 'Barang rusak biasanya TIDAK masuk stok — centang kondisinya sesuai pemeriksaan.',
    hilang_kirim: 'Catatan ini untuk arsip; klaim ke jasa kirim/marketplace lewat menu Tiket Kendala.',
    batal_order: 'Barang kembali ke gudang dan biasanya masih layak jual.',
    ambil_toko: 'Pembeli mengembalikan langsung di toko — isi tanggal barang diterima bila sudah.',
    lainnya: 'Tulis detailnya di kolom catatan supaya mudah ditelusuri.'
  };

  document.addEventListener('change', function (ev) {
    var reason = ev.target.closest('#fReason');
    if (reason) {
      var hint = document.getElementById('reasonHint');
      var val = reason.value;
      if (hint) hint.textContent = REASON_HINTS[val] || '';
      /* Tukar size: barang lama tidak boleh langsung masuk stok. */
      if (val === 'tukar_size') {
        els('#itemBody .item-row', body || document).forEach(function (row) {
          var chk = row.querySelector('.stock-check');
          if (chk && !chk.disabled) chk.checked = false;
        });
      }
      return;
    }
  }, true);

  /* ---------------- pengiriman formulir ---------------- */

  document.addEventListener('submit', function (ev) {
    var form = ev.target;
    if (!form || !form.matches('.retur-form')) return;
    var received = el('[name="received_date_raw"]', form);
    if (received && received.value && !received.disabled) {
      var masuk = 0;
      els('#itemBody .item-row', form).forEach(function (row) {
        var sku = el('.sku-input', row);
        var chk = el('.stock-check', row);
        if (sku && String(sku.value).trim() !== '' && chk && chk.checked && !chk.disabled) masuk++;
      });
      var pesan = masuk > 0
        ? masuk + ' artikel bertanda "Masuk stok" akan langsung ditambahkan ke stok aplikasi Inventory.'
        : 'Tidak ada artikel bertanda "Masuk stok", jadi stok Inventory tidak berubah.';
      if (!window.confirm('Tanggal retur diterima terisi (' + received.value + ').\n\n' + pesan + '\nLanjutkan simpan?')) {
        ev.preventDefault();
        return;
      }
    }
    renumber();
  }, true);

  /* ---------------- siapkan halaman ---------------- */

  document.addEventListener('DOMContentLoaded', function () {
    var tanggal = el('[name="received_date_raw"]');
    if (tanggal) {
      tanggal.addEventListener('change', syncStockCol);
      tanggal.addEventListener('input', syncStockCol);
      syncStockCol();
    }
    if (!body) return;

    /* Penanda baris dari data yang sudah tersimpan: tampilkan info stok tanpa harus blur. */
    els('.sku-input', body).forEach(function (input) {
      if (String(input.value || '').trim() !== '') lookupSku(input);
    });

    var resi = el('#fResi');
    if (resi && String(resi.value || '').trim() === '' && !resi.disabled) resi.focus();
  });

  /* Dipakai assets/scan.js (kamera) supaya tidak perlu tahu isi tabel. */
  window.RetForm = {
    syncStockCol: syncStockCol,
    addRow: addRow,
    lastSkuInput: lastSkuInput,
    ensureTrailingRow: ensureTrailingRow,
    lookupSku: function (input) { if (input) lookupSku(input); },
    focusResiNext: function () {
      var last = lastSkuInput();
      if (last) last.focus();
      return last;
    }
  };
})();
