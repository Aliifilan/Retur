<?php
declare(strict_types=1);

/* ============================================================
 * Database aplikasi Monitoring Retur Marketplace (SQLite, baca-tulis).
 *
 * Kenapa di LUAR folder aplikasi: folder aplikasi disajikan sebagai berkas statis
 * oleh web server, jadi database berisi nama pembeli & nomor resi tidak boleh ada
 * di dalamnya.
 *
 * Catatan kinerja (mengikuti kebiasaan aplikasi lain di ruang kerja ini):
 *  - PDO: busy_timeout + WAL + synchronous=NORMAL.
 *  - ret_ensure_schema() seluruhnya dibungkus SATU transaksi supaya tidak fsync per
 *    pernyataan pada setiap request.
 *  - ret_tx() reentrant (bersarang aman).
 *  - Semua query lewat ret_prepare() yang menolak bila jumlah ? ≠ jumlah nilai
 *    (kelas bug "nilai bergeser satu kolom" pernah terjadi di aplikasi Inventory).
 * ============================================================ */

function retur_data_dir(): string
{
    static $dir = null;
    if ($dir !== null) return $dir;

    $env = getenv('RETUR_DATA');
    if (is_string($env) && $env !== '') return $dir = rtrim($env, '/');

    $outside = dirname(__DIR__, 2) . '/retur-data';
    if (!is_dir($outside)) { @mkdir($outside, 0775, true); }
    if (is_dir($outside) && is_writable($outside)) return $dir = $outside;

    $tmp = rtrim(sys_get_temp_dir(), '/\\') . '/retur-data-' . substr(sha1(dirname(__DIR__)), 0, 8);
    if (!is_dir($tmp)) { @mkdir($tmp, 0775, true); }
    return $dir = $tmp;
}

/** Apakah folder data terpaksa memakai folder sementara sistem (perlu diperingatkan)? */
function retur_data_is_fallback(): bool
{
    $base = str_replace('\\', '/', dirname(__DIR__, 2) . '/retur-data');
    return !str_starts_with(str_replace('\\', '/', retur_data_dir()), $base);
}

function retur_data_path(string $file): string
{
    $dir = retur_data_dir();
    if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
    return rtrim($dir, '/') . '/' . $file;
}

function ret_db_path(): string
{
    return retur_data_path('data.sqlite');
}

function ret_db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $pdo = new PDO('sqlite:' . ret_db_path());
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec('PRAGMA busy_timeout = 5000');
    $pdo->exec('PRAGMA journal_mode = WAL');
    $pdo->exec('PRAGMA synchronous = NORMAL');
    $pdo->exec('PRAGMA foreign_keys = ON');
    return $pdo;
}

/** Hitung jumlah tanda ? di luar tanda kutip (sama seperti pengaman aplikasi Inventory). */
function ret_placeholder_count(string $sql): int
{
    $count = 0;
    $len = strlen($sql);
    $quote = null;
    for ($i = 0; $i < $len; $i++) {
        $ch = $sql[$i];
        if ($quote !== null) {
            if ($ch === $quote) {
                if ($i + 1 < $len && $sql[$i + 1] === $quote) { $i++; continue; }
                $quote = null;
            }
            continue;
        }
        if ($ch === "'" || $ch === '"') { $quote = $ch; continue; }
        if ($ch === '?') $count++;
    }
    return $count;
}

function ret_prepare(string $sql, array $params = []): PDOStatement
{
    $expected = ret_placeholder_count($sql);
    if ($expected !== count($params)) {
        $snippet = preg_replace('/\s+/', ' ', substr($sql, 0, 90));
        throw new RuntimeException(
            'Jumlah parameter SQL tidak cocok: ' . $expected . ' tanda ? tetapi ' . count($params)
            . ' nilai dikirim. Query: ' . $snippet . '…'
        );
    }
    $st = ret_db()->prepare($sql);
    $st->execute(array_values($params));
    return $st;
}

function ret_all(string $sql, array $params = []): array
{
    return ret_prepare($sql, $params)->fetchAll();
}

function ret_one(string $sql, array $params = [])
{
    $row = ret_prepare($sql, $params)->fetch();
    return $row === false ? null : $row;
}

function ret_scalar(string $sql, array $params = [])
{
    $v = ret_prepare($sql, $params)->fetchColumn();
    return $v === false ? null : $v;
}

function ret_run(string $sql, array $params = []): PDOStatement
{
    return ret_prepare($sql, $params);
}

/**
 * Transaksi yang boleh bersarang: transaksi dalam sudah "menumpang" transaksi luar
 * (SQLite menolak BEGIN bersarang).
 */
function ret_tx(callable $fn)
{
    static $depth = 0;
    if ($depth > 0) return $fn();

    $pdo = ret_db();
    $depth++;
    /* BEGIN IMMEDIATE: kunci tulis diambil sejak awal, sehingga pengulangan busytimeout
       bekerja andal saat dua request menyimpan bersamaan. */
    $pdo->exec('BEGIN IMMEDIATE');
    try {
        $out = $fn();
        $pdo->exec('COMMIT');
        $depth--;
        return $out;
    } catch (Throwable $e) {
        try { $pdo->exec('ROLLBACK'); } catch (Throwable $e2) { /* sudah tidak ada transaksi */ }
        $depth--;
        throw $e;
    }
}

/** Skema + data awal. SELURUH body dibungkus satu transaksi (hindari fsync per pernyataan). */
function ret_ensure_schema(): void
{
    ret_tx(function () {
        $pdo = ret_db();
        $pdo->exec("CREATE TABLE IF NOT EXISTS mret (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            uuid TEXT NOT NULL DEFAULT '',
            marketplace TEXT NOT NULL DEFAULT '',
            resi TEXT NOT NULL DEFAULT '',
            order_no TEXT NOT NULL DEFAULT '',
            buyer TEXT NOT NULL DEFAULT '',
            courier TEXT NOT NULL DEFAULT '',
            reason TEXT NOT NULL DEFAULT '',
            note TEXT NOT NULL DEFAULT '',
            issued_date TEXT NOT NULL,
            received_date TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'pending',
            qty_total REAL NOT NULL DEFAULT 0,
            manual INTEGER NOT NULL DEFAULT 0,
            source TEXT NOT NULL DEFAULT 'marketplace',
            swap_from_sku TEXT NOT NULL DEFAULT '',
            swap_to_sku TEXT NOT NULL DEFAULT '',
            swap_qty REAL NOT NULL DEFAULT 0,
            swap_state TEXT NOT NULL DEFAULT '',
            swap_doc_no TEXT NOT NULL DEFAULT '',
            created_by INTEGER, created_at TEXT,
            updated_by INTEGER, updated_at TEXT,
            received_by INTEGER, received_at TEXT,
            canceled_by INTEGER, canceled_at TEXT, cancel_reason TEXT NOT NULL DEFAULT '',
            inv_state TEXT NOT NULL DEFAULT 'none',
            inv_doc_no TEXT NOT NULL DEFAULT '',
            inv_return_id INTEGER NOT NULL DEFAULT 0,
            inv_error TEXT NOT NULL DEFAULT '',
            inv_at TEXT NOT NULL DEFAULT '',
            mk_received_date TEXT NOT NULL DEFAULT ''
        )");
        $pdo->exec("CREATE TABLE IF NOT EXISTS mitem (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ret_id INTEGER NOT NULL REFERENCES mret(id) ON DELETE CASCADE,
            sku TEXT NOT NULL DEFAULT '',
            qty REAL NOT NULL DEFAULT 0,
            condition TEXT NOT NULL DEFAULT 'bagus',
            to_stock INTEGER NOT NULL DEFAULT 1,
            known INTEGER NOT NULL DEFAULT 0,
            note TEXT NOT NULL DEFAULT ''
        )");
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_mret_resi ON mret(resi)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_mret_issued ON mret(issued_date)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_mret_status ON mret(status)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_mitem_ret ON mitem(ret_id)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_mitem_sku ON mitem(sku)');

        /* Migrasi ringan untuk database yang dibuat versi sebelumnya. */
        ret_migrate_column($pdo, 'mret', 'manual', "INTEGER NOT NULL DEFAULT 0");
        ret_migrate_column($pdo, 'mret', 'source', "TEXT NOT NULL DEFAULT 'marketplace'");
        ret_migrate_column($pdo, 'mret', 'swap_from_sku', "TEXT NOT NULL DEFAULT ''");
        ret_migrate_column($pdo, 'mret', 'swap_to_sku', "TEXT NOT NULL DEFAULT ''");
        ret_migrate_column($pdo, 'mret', 'swap_qty', "REAL NOT NULL DEFAULT 0");
        ret_migrate_column($pdo, 'mret', 'swap_state', "TEXT NOT NULL DEFAULT ''");
        ret_migrate_column($pdo, 'mret', 'swap_doc_no', "TEXT NOT NULL DEFAULT ''");
        ret_migrate_column($pdo, 'mret', 'mk_received_date', "TEXT NOT NULL DEFAULT ''");

        $pdo->exec("CREATE TABLE IF NOT EXISTS mticket (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            uuid TEXT NOT NULL DEFAULT '',
            marketplace TEXT NOT NULL DEFAULT '',
            ticket_no TEXT NOT NULL DEFAULT '',
            order_no TEXT NOT NULL DEFAULT '',
            resi TEXT NOT NULL DEFAULT '',
            buyer TEXT NOT NULL DEFAULT '',
            category TEXT NOT NULL DEFAULT 'lainnya',
            subject TEXT NOT NULL DEFAULT '',
            detail TEXT NOT NULL DEFAULT '',
            opened_date TEXT NOT NULL,
            due_date TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'open',
            closed_date TEXT NOT NULL DEFAULT '',
            close_note TEXT NOT NULL DEFAULT '',
            refund_amount REAL NOT NULL DEFAULT 0,
            created_by INTEGER, created_at TEXT,
            updated_by INTEGER, updated_at TEXT,
            closed_by INTEGER, closed_at TEXT
        )");
        $pdo->exec("CREATE TABLE IF NOT EXISTS mticket_reply (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticket_id INTEGER NOT NULL REFERENCES mticket(id) ON DELETE CASCADE,
            at TEXT NOT NULL,
            by_user INTEGER,
            by_name TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'open',
            message TEXT NOT NULL DEFAULT ''
        )");
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_mticket_status ON mticket(status)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_mticket_opened ON mticket(opened_date)');
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_mticket_reply ON mticket_reply(ticket_id)');
    });
}

/** Tambah kolom bila belum ada (dipakai migrasi database lama). */
function ret_migrate_column(PDO $pdo, string $table, string $column, string $definition): void
{
    $cols = [];
    foreach ($pdo->query('PRAGMA table_info(' . $table . ')') as $c) {
        $cols[(string)$c['name']] = true;
    }
    if (!isset($cols[$column])) {
        $pdo->exec('ALTER TABLE ' . $table . ' ADD COLUMN ' . $column . ' ' . $definition);
    }
}
