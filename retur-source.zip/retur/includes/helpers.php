<?php
declare(strict_types=1);

/* ============================================================
 * Helper aplikasi Monitoring Retur Marketplace.
 *
 * Catatan: fungsi umum (e(), fmt_money(), fmt_date(), csrf_*, pager(), parse_num(),
 * now(), today(), redirect(), flash()) DIPAKAI DARI aplikasi Inventory — jangan
 * didefinisikan ulang di sini, nama-namanya sudah ada di memori PHP yang sama.
 * ============================================================ */

/** Pilihan marketplace (sesuai permintaan pemilik toko). */
function ret_markets(): array
{
    return [
        'shopee' => 'Shopee',
        'tiktok' => 'TikTok Shop',
        'lazada' => 'Lazada',
    ];
}

function ret_market_label(string $code): string
{
    return ret_markets()[$code] ?? ($code !== '' ? $code : '-');
}

/** Kelas warna badge per marketplace (dipakai tabel & grafik). */
function ret_market_class(string $code): string
{
    return match ($code) {
        'shopee' => 'mk-shopee',
        'tiktok' => 'mk-tiktok',
        'lazada' => 'mk-lazada',
        default  => 'mk-other',
    };
}

function ret_market_badge(string $code): string
{
    return '<span class="badge ' . ret_market_class($code) . '">' . e(ret_market_label($code)) . '</span>';
}

/**
 * Kondisi barang saat diterima.
 *
 * Urutannya dipakai apa adanya di semua dropdown (form, halaman rincian, retur manual)
 * supaya petugas melihat pilihan yang sama di mana pun.
 *
 * Catatan: semua kondisi selain 'bagus' berarti barang TIDAK kembali ke stok jual
 * (dipatuhi otomatis oleh assets/app.js), dan dihitung sebagai "tidak layak jual" di dashboard.
 */
function ret_conditions(): array
{
    return [
        'bagus'   => 'Bagus (layak jual)',
        'ditukar' => 'Barang ditukar',
        'rusak'   => 'Rusak',
        'kurang'  => 'Kurang lengkap',
    ];
}

/** Jenis retur manual (dicatat tanpa marketplace/no. resi). */
function ret_manual_types(): array
{
    return [
        'tukar_size' => 'Tukar size / tukar model (ambil barang lama, ganti baru)',
        'salah_kirim' => 'Salah kirim dari gudang (barang salah varian/kode)',
        'rusak_kirim' => 'Rusak saat dikirim / dikemas kurang aman',
        'hilang_kirim' => 'Paket hilang / tidak sampai pembeli',
        'batal_order' => 'Pesanan dibatalkan pembeli setelah dikemas',
        'ambil_toko' => 'Retur di toko langsung (ambil sendiri)',
        'lainnya' => 'Lainnya (tulis keterangan)',
    ];
}

function ret_manual_label(string $code): string
{
    return ret_manual_types()[$code] ?? ($code !== '' ? $code : '-');
}

/** Status penukaran size (hanya untuk retur manual jenis tukar_size). */
function ret_swap_states(): array
{
    return [
        'pending'  => 'Menunggu barang lama kembali',
        'received' => 'Barang lama diterima gudang',
        'sent'     => 'Barang pengganti dikirim / diambil',
        'done'     => 'Selesai',
        'canceled' => 'Dibatalkan',
    ];
}

function ret_swap_label(string $code): string
{
    return ret_swap_states()[$code] ?? '—';
}

/** Jenis kendala yang dicatat di Tiket Kendala Marketplace. */
function ret_ticket_categories(): array
{
    return [
        'dana_ditahan'  => 'Dana ditahan / escrow',
        'klaim_hilang'  => 'Klaim paket hilang',
        'klaim_rusak'   => 'Klaim paket rusak',
        'retur_macet'   => 'Retur macet / belum diproses marketplace',
        'refund_belum'  => 'Refund pembeli belum turun',
        'denda_pelanggaran' => 'Denda / pelanggaran toko',
        'iklan_saldo'   => 'Iklan / saldo iklan bermasalah',
        'akun_verifikasi' => 'Akun, verifikasi & akses',
        'lainnya'       => 'Lainnya',
    ];
}

function ret_ticket_category_label(string $code): string
{
    return ret_ticket_categories()[$code] ?? 'Lainnya';
}

/** Status tiket + kelas badge-nya. */
function ret_ticket_statuses(): array
{
    return [
        'open'      => ['Terbuka', 'badge-warn'],
        'waiting'   => ['Menunggu marketplace', 'badge-warn'],
        'progress'  => ['Sedang diproses', 'badge-info'],
        'resolved'  => ['Selesai / untung', 'badge-ok'],
        'closed'    => ['Ditutup', 'badge-muted'],
    ];
}

function ret_ticket_status_label(string $code): string
{
    $m = ret_ticket_statuses();
    return $m[$code][0] ?? $code;
}

function ret_ticket_status_badge(string $code): string
{
    $m = ret_ticket_statuses();
    [$label, $cls] = $m[$code] ?? [$code, 'badge-muted'];
    return '<span class="badge ' . $cls . '">' . e($label) . '</span>';
}

function ret_ticket_category_badge(string $code): string
{
    return '<span class="badge badge-muted">' . e(ret_ticket_category_label($code)) . '</span>';
}

function ret_cond_label(string $code): string
{
    return ret_conditions()[$code] ?? 'Bagus (layak jual)';
}

function ret_cond_badge(string $code): string
{
    $cls = match ($code) {
        'rusak'   => 'badge-danger',
        'kurang'  => 'badge-warn',
        'ditukar' => 'badge-info',
        default   => 'badge-ok',
    };
    return '<span class="badge ' . $cls . '">' . e(ret_cond_label($code)) . '</span>';
}

/** Saran alasan retur (datalist) — pengguna tetap bebas mengetik alasan lain. */
function ret_reasons(): array
{
    return [
        'Barang tidak sesuai pesanan',
        'Barang rusak / pecah',
        'Salah ukuran',
        'Salah warna / model',
        'Barang kurang lengkap',
        'Pembeli berubah pikiran',
        'Paket tidak sampai / hilang',
        'Salah kirim oleh penjual',
    ];
}

/** Saran nama kurir (datalist). */
function ret_couriers(): array
{
    return ['JNE', 'J&T', 'SiCepat', 'AnterAja', 'Ninja Xpress', 'Shopee Express', 'Lazada Express', 'ID Express', 'Pos Indonesia', 'Ambil sendiri'];
}

/**
 * Umur dalam hari: selisih tanggal (bisa negatif bila tanggal di masa depan).
 * Dihitung dari tanggal (bukan jam) supaya tidak terpengaruh zona waktu server.
 */
function ret_age_days(string $from, ?string $to = null): int
{
    $to = $to !== null && $to !== '' ? $to : today();
    $a = parse_date_flexible($from);
    $b = parse_date_flexible($to);
    if (!$a || !$b) return 0;
    try {
        $d1 = new DateTimeImmutable($a);
        $d2 = new DateTimeImmutable($b);
        $diff = (int)$d1->diff($d2)->format('%r%a');
        return $diff;
    } catch (Throwable $e) {
        return 0;
    }
}

/** Warna penanda umur tunggu: hijau (baru), kuning, merah (perlu dikejar). */
function ret_age_class(int $days): string
{
    if ($days >= 7) return 'age-danger';
    if ($days >= 3) return 'age-warn';
    return 'age-ok';
}

function ret_age_text(int $days): string
{
    if ($days < 0) return 'tanggal di depan';
    if ($days === 0) return 'hari ini';
    return $days . ' hari';
}

/**
 * Selisih hari antara "diterima menurut marketplace" dan "diterima di gudang" —
 * selisih positif = paket terlambat dari yang diklaim jasa kirim (bahan klaim).
 */
function ret_delay_days(array $row): ?int
{
    $mk = (string)($row['mk_received_date'] ?? '');
    $gd = (string)($row['received_date'] ?? '');
    if ($mk === '' || $gd === '') return null;
    return ret_age_days($mk, $gd);
}

function ret_delay_text(?int $days): string
{
    if ($days === null) return '';
    if ($days <= 0) return 'tepat waktu';
    return 'terlambat ' . $days . ' hari';
}

function ret_delay_badge(?int $days): string
{
    if ($days === null) return '';
    if ($days <= 0) return '<span class="age age-ok" title="Diterima di gudang tidak lebih lambat dari klaim jasa kirim">' . e(ret_delay_text($days)) . '</span>';
    $cls = $days >= 3 ? 'age-danger' : 'age-warn';
    return '<span class="age ' . $cls . '" title="Selisih antara diterima menurut marketplace dan diterima di gudang">' . e(ret_delay_text($days)) . '</span>';
}

/** Badge status penerimaan. */
function ret_status_badge(array $row): string
{
    $st = (string)($row['status'] ?? 'pending');
    if ($st === 'received') {
        $txt = 'Diterima';
        if (!empty($row['received_date'])) $txt .= ' ' . fmt_date((string)$row['received_date']);
        return '<span class="badge badge-ok">' . e($txt) . '</span>';
    }
    return '<span class="badge badge-warn">Belum diterima</span>';
}

/** Badge keadaan pengiriman stok ke Inventory. */
function ret_inv_badge(array $row): string
{
    $state = (string)($row['inv_state'] ?? 'none');
    $doc = (string)($row['inv_doc_no'] ?? '');
    $title = $state === 'blocked' ? (string)($row['inv_error'] ?? '') : '';
    $label = match ($state) {
        'posted'  => 'Stok ✓ ' . ($doc !== '' ? $doc : ''),
        'blocked' => 'Stok gagal',
        'void'    => 'Stok dibatalkan',
        'skipped' => 'Tanpa stok',
        default   => 'Belum masuk stok',
    };
    $cls = match ($state) {
        'posted'  => 'badge-ok',
        'blocked' => 'badge-danger',
        'void'    => 'badge-muted',
        'skipped' => 'badge-muted',
        default   => 'badge-muted',
    };
    return '<span class="badge ' . $cls . '"' . ($title !== '' ? ' title="' . e($title) . '"' : '') . '>'
        . e($label) . '</span>';
}

/** Ringkasan artikel sebuah retur: "JK-001 ×1, WK-002 ×2" (dipotong bila terlalu banyak). */
function ret_items_summary(array $items, int $max = 3): string
{
    if (!$items) return '<span class="muted">belum ada artikel</span>';
    $parts = [];
    foreach ($items as $i) {
        if (count($parts) >= $max) { $parts[] = '+' . (count($items) - $max) . ' lagi'; break; }
        $parts[] = (string)$i['sku'] . ' ×' . fmt_qty($i['qty']);
    }
    return '<span class="sku-list">' . e(implode(', ', $parts)) . '</span>';
}

/** SKU yang dianggap "belum terdaftar" diberi penanda supaya tidak salah kirim ke stok. */
function ret_known_badge(int $known): string
{
    return $known === 1
        ? '<span class="badge badge-ok" title="Terdaftar di aplikasi Inventory">Inventory</span>'
        : '<span class="badge badge-danger" title="Belum terdaftar di aplikasi Inventory">Baru / belum terdaftar</span>';
}

/** Nomor resi dinormalkan (huruf besar, tanpa spasi) supaya pencarian & perbandingan konsisten. */
function ret_norm_resi(string $resi): string
{
    return strtoupper(preg_replace('/\s+/', '', trim($resi)) ?? '');
}

function ret_norm_sku(string $sku): string
{
    return strtoupper(preg_replace('/\s+/', '', trim($sku)) ?? '');
}

/**
 * Tanggal dari input pengguna; menerima format bebas (31/01/2026, 2026-01-31, …).
 * String kosong tetap kosong (bukan "hari ini") supaya tanggal yang belum diisi
 * tidak diam-diam terisi sendiri.
 */
function ret_date_input(string $value): string
{
    $value = trim($value);
    if ($value === '') return '';
    return parse_date_flexible($value) ?? '';
}

/** Rentang tanggal untuk ringkasan dashboard. */
function ret_period_options(): array
{
    return ['7' => '7 hari terakhir', '30' => '30 hari terakhir', '90' => '90 hari terakhir', 'all' => 'Semua'];
}

/** Batas awal periode ('' = tanpa batas). */
function ret_period_from(string $period): string
{
    if ($period === 'all' || $period === '') return '';
    $days = max(1, (int)$period);
    try {
        return (new DateTimeImmutable(today()))->modify('-' . ($days - 1) . ' days')->format('Y-m-d');
    } catch (Throwable $e) {
        return '';
    }
}
