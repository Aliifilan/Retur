<?php
declare(strict_types=1);

/* ============================================================
 * Aturan pencatatan retur marketplace.
 *
 * Alur: catat retur (terbit) → saat paket kembali diterima, tanggal diterima diisi
 * → artikel yang ditandai "→ stok" dikirim ke aplikasi Inventory sebagai dokumen
 * Resur dari Customer (RTB-…) yang langsung diposting, sehingga stok masuk kembali
 * lewat jalur resmi (apply_move + FIFO).
 *
 * Kalau pengiriman ke Inventory gagal (mis. database Inventory tidak bisa ditulis),
 * catatan retur TETAP tersimpan dan diberi status "Stok gagal" + tombol kirim ulang —
 * petugas tidak boleh kehilangan catatan hanya karena masalah teknis.
 * ============================================================ */

const RET_INV_NONE    = 'none';       // belum pernah dikirim ke Inventory
const RET_INV_POSTED  = 'posted';     // sudah masuk stok Inventory
const RET_INV_BLOCKED = 'blocked';    // gagal dikirim (bisa dikirim ulang)
const RET_INV_SKIPPED = 'skipped';    // sengaja tidak masuk stok (semua artikel ditandai jangan)
const RET_INV_VOID    = 'void';       // dokumen Inventory dibatalkan (penerimaan dibatalkan)

function ret_uuid(): string
{
    try {
        return bin2hex(random_bytes(16));
    } catch (Throwable $e) {
        return sha1(uniqid('', true) . mt_rand());
    }
}

function ret_find(int $id): ?array
{
    $row = ret_one('SELECT * FROM mret WHERE id = ?', [$id]);
    return $row ?: null;
}

function ret_items(int $id): array
{
    return ret_all('SELECT * FROM mitem WHERE ret_id = ? ORDER BY id', [$id]);
}

/** Ambil item banyak retur sekaligus (satu query, bukan satu per baris). */
function ret_items_map(array $ids): array
{
    $ids = array_values(array_unique(array_filter(array_map('intval', $ids), static fn($i) => $i > 0)));
    if (!$ids) return [];
    $out = [];
    foreach (array_chunk($ids, 300) as $chunk) {
        $ph = implode(',', array_fill(0, count($chunk), '?'));
        foreach (ret_all("SELECT * FROM mitem WHERE ret_id IN ($ph) ORDER BY id", $chunk) as $r) {
            $out[(int)$r['ret_id']][] = $r;
        }
    }
    return $out;
}

/** Cari retur lain dengan nomor resi yang sama (untuk peringatan dobel input). */
function ret_duplicate_resi(string $resi, int $excludeId = 0): array
{
    $resi = ret_norm_resi($resi);
    if ($resi === '') return [];
    return ret_all(
        "SELECT id, marketplace, resi, issued_date, received_date, status, buyer
           FROM mret
          WHERE UPPER(REPLACE(resi, ' ', '')) = ? AND id <> ?
          ORDER BY id DESC LIMIT 5",
        [$resi, $excludeId]
    );
}

/**
 * Baris item dari input form (SKU + qty + kondisi + tanda masuk stok).
 * Mengembalikan [baris_bersih, pesan_galat]. Baris kosong (SKU & qty kosong) diabaikan.
 */
function ret_collect_items(array $skus, array $qtys, array $conds, array $flags): array
{
    $errors = [];
    $out = [];
    /* Baris bisa dihapus/ditambah di browser, jadi kunci array tidak selalu 0..n-1:
       gabungkan semua kunci lalu proses urut naik. */
    $keys = array_unique(array_merge(array_keys($skus), array_keys($qtys), array_keys($conds), array_keys($flags)));
    sort($keys, SORT_NUMERIC);
    foreach ($keys as $i) {
        $sku = ret_norm_sku((string)($skus[$i] ?? ''));
        $qtyRaw = trim((string)($qtys[$i] ?? ''));
        if ($sku === '' && $qtyRaw === '') continue;
        if ($sku === '') {
            $errors[] = 'Ada baris yang jumlahnya diisi tetapi artikelnya kosong (baris ke-' . ((int)$i + 1) . ').';
            continue;
        }
        /* Jumlah boleh dikosongkan: artinya 1 pcs (baris baru langsung dari hasil scan).
           Jumlah yang diisi 0 / negatif tetap ditolak supaya tidak ada baris bernilai nol. */
        $qty = $qtyRaw === '' ? 1.0 : parse_num($qtyRaw);
        if ($qty <= 0) {
            $errors[] = 'Jumlah untuk artikel ' . $sku . ' harus lebih dari 0.';
            continue;
        }
        $cond = (string)($conds[$i] ?? 'bagus');
        if (!isset(ret_conditions()[$cond])) $cond = 'bagus';
        $out[] = [
            'sku' => $sku,
            'qty' => $qty,
            'condition' => $cond,
            'to_stock' => (int)($flags[$i] ?? 0) === 1 ? 1 : 0,
        ];
    }
    /* Artikel yang sama di dua baris digabung supaya stok tidak dihitung dua kali. */
    $merged = [];
    foreach ($out as $r) {
        $key = $r['sku'];
        if (isset($merged[$key])) {
            $merged[$key]['qty'] += $r['qty'];
            $merged[$key]['to_stock'] = $merged[$key]['to_stock'] === 1 || $r['to_stock'] === 1 ? 1 : 0;
            if ($merged[$key]['condition'] === 'bagus' && $r['condition'] !== 'bagus') $merged[$key]['condition'] = $r['condition'];
        } else {
            $merged[$key] = $r;
        }
    }
    return [array_values($merged), $errors];
}

/** Tandai tiap item apakah SKU-nya terdaftar di aplikasi Inventory. */
function ret_mark_known(array $items): array
{
    $skus = array_map(static fn($i) => (string)$i['sku'], $items);
    $known = ret_prod_lookup($skus);
    $info = [];
    foreach ($items as &$it) {
        $key = strtoupper((string)$it['sku']);
        $p = $known[$key] ?? null;
        $it['known'] = $p ? 1 : 0;
        $info[$key] = $p;
    }
    unset($it);
    return [$items, $info];
}

/**
 * Simpan (baru atau ubah) catatan retur.
 *
 * Mengikuti kebiasaan aplikasi Inventory: validasi gagal TIDAK redirect dan TIDAK
 * menghapus isian — pemanggil menampilkan pesan galat + isi form apa adanya.
 *
 * @param bool $pushInventory false dipakai mode uji coba import: catatan disimpan di
 *        transaksi pemanggil TANPA menyentuh stok Inventory (dry-run tidak boleh
 *        mengubah stok, walaupun transaksi lokalnya nanti dibatalkan).
 * @param bool $strict true (bawaan) = SEMUA kolom wajib diisi kecuali tanggal retur diterima
 *        (permintaan pemilik toko: paket sering baru sampai gudang beberapa hari setelah
 *        marketplace menyatakannya diterima). Import memakai false supaya berkas lama yang
 *        kolomnya belum lengkap tetap bisa masuk — kekurangannya hanya dicatat di laporan.
 * @return array{ok:bool,id:int,errors:array<int,string>,receive:?array,should_push:bool}
 */
function ret_save(?array $existing, array $data, array $items, ?int $uid, bool $pushInventory = true, bool $strict = true): array
{
    $errors = [];

    if (!empty($data['manual'])) {
        /* Retur manual tidak lewat marketplace: marketplace & kurir boleh kosong,
           nomor resi otomatis dibuat bila dikosongkan. */
        if ($data['marketplace'] !== '' && !isset(ret_markets()[$data['marketplace']])) {
            $errors[] = 'Marketplace tidak dikenal.';
        }
    } elseif (!isset(ret_markets()[$data['marketplace']])) {
        $errors[] = 'Marketplace belum dipilih.';
    } else {
        if ($data['resi'] === '') {
            $errors[] = 'Nomor resi belum diisi.';
        }
        if ($strict && trim((string)($data['courier'] ?? '')) === '') {
            $errors[] = 'Kurir belum diisi (contoh: JNE, J&T, SiCepat, Shopee Express).';
        }
    }
    /* Nama pembeli WAJIB (permintaan pemilik toko): laporan "pembeli sering retur"
       tidak ada gunanya kalau barisnya tanpa nama. */
    if (trim((string)($data['buyer'] ?? '')) === '') {
        $errors[] = 'Nama pembeli belum diisi.';
    }
    if ($strict) {
        /* Kelengkapan kolom diputuskan sekali saja, saat data pertama kali dicatat. Saat
           mengubah catatan lama (mis. hasil import yang kolomnya belum lengkap) pengguna tidak
           dipaksa mengisi ulang: nilai lama dipertahankan, dan yang benar-benar belum ada
           dilaporkan sebagai galat supaya tetap lengkap saat dibuat baru. */
        $wajib = [
            'order_no' => 'Nomor pesanan belum diisi (ada di halaman pesanan marketplace).',
            'courier' => 'Kurir belum diisi (contoh: JNE, J&T, SiCepat, Shopee Express).',
            'reason' => 'Alasan retur belum diisi.',
        ];
        if (!empty($data['manual'])) {
            /* Retur manual: kurir opsional (mungkin bukan pengiriman marketplace). */
            unset($wajib['courier']);
        }
        foreach ($wajib as $key => $pesan) {
            $val = trim((string)($data[$key] ?? ''));
            $old = trim((string)($existing[$key] ?? ''));
            if ($val === '' && $old !== '') {
                $data[$key] = $old;           // jangan menghapus isian lama tanpa alasan
                continue;
            }
            if ($val === '') $errors[] = $pesan;
        }
    }
    if ($data['issued_date'] === '') {
        $errors[] = 'Tanggal retur terbit belum diisi atau formatnya tidak dikenali (contoh: 31/01/2026).';
    }
    if ($data['received_date_raw'] !== '' && $data['received_date'] === '') {
        $errors[] = 'Tanggal retur diterima formatnya tidak dikenali (contoh: 31/01/2026).';
    }
    if (!$items) {
        $errors[] = 'Belum ada artikel yang diisi. Scan atau ketik minimal satu artikel.';
    }
    if ($errors) return ['ok' => false, 'id' => (int)($existing['id'] ?? 0), 'errors' => $errors, 'receive' => null];

    /* Nomor resi selalu dinormalkan di lapisan ini (huruf besar, tanpa spasi) supaya
       pencarian & peringatan resi dobel konsisten, dari mana pun fungsinya dipanggil.
       Retur manual (bukan dari marketplace) boleh tanpa resi — tandai sebagai manual. */
    $data['manual'] = !empty($data['manual']) ? 1 : 0;
    if ($data['manual'] === 1) {
        $data['source'] = 'manual';
        if ($data['resi'] === '') {
            $data['resi'] = 'MANUAL-' . date('Ymd') . '-' . strtoupper(substr(ret_uuid(), 0, 6));
        }
    } else {
        $data['source'] = 'marketplace';
        $data['resi'] = ret_norm_resi((string)$data['resi']);
    }
    /* Tanggal diterima menurut marketplace (boleh berbeda dari tanggal paket sampai gudang). */
    $data['mk_received_date'] = ret_date_input((string)($data['mk_received_date_raw'] ?? ''));

    [$items, ] = ret_mark_known($items);

    $id = (int)($existing['id'] ?? 0);
    $locked = $existing && (string)$existing['status'] === 'received';

    $res = ret_tx(function () use ($existing, $data, $items, $uid, $id, $locked) {
        $qtyTotal = 0.0;
        foreach ($items as $it) $qtyTotal += (float)$it['qty'];

        if ($id > 0) {
            if ($locked) {
                /* Sudah diterima: tanggal & artikel tidak boleh berubah (stok di Inventory
                   sudah mengikuti angka lama). Hanya keterangan yang boleh diperbarui. */
                ret_run(
                    'UPDATE mret SET marketplace = ?, resi = ?, order_no = ?, buyer = ?, courier = ?,
                            reason = ?, note = ?, updated_by = ?, updated_at = ? WHERE id = ?',
                    [$data['marketplace'], $data['resi'], $data['order_no'], $data['buyer'], $data['courier'],
                     $data['reason'], $data['note'], $uid, now(), $id]
                );
                return ['id' => $id, 'push' => false];
            }
            ret_run(
                'UPDATE mret SET marketplace = ?, resi = ?, order_no = ?, buyer = ?, courier = ?,
                        reason = ?, note = ?, issued_date = ?, received_date = ?, status = ?,
                        qty_total = ?, manual = ?, source = ?, mk_received_date = ?,
                        updated_by = ?, updated_at = ? WHERE id = ?',
                [$data['marketplace'], $data['resi'], $data['order_no'], $data['buyer'], $data['courier'],
                 $data['reason'], $data['note'], $data['issued_date'], $data['received_date'],
                 $data['received_date'] !== '' ? 'received' : 'pending', $qtyTotal,
                 $data['manual'], $data['source'], $data['mk_received_date'], $uid, now(), $id]
            );
            ret_run('DELETE FROM mitem WHERE ret_id = ?', [$id]);
        } else {
            ret_run(
                'INSERT INTO mret (uuid, marketplace, resi, order_no, buyer, courier, reason, note,
                        issued_date, received_date, status, qty_total, manual, source, mk_received_date,
                        created_by, created_at, updated_by, updated_at)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                [ret_uuid(), $data['marketplace'], $data['resi'], $data['order_no'], $data['buyer'], $data['courier'],
                 $data['reason'], $data['note'], $data['issued_date'], $data['received_date'],
                 $data['received_date'] !== '' ? 'received' : 'pending', $qtyTotal,
                 $data['manual'], $data['source'], $data['mk_received_date'], $uid, now(), $uid, now()]
            );
            $id = (int)ret_db()->lastInsertId();
        }

        foreach ($items as $it) {
            ret_run(
                'INSERT INTO mitem (ret_id, sku, qty, condition, to_stock, known, note) VALUES (?,?,?,?,?,?,?)',
                [$id, $it['sku'], $it['qty'], $it['condition'], $it['to_stock'], (int)$it['known'], '']
            );
        }

        /* Tanggal diterima diisi langsung di form = retur sudah diterima. */
        if (!$locked && $data['received_date'] !== '') {
            ret_run('UPDATE mret SET received_by = COALESCE(received_by, ?), received_at = COALESCE(received_at, ?) WHERE id = ?',
                [$uid, now(), $id]);
            return ['id' => $id, 'push' => true];
        }
        return ['id' => $id, 'push' => false];
    });

    $receive = (!empty($res['push']) && $pushInventory) ? ret_push_inventory((int)$res['id'], $uid) : null;
    return ['ok' => true, 'id' => (int)$res['id'], 'errors' => [], 'receive' => $receive, 'should_push' => !empty($res['push'])];
}

/**
 * Pilihan per artikel: mana yang layak masuk stok jual beserta kondisinya.
 *
 * Dipakai saat tanggal retur diterima diisi — di situlah petugas gudang melihat barangnya
 * langsung dan memutuskan apa yang boleh kembali ke stok (permintaan pemilik toko).
 * Sengaja DITOLAK bila retur sudah pernah dikirim ke Inventory: stok yang sudah masuk tidak
 * boleh berubah tanpa dokumen resmi (pakai "Batalkan penerimaan" bila memang salah).
 *
 * @param array<int|string,int> $stocks item_id => 1/0 (masuk stok?)
 * @param array<int|string,string> $conds item_id => kondisi (bagus|rusak|kurang)
 * @return array{ok:bool,changed:int,errors:array<int,string>}
 */
function ret_set_item_choices(int $id, array $stocks, array $conds): array
{
    $row = ret_find($id);
    if (!$row) return ['ok' => false, 'changed' => 0, 'errors' => ['Catatan retur tidak ditemukan.']];
    if ((string)$row['status'] === 'received' && (string)$row['inv_state'] === RET_INV_POSTED) {
        return ['ok' => false, 'changed' => 0, 'errors' => ['Stok retur ini sudah masuk Inventory. '
            . 'Batalkan penerimaan lebih dulu bila ada artikel yang salah ditandai.']];
    }

    $changed = 0;
    ret_tx(function () use ($id, $stocks, $conds, &$changed) {
        foreach (ret_items($id) as $it) {
            $iid = (int)$it['id'];
            $toStock = (int)($stocks[$iid] ?? $it['to_stock']) === 1 ? 1 : 0;
            $cond = (string)($conds[$iid] ?? $it['condition']);
            if (!isset(ret_conditions()[$cond])) $cond = (string)$it['condition'];
            if ($toStock === (int)$it['to_stock'] && $cond === (string)$it['condition']) continue;
            ret_run('UPDATE mitem SET to_stock = ?, condition = ? WHERE id = ?', [$toStock, $cond, $iid]);
            $changed++;
        }
    });
    return ['ok' => true, 'changed' => $changed, 'errors' => []];
}

/**
 * Tandai retur sudah diterima (tanggal diterima diisi) lalu kirim ke Inventory.
 * @return array{ok:bool,errors:array<int,string>,push:?array}
 */
function ret_receive(int $id, string $date, ?int $uid): array
{    $row = ret_find($id);
    if (!$row) return ['ok' => false, 'errors' => ['Catatan retur tidak ditemukan.'], 'push' => null];
    $date = ret_date_input($date);
    if ($date === '') $date = today();
    if ((string)$row['status'] === 'received') {
        if ((string)$row['received_date'] === $date) return ['ok' => true, 'errors' => [], 'push' => null];
        if ((string)$row['inv_state'] === RET_INV_POSTED) {
            return ['ok' => false, 'errors' => ['Tanggal diterima tidak bisa diubah karena stoknya sudah masuk Inventory. '
                . 'Batalkan penerimaan lebih dulu bila memang salah tanggal.'], 'push' => null];
        }
    }
    ret_tx(function () use ($id, $date, $uid) {
        ret_run('UPDATE mret SET received_date = ?, status = ?, received_by = ?, received_at = ?, updated_by = ?, updated_at = ? WHERE id = ?',
            [$date, 'received', $uid, now(), $uid, now(), $id]);
    });
    return ['ok' => true, 'errors' => [], 'push' => ret_push_inventory($id, $uid)];
}

/**
 * Kirim artikel bertanda "→ stok" ke aplikasi Inventory sebagai dokumen retur yang diposting.
 * Aman dipanggil berulang: uuid disimpan di returns.pos_uuid, jadi tidak ada dokumen ganda.
 *
 * @return array{ok:bool,state:string,doc_no:string,errors:array<int,string>,skipped:array<int,string>}
 */
function ret_push_inventory(int $id, ?int $uid): array
{
    $row = ret_find($id);
    if (!$row) return ['ok' => false, 'state' => RET_INV_NONE, 'doc_no' => '', 'errors' => ['Catatan retur tidak ditemukan.'], 'skipped' => []];
    if ((string)$row['status'] !== 'received') {
        return ['ok' => false, 'state' => (string)$row['inv_state'], 'doc_no' => (string)$row['inv_doc_no'],
                'errors' => ['Retur belum ditandai diterima, jadi stok belum bisa ditambahkan.'], 'skipped' => []];
    }
    if ((string)$row['inv_state'] === RET_INV_POSTED) {
        return ['ok' => true, 'state' => RET_INV_POSTED, 'doc_no' => (string)$row['inv_doc_no'], 'errors' => [], 'skipped' => []];
    }

    $items = ret_items($id);
    $push = [];
    $skipped = [];
    foreach ($items as $it) {
        if ((int)$it['to_stock'] !== 1) { $skipped[] = (string)$it['sku']; continue; }
        $push[] = ['sku' => (string)$it['sku'], 'qty' => (float)$it['qty']];
    }

    if (!$push) {
        ret_run('UPDATE mret SET inv_state = ?, inv_error = ?, inv_at = ? WHERE id = ?',
            [RET_INV_SKIPPED, '', now(), $id]);
        return ['ok' => true, 'state' => RET_INV_SKIPPED, 'doc_no' => '', 'errors' => [], 'skipped' => $skipped];
    }

    $uuid = (string)$row['uuid'];

    /* Kalau dokumen Inventory sebelumnya sudah DIBATALKAN (void), uuid diganti supaya
       penerimaan berikutnya membuat DOKUMEN BARU. Tanpa ini, penerimaan ulang akan
       menemukan dokumen lama yang sudah void, menganggap "sudah dikirim", lalu stok
       tidak pernah kembali — stok jadi tidak sinkron tanpa peringatan. */
    $perluDokumenBaru = ((string)$row['inv_state'] === RET_INV_VOID);
    if (!$perluDokumenBaru && (int)$row['inv_return_id'] > 0 && ret_inv_ready()) {
        $st = (string)(db_scalar('SELECT status FROM returns WHERE id = ?', [(int)$row['inv_return_id']]) ?? '');
        if ($st === 'void') $perluDokumenBaru = true;
    }
    if ($perluDokumenBaru || $uuid === '') {
        $uuid = ret_uuid();
        ret_run('UPDATE mret SET uuid = ?, inv_doc_no = ?, inv_return_id = 0 WHERE id = ?', [$uuid, '', $id]);
    }

    $isManual = (int)($row['manual'] ?? 0) === 1;
    $market = $isManual ? 'Retur manual (' . ret_manual_label((string)($row['reason'] ?? '')) . ')'
                        : ret_market_label((string)$row['marketplace']);
    $party = trim($market . (($row['buyer'] ?? '') !== '' ? ' — ' . (string)$row['buyer'] : ''));
    $noteParts = [$isManual ? 'Retur manual' : 'Retur marketplace ' . $market];
    if ((string)($row['reason'] ?? '') !== '') $noteParts[] = 'alasan: ' . (string)$row['reason'];
    if ((string)($row['resi'] ?? '') !== '') $noteParts[] = 'resi: ' . (string)$row['resi'];

    $res = ret_post_return([
        'uuid' => $uuid,
        'doc_date' => (string)$row['received_date'] !== '' ? (string)$row['received_date'] : today(),
        'party' => $party,
        'ref_doc_no' => (string)$row['resi'],
        'note' => implode(' • ', $noteParts),
        'items' => $push,
    ], $uid);

    if (!empty($res['ok'])) {
        ret_run('UPDATE mret SET inv_state = ?, inv_doc_no = ?, inv_return_id = ?, inv_error = ?, inv_at = ? WHERE id = ?',
            [RET_INV_POSTED, (string)$res['doc_no'], (int)$res['return_id'], '', now(), $id]);
        return ['ok' => true, 'state' => RET_INV_POSTED, 'doc_no' => (string)$res['doc_no'], 'errors' => [], 'skipped' => $skipped];
    }

    $err = implode('; ', (array)$res['errors']);
    ret_run('UPDATE mret SET inv_state = ?, inv_error = ?, inv_at = ? WHERE id = ?',
        [RET_INV_BLOCKED, $err, now(), $id]);
    return ['ok' => false, 'state' => RET_INV_BLOCKED, 'doc_no' => '', 'errors' => (array)$res['errors'], 'skipped' => $skipped];
}

/**
 * Batalkan penerimaan retur (mis. salah menandai diterima).
 * Kalau stok sudah masuk Inventory, dokumennya di-void lewat jalur resmi Inventory
 * sehingga stok & FIFO kembali seperti sebelumnya.
 */
function ret_cancel_receive(int $id, string $reason, ?int $uid): array
{
    $row = ret_find($id);
    if (!$row) return ['ok' => false, 'errors' => ['Catatan retur tidak ditemukan.']];
    if ((string)$row['status'] !== 'received') {
        return ['ok' => false, 'errors' => ['Retur ini belum ditandai diterima.']];
    }
    $reason = trim($reason);
    if ($reason === '') return ['ok' => false, 'errors' => ['Alasan pembatalan wajib diisi.']];

    $state = (string)$row['inv_state'];
    if ($state === RET_INV_POSTED) {
        $res = ret_void_return((int)$row['inv_return_id'], $reason, $uid);
        if (empty($res['ok'])) {
            return ['ok' => false, 'errors' => array_merge(
                ['Stok belum bisa dikembalikan ke Inventory, jadi penerimaan tidak dibatalkan:'],
                (array)$res['errors']
            )];
        }
    }

    ret_tx(function () use ($id, $reason, $uid, $state) {
        ret_run(
            'UPDATE mret SET status = ?, received_date = ?, received_by = NULL, received_at = NULL,
                    canceled_by = ?, canceled_at = ?, cancel_reason = ?,
                    inv_state = ?, inv_error = ?, updated_by = ?, updated_at = ? WHERE id = ?',
            ['pending', '', $uid, now(), $reason,
             $state === RET_INV_POSTED ? RET_INV_VOID : $state,
             '', $uid, now(), $id]
        );
    });
    return ['ok' => true, 'errors' => []];
}

/** Hapus catatan retur. Hanya untuk catatan yang belum pernah masuk stok Inventory. */
function ret_delete(int $id): array
{
    $row = ret_find($id);
    if (!$row) return ['ok' => false, 'errors' => ['Catatan retur tidak ditemukan.']];
    if ((string)$row['inv_state'] === RET_INV_POSTED) {
        return ['ok' => false, 'errors' => ['Retur ini stoknya sudah masuk Inventory. Batalkan penerimaan dulu, baru hapus.']];
    }
    ret_tx(function () use ($id) {
        ret_run('DELETE FROM mitem WHERE ret_id = ?', [$id]);
        ret_run('DELETE FROM mret WHERE id = ?', [$id]);
    });
    return ['ok' => true, 'errors' => []];
}

/* ------------------------------------------------------------------ */
/* Daftar & ringkasan                                                 */
/* ------------------------------------------------------------------ */

/** Menyusun potongan WHERE dari filter halaman daftar/dashboard. */
function ret_filter_sql(array $f): array
{
    $where = ['1 = 1'];
    $params = [];

    $q = trim((string)($f['q'] ?? ''));
    if ($q !== '') {
        $like = '%' . $q . '%';
        $where[] = "(m.resi LIKE ? OR m.order_no LIKE ? OR m.buyer LIKE ? OR m.courier LIKE ? OR m.reason LIKE ? OR m.note LIKE ?
                     OR EXISTS (SELECT 1 FROM mitem i WHERE i.ret_id = m.id AND i.sku LIKE ?))";
        $params = array_merge($params, [$like, $like, $like, $like, $like, $like, $like]);
    }
    $market = (string)($f['marketplace'] ?? '');
    if ($market !== '' && isset(ret_markets()[$market])) {
        $where[] = 'm.marketplace = ?';
        $params[] = $market;
    }
    $status = (string)($f['status'] ?? '');
    if ($status === 'pending' || $status === 'received') {
        $where[] = 'm.status = ?';
        $params[] = $status;
    }
    $source = (string)($f['source'] ?? '');
    if ($source === 'manual') { $where[] = 'm.manual = 1'; }
    elseif ($source === 'marketplace') { $where[] = 'm.manual = 0'; }
    $swap = (string)($f['swap'] ?? '');
    if ($swap === 'open') { $where[] = "m.swap_state IN ('pending','received','sent')"; }
    elseif ($swap !== '') { $where[] = 'm.swap_state = ?'; $params[] = $swap; }
    if (!empty($f['inv_problem'])) {
        $where[] = "m.inv_state IN ('blocked')";
    }
    $from = (string)($f['from'] ?? '');
    if ($from !== '') { $where[] = 'm.issued_date >= ?'; $params[] = $from; }
    $to = (string)($f['to'] ?? '');
    if ($to !== '') { $where[] = 'm.issued_date <= ?'; $params[] = $to; }

    return [implode(' AND ', $where), $params];
}

/** @return array{rows:array<int,array>,items:array<int,array<int,array>>,total:int,pager:array} */
function ret_list(array $f, int $perPage = 25): array
{
    [$where, $params] = ret_filter_sql($f);
    $total = (int)ret_scalar('SELECT COUNT(*) FROM mret m WHERE ' . $where, $params);
    $p = pager($total, $perPage);
    $rows = ret_all(
        'SELECT m.* FROM mret m WHERE ' . $where . ' ORDER BY m.issued_date DESC, m.id DESC LIMIT ? OFFSET ?',
        array_merge($params, [$p['per'], $p['offset']])
    );
    return ['rows' => $rows, 'items' => ret_items_map(array_column($rows, 'id')), 'total' => $total, 'pager' => $p];
}

/** Daftar retur yang belum diterima, terlama menunggu lebih dulu. */
function ret_pending(array $f = [], int $limit = 50): array
{
    $f['status'] = 'pending';
    [$where, $params] = ret_filter_sql($f);
    $rows = ret_all(
        'SELECT m.* FROM mret m WHERE ' . $where . ' ORDER BY m.issued_date ASC, m.id ASC LIMIT ?',
        array_merge($params, [max(1, min(200, $limit))])
    );
    return ['rows' => $rows, 'items' => ret_items_map(array_column($rows, 'id'))];
}

/** Kartu ringkasan dashboard. */
function ret_stats(array $f = []): array
{
    [$where, $params] = ret_filter_sql($f);
    $row = ret_one(
        "SELECT COUNT(*) AS total,
                SUM(CASE WHEN m.status = 'received' THEN 1 ELSE 0 END) AS received,
                SUM(CASE WHEN m.status = 'pending' THEN 1 ELSE 0 END) AS pending,
                SUM(CASE WHEN m.inv_state = 'blocked' THEN 1 ELSE 0 END) AS blocked,
                COALESCE(SUM(m.qty_total), 0) AS qty
           FROM mret m WHERE " . $where,
        $params
    ) ?: [];

    /* Umur & rata-rata tunggu dihitung dari TANGGAL (bukan jam) supaya tidak muncul
       angka pecahan seperti 4,9 hari hanya karena selisih jam UTC dengan jam lokal. */
    $open = ret_one(
        "SELECT COUNT(*) AS n, MIN(m.issued_date) AS oldest,
                COALESCE(AVG(julianday(date('now','localtime')) - julianday(m.issued_date)), 0) AS avg_days
           FROM mret m WHERE m.status = 'pending'"
    ) ?: [];
    $oldest = (string)($open['oldest'] ?? '');

    /* Barang retur yang tidak kembali / rusak sering tidak sengaja dianggap stok jual —
       hitungan ini membantu pemilik toko melihat berapa banyak yang tidak layak jual. */
    $badQty = (float)(ret_scalar(
        "SELECT COALESCE(SUM(i.qty), 0) FROM mitem i JOIN mret m ON m.id = i.ret_id
          WHERE i.condition <> 'bagus' AND m.status = 'received' AND " . $where,
        $params
    ) ?? 0);

    return [
        'total' => (int)($row['total'] ?? 0),
        'received' => (int)($row['received'] ?? 0),
        'pending' => (int)($row['pending'] ?? 0),
        'blocked' => (int)($row['blocked'] ?? 0),
        'qty' => (float)($row['qty'] ?? 0),
        'pending_all' => (int)($open['n'] ?? 0),
        'oldest_date' => $oldest,
        'oldest_days' => $oldest !== '' ? ret_age_days($oldest) : 0,
        'avg_days' => round((float)($open['avg_days'] ?? 0), 1),
        'bad_qty' => $badQty,
    ];
}

/** Rekap per marketplace (jumlah retur & yang belum diterima) untuk grafik dashboard. */
function ret_market_stats(array $f = []): array
{
    [$where, $params] = ret_filter_sql($f);
    $rows = ret_all(
        "SELECT m.marketplace AS mk,
                COUNT(*) AS total,
                SUM(CASE WHEN m.status = 'received' THEN 1 ELSE 0 END) AS received,
                SUM(CASE WHEN m.status = 'pending' THEN 1 ELSE 0 END) AS pending,
                COALESCE(SUM(m.qty_total), 0) AS qty
           FROM mret m WHERE " . $where . ' GROUP BY m.marketplace',
        $params
    );
    $byMk = [];
    foreach ($rows as $r) $byMk[(string)$r['mk']] = $r;

    $out = [];
    foreach (ret_markets() as $code => $label) {
        $r = $byMk[$code] ?? null;
        $out[$code] = [
            'code' => $code,
            'label' => $label,
            'total' => (int)($r['total'] ?? 0),
            'received' => (int)($r['received'] ?? 0),
            'pending' => (int)($r['pending'] ?? 0),
            'qty' => (float)($r['qty'] ?? 0),
        ];
    }
    return $out;
}

/**
 * Teks konfirmasi tombol cepat "Terima" (dipakai daftar & dashboard).
 * Menyebut artikel mana yang akan masuk stok, supaya tombol cepat tetap aman dipakai
 * tanpa membuka halaman rincian.
 */
function ret_quick_receive_confirm(array $row, array $items): string
{
    $masuk = [];
    $tahan = [];
    foreach ($items as $it) {
        $label = (string)$it['sku'] . ' ×' . fmt_qty($it['qty']);
        if ((int)$it['to_stock'] === 1) $masuk[] = $label; else $tahan[] = $label;
    }
    $txt = 'Tandai retur ' . (string)$row['resi'] . ' DITERIMA hari (' . fmt_date(today()) . ')?\n\n';
    if ($masuk) {
        $txt .= 'Masuk stok Inventory: ' . implode(', ', $masuk) . '\n';
    } else {
        $txt .= 'Tidak ada artikel yang ditandai masuk stok, jadi stok Inventory tidak berubah.\n';
    }
    if ($tahan) {
        $txt .= 'Tidak masuk stok: ' . implode(', ', $tahan) . '\n';
    }
    $txt .= '\nTanggal & pilihan per artikel bisa diubah dari halaman rinciannya.';
    return $txt;
}

/** SKU yang paling sering diretur pada periode terpilih, lengkap dengan PEMBELI-nya. */
function ret_top_sku(array $f = [], int $limit = 8): array
{
    [$where, $params] = ret_filter_sql($f);
    $limit = max(1, min(50, $limit));
    $rows = ret_all(
        "SELECT i.sku, COUNT(DISTINCT m.id) AS docs, COALESCE(SUM(i.qty), 0) AS qty,
                SUM(CASE WHEN i.condition <> 'bagus' THEN 1 ELSE 0 END) AS bad
           FROM mitem i JOIN mret m ON m.id = i.ret_id
          WHERE " . $where . '
          GROUP BY i.sku ORDER BY docs DESC, qty DESC, i.sku LIMIT ?',
        array_merge($params, [$limit])
    );
    if (!$rows) return [];
    $buyers = ret_sku_buyers(array_map(static fn($r) => (string)$r['sku'], $rows), $f);
    foreach ($rows as &$r) {
        $r['buyers'] = $buyers[strtoupper((string)$r['sku'])] ?? [];
    }
    unset($r);
    return $rows;
}

/**
 * Pembeli yang paling sering meretur, per SKU (untuk keterangan di tabel
 * "artikel paling sering diretur"): siapa yang mengembalikan barang itu.
 *
 * @param array<int,string> $skus daftar SKU (hasil ret_top_sku)
 * @return array<string,array<int,array{buyer:string,docs:int,qty:float}>> kunci = SKU huruf besar
 */
function ret_sku_buyers(array $skus, array $f = [], int $per = 2): array
{
    $skus = array_values(array_unique(array_filter(array_map(static fn($s) => strtoupper(trim((string)$s)), $skus))));
    if (!$skus) return [];
    [$where, $params] = ret_filter_sql($f);
    $ph = implode(',', array_fill(0, count($skus), '?'));
    $rows = ret_all(
        "SELECT UPPER(i.sku) AS sku, m.buyer AS buyer, COUNT(DISTINCT m.id) AS docs, COALESCE(SUM(i.qty), 0) AS qty
           FROM mitem i JOIN mret m ON m.id = i.ret_id
          WHERE " . $where . " AND UPPER(i.sku) IN ($ph) AND TRIM(m.buyer) <> ''
          GROUP BY UPPER(i.sku), m.buyer
          ORDER BY docs DESC, qty DESC, m.buyer",
        array_merge($params, $skus)
    );
    $out = [];
    foreach ($rows as $r) {
        $key = (string)$r['sku'];
        if (count($out[$key] ?? []) >= $per) continue;   // cukup beberapa nama teratas per SKU
        $out[$key][] = [
            'buyer' => (string)$r['buyer'],
            'docs' => (int)$r['docs'],
            'qty' => (float)$r['qty'],
        ];
    }
    return $out;
}

/**
 * Peringkat PEMBELI yang paling sering meretur — dipakai untuk mengenali pembeli
 * bermasalah. Satu baris per nama pembeli (nama dibandingkan tanpa peduli huruf
 * besar/kecil dan spasi ganda).
 *
 * @return array<int,array{buyer:string,docs:int,qty:float,skus:int,bad:int,last_date:string}>
 */
function ret_top_buyer(array $f = [], int $limit = 10): array
{
    [$where, $params] = ret_filter_sql($f);
    $limit = max(1, min(50, $limit));
    return ret_all(
        "SELECT TRIM(m.buyer) AS buyer,
                COUNT(DISTINCT m.id) AS docs,
                COALESCE(SUM(m.qty_total), 0) AS qty,
                COUNT(DISTINCT i.sku) AS skus,
                COALESCE(SUM(CASE WHEN i.condition <> 'bagus' THEN 1 ELSE 0 END), 0) AS bad,
                MAX(m.issued_date) AS last_date
           FROM mret m LEFT JOIN mitem i ON i.ret_id = m.id
          WHERE " . $where . " AND TRIM(m.buyer) <> ''
          GROUP BY UPPER(TRIM(m.buyer))
          ORDER BY docs DESC, qty DESC, buyer
          LIMIT ?",
        array_merge($params, [$limit])
    );
}

/** Daftar seluruh retur untuk export (tanpa pembatasan halaman), item digabung per catatan. */
function ret_export_rows(array $f = []): array
{
    [$where, $params] = ret_filter_sql($f);
    $rows = ret_all('SELECT m.* FROM mret m WHERE ' . $where . ' ORDER BY m.issued_date, m.id', $params);
    if (!$rows) return [];
    $items = ret_items_map(array_column($rows, 'id'));
    $out = [];
    foreach ($rows as $r) {
        $its = $items[(int)$r['id']] ?? [];
        $delay = ret_delay_days($r);
        $isManual = (int)($r['manual'] ?? 0) === 1;
        $alasan = $isManual ? ret_manual_label((string)$r['reason']) : (string)$r['reason'];
        $tukar = '';
        if ((string)($r['swap_from_sku'] ?? '') !== '') {
            $tukar = (string)$r['swap_from_sku'] . ' → ' . ((string)$r['swap_to_sku'] !== '' ? (string)$r['swap_to_sku'] : '(pengganti belum ditentukan)');
            if ((string)($r['swap_doc_no'] ?? '') !== '') $tukar .= ' [' . (string)$r['swap_doc_no'] . ']';
        }
        $base = [
            'resi' => (string)$r['resi'],
            'sumber' => $isManual ? 'Retur manual' : 'Marketplace',
            'marketplace' => ret_market_label((string)$r['marketplace']),
            'tanggal_terbit' => (string)$r['issued_date'],
            'klaim_diterima' => (string)($r['mk_received_date'] ?? ''),
            'tanggal_diterima' => (string)$r['received_date'],
            'selisih_hari' => $delay ?? '',
            'umur_hari' => ret_age_days((string)$r['issued_date'],
                (string)$r['status'] === 'received' && (string)$r['received_date'] !== '' ? (string)$r['received_date'] : null),
            'status' => (string)$r['status'] === 'received' ? 'Diterima' : 'Belum diterima',
            'pembeli' => (string)$r['buyer'],
            'no_pesanan' => (string)$r['order_no'],
            'kurir' => (string)$r['courier'],
            'alasan' => $alasan,
            'catatan' => (string)$r['note'],
            'stok' => match ((string)$r['inv_state']) {
                RET_INV_POSTED => 'Masuk stok ' . (string)$r['inv_doc_no'],
                RET_INV_BLOCKED => 'Gagal: ' . (string)$r['inv_error'],
                RET_INV_VOID => 'Dibatalkan',
                RET_INV_SKIPPED => 'Tanpa stok',
                default => 'Belum masuk stok',
            },
            'tukar' => $tukar,
        ];
        if (!$its) {
            $out[] = $base + ['sku' => '', 'qty' => 0, 'kondisi' => '', 'masuk_stok' => ''];
            continue;
        }
        foreach ($its as $it) {
            $out[] = $base + [
                'sku' => (string)$it['sku'],
                'qty' => (float)$it['qty'],
                'kondisi' => ret_cond_label((string)$it['condition']),
                'masuk_stok' => (int)$it['to_stock'] === 1 ? 'Ya' : 'Tidak',
            ];
        }
    }
    return $out;
}

/* ------------------------------------------------------------------ */
/* Retur manual & tukar size                                          */
/* ------------------------------------------------------------------ */

/** @return array{ok:bool,id:int,errors:array<int,string>,receive:?array,should_push:bool} */
function ret_save_manual(array $data, array $items, ?int $uid): array
{
    $data['manual'] = 1;
    return ret_save(null, $data, $items, $uid);
}

/** Kategori retur manual yang memicu alur tukar size. */
function ret_is_swap(string $reasonCode): bool
{
    return $reasonCode === 'tukar_size';
}

/**
 * Simpan data penukaran size pada retur manual (artikel lama → artikel pengganti).
 *
 * Pengiriman barang pengganti TIDAK otomatis: petugas menekan tombolnya saat barang
 * benar-benar keluar. Pengiriman membuat dokumen Barang Keluar resmi di aplikasi
 * Inventory (OUT-…) lewat post_document('outbound') sehingga kartu stok & HPP
 * tercatat — TIDAK dengan mengurangi stock_qty langsung.
 */
function ret_swap_save(int $id, array $data, ?int $uid): array
{
    $row = ret_find($id);
    if (!$row) return ['ok' => false, 'errors' => ['Catatan retur tidak ditemukan.']];
    if ((int)$row['manual'] !== 1) return ['ok' => false, 'errors' => ['Penukaran size hanya untuk retur manual.']];
    if ((string)$row['swap_state'] === 'done') return ['ok' => false, 'errors' => ['Penukaran ini sudah selesai.']];

    $fromSku = ret_norm_sku((string)($data['from_sku'] ?? (string)$row['swap_from_sku']));
    $toSku = ret_norm_sku((string)($data['to_sku'] ?? ''));
    if ($fromSku === '' || $toSku === '') {
        return ['ok' => false, 'errors' => ['Artikel lama & artikel pengganti wajib diisi.']];
    }
    if ($fromSku === $toSku) {
        return ['ok' => false, 'errors' => ['Artikel pengganti tidak boleh sama dengan artikel lama.']];
    }

    $found = ret_prod_lookup([$fromSku, $toSku]);
    $from = $found[$fromSku] ?? null;
    $to = $found[$toSku] ?? null;
    $errors = [];
    if (!$from) $errors[] = 'Artikel lama ' . $fromSku . ' belum terdaftar di Inventory.';
    if (!$to) $errors[] = 'Artikel pengganti ' . $toSku . ' belum terdaftar di Inventory.';
    if ($errors) return ['ok' => false, 'errors' => $errors];

    $qty = max(1.0, (float)($data['qty'] ?? 0));
    ret_tx(function () use ($id, $fromSku, $toSku, $qty, $uid, $row) {
        ret_run(
            'UPDATE mret SET swap_from_sku = ?, swap_to_sku = ?, swap_qty = ?, swap_state = ?,
                    updated_by = ?, updated_at = ? WHERE id = ?',
            [$fromSku, $toSku, $qty,
             (string)$row['swap_state'] !== '' ? (string)$row['swap_state'] : 'pending',
             $uid, now(), $id]
        );
    });

    return ['ok' => true, 'errors' => [], 'from' => $from, 'to' => $to, 'qty' => $qty];
}

/**
 * Kirim barang pengganti: membuat dokumen Barang Keluar (OUT-…) yang langsung diposting
 * di aplikasi Inventory. Dipanggil saat barang pengganti benar-benar keluar gudang.
 */
function ret_swap_send(int $id, ?int $uid): array
{
    $row = ret_find($id);
    if (!$row) return ['ok' => false, 'errors' => ['Catatan retur tidak ditemukan.']];
    if ((int)$row['manual'] !== 1 || (string)$row['reason'] !== 'tukar_size') {
        return ['ok' => false, 'errors' => ['Pengiriman pengganti hanya untuk retur manual jenis tukar size.']];
    }
    if ((string)$row['swap_state'] === 'sent' || (string)$row['swap_state'] === 'done') {
        return ['ok' => false, 'errors' => ['Barang pengganti untuk retur ini sudah pernah dikirim (' . (string)$row['swap_doc_no'] . ').']];
    }
    $toSku = (string)$row['swap_to_sku'];
    $fromSku = (string)$row['swap_from_sku'];
    if ($toSku === '' || $fromSku === '') {
        return ['ok' => false, 'errors' => ['Artikel pengganti belum ditentukan. Simpan dulu datanya.']];
    }
    if (!ret_inv_ready()) {
        return ['ok' => false, 'errors' => ['Database Inventory tidak tersedia, jadi barang keluar tidak bisa dicatat.']];
    }

    $qty = (float)($row['swap_qty'] ?? 0);
    if ($qty <= 0) $qty = 1.0;

    /* Isi barang keluar langsung di dalam transaksi Inventori, lalu posting. */
    try {
        $doc = db_tx(function () use ($row, $toSku, $qty, $uid) {
            $p = product_by_sku($toSku);
            if (!$p) throw new RuntimeException('Artikel pengganti ' . $toSku . ' tidak ditemukan di Inventory.');
            $docNo = next_doc_no('outbound', 'OUT', today());
            db_run(
                'INSERT INTO outbounds (doc_no, doc_date, destination, channel, note, status, created_by, created_at)
                 VALUES (?,?,?,?,?,?,?,?)',
                [$docNo, today(), 'Pengganti tukar size — ' . (string)$row['buyer'],
                 'RETUR', 'Pengganti retur ' . (string)$row['resi'] . ' (barang lama: ' . (string)$row['swap_from_sku'] . ')',
                 'draft', $uid, now()]
            );
            $docId = (int)db()->lastInsertId();
            $price = (float)db_scalar('SELECT sell_price FROM products WHERE id = ?', [(int)$p['id']]);
            db_run(
                'INSERT INTO outbound_items (outbound_id, product_id, qty, unit_price, subtotal) VALUES (?,?,?,?,?)',
                [$docId, (int)$p['id'], $qty, $price, $qty * $price]
            );
            recalc_doc_totals('outbound', $docId);
            return ['id' => $docId, 'doc_no' => $docNo];
        });

        $post = post_document('outbound', (int)$doc['id']);
        if (empty($post['ok'])) {
            throw new RuntimeException(implode('; ', (array)$post['errors']));
        }

        ret_tx(function () use ($id, $doc, $uid) {
            ret_run(
                'UPDATE mret SET swap_state = ?, swap_doc_no = ?, updated_by = ?, updated_at = ? WHERE id = ?',
                ['sent', (string)$doc['doc_no'], $uid, now(), $id]
            );
        });

        return ['ok' => true, 'errors' => [], 'doc_no' => (string)$doc['doc_no']];
    } catch (Throwable $e) {
        return ['ok' => false, 'errors' => [$e->getMessage()]];
    }
}

/** Tandai penukaran selesai / dibatalkan (tanpa menyentuh stok). */
function ret_swap_mark(int $id, string $state, ?int $uid): array
{
    if (!isset(ret_swap_states()[$state])) return ['ok' => false, 'errors' => ['Keadaan penukaran tidak dikenal.']];
    $row = ret_find($id);
    if (!$row) return ['ok' => false, 'errors' => ['Catatan retur tidak ditemukan.']];
    ret_tx(function () use ($id, $state, $uid) {
        ret_run('UPDATE mret SET swap_state = ?, updated_by = ?, updated_at = ? WHERE id = ?', [$state, $uid, now(), $id]);
    });
    return ['ok' => true, 'errors' => []];
}

/* ------------------------------------------------------------------ */
/* Tiket kendala marketplace                                          */
/* ------------------------------------------------------------------ */

function ret_ticket_find(int $id): ?array
{
    $row = ret_one('SELECT * FROM mticket WHERE id = ?', [$id]);
    return $row ?: null;
}

function ret_ticket_replies(int $id): array
{
    return ret_all('SELECT * FROM mticket_reply WHERE ticket_id = ? ORDER BY id DESC', [$id]);
}

function ret_ticket_filter_sql(array $f): array
{
    $where = ['1 = 1'];
    $params = [];
    $q = trim((string)($f['q'] ?? ''));
    if ($q !== '') {
        $like = '%' . $q . '%';
        $where[] = '(t.ticket_no LIKE ? OR t.order_no LIKE ? OR t.resi LIKE ? OR t.buyer LIKE ? OR t.subject LIKE ? OR t.detail LIKE ?)';
        $params = array_merge($params, [$like, $like, $like, $like, $like, $like]);
    }
    $market = (string)($f['marketplace'] ?? '');
    if ($market !== '' && isset(ret_markets()[$market])) {
        $where[] = 't.marketplace = ?';
        $params[] = $market;
    }
    $status = (string)($f['status'] ?? '');
    if ($status === 'open') {
        $where[] = "t.status IN ('open','waiting','progress')";
    } elseif ($status !== '' && isset(ret_ticket_statuses()[$status])) {
        $where[] = 't.status = ?';
        $params[] = $status;
    }
    $cat = (string)($f['category'] ?? '');
    if ($cat !== '' && isset(ret_ticket_categories()[$cat])) {
        $where[] = 't.category = ?';
        $params[] = $cat;
    }
    $from = (string)($f['from'] ?? '');
    if ($from !== '') { $where[] = 't.opened_date >= ?'; $params[] = $from; }
    $to = (string)($f['to'] ?? '');
    if ($to !== '') { $where[] = 't.opened_date <= ?'; $params[] = $to; }
    return [implode(' AND ', $where), $params];
}

/** @return array{rows:array<int,array>,total:int,pager:array} */
function ret_ticket_list(array $f, int $perPage = 25): array
{
    [$where, $params] = ret_ticket_filter_sql($f);
    $total = (int)ret_scalar('SELECT COUNT(*) FROM mticket t WHERE ' . $where, $params);
    $p = pager($total, $perPage);
    $rows = ret_all(
        'SELECT t.* FROM mticket t WHERE ' . $where . ' ORDER BY t.opened_date DESC, t.id DESC LIMIT ? OFFSET ?',
        array_merge($params, [$p['per'], $p['offset']])
    );
    return ['rows' => $rows, 'total' => $total, 'pager' => $p];
}

/**
 * Simpan tiket baru / ubah tiket lama + catat entri riwayat statusnya.
 * @return array{ok:bool,id:int,errors:array<int,string>}
 */
function ret_ticket_save(?array $existing, array $data, string $message, ?int $uid): array
{
    $errors = [];
    if (!isset(ret_markets()[$data['marketplace']])) $errors[] = 'Marketplace belum dipilih.';
    if (trim((string)$data['subject']) === '') $errors[] = 'Judul kendala belum diisi.';
    if ($data['opened_date'] === '') $errors[] = 'Tanggal tiket dibuat belum diisi atau formatnya tidak dikenali.';
    if ($data['due_date_raw'] !== '' && $data['due_date'] === '') $errors[] = 'Tanggal tenggat formatnya tidak dikenali (contoh: 31/01/2026).';
    if ($errors) return ['ok' => false, 'id' => (int)($existing['id'] ?? 0), 'errors' => $errors];

    $id = (int)($existing['id'] ?? 0);
    $status = $data['status'] ?? 'open';
    if (!isset(ret_ticket_statuses()[$status])) $status = 'open';

    $id = ret_tx(function () use ($existing, $data, $status, $message, $uid, $id) {
        $u = current_user();
        $name = (string)($u['name'] ?? '');
        if ($id > 0) {
            ret_run(
                'UPDATE mticket SET marketplace = ?, ticket_no = ?, order_no = ?, resi = ?, buyer = ?,
                        category = ?, subject = ?, detail = ?, opened_date = ?, due_date = ?, status = ?,
                        closed_date = ?, close_note = ?, refund_amount = ?, updated_by = ?, updated_at = ? WHERE id = ?',
                [$data['marketplace'], $data['ticket_no'], $data['order_no'], $data['resi'], $data['buyer'],
                 $data['category'], $data['subject'], $data['detail'], $data['opened_date'], $data['due_date'], $status,
                 $status === 'closed' || $status === 'resolved' ? ($data['closed_date'] ?: today()) : '',
                 $data['close_note'], (float)$data['refund_amount'], $uid, now(), $id]
            );
        } else {
            ret_run(
                'INSERT INTO mticket (uuid, marketplace, ticket_no, order_no, resi, buyer, category, subject, detail,
                        opened_date, due_date, status, refund_amount, created_by, created_at, updated_by, updated_at)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                [ret_uuid(), $data['marketplace'], $data['ticket_no'], $data['order_no'], $data['resi'], $data['buyer'],
                 $data['category'], $data['subject'], $data['detail'], $data['opened_date'], $data['due_date'], $status,
                 (float)$data['refund_amount'], $uid, now(), $uid, now()]
            );
            $id = (int)ret_db()->lastInsertId();
        }

        /* Riwayat: entri pertama otomatis dibuat, sisanya hanya bila pengguna menulis catatan. */
        $hasAny = (int)ret_scalar('SELECT COUNT(*) FROM mticket_reply WHERE ticket_id = ?', [$id]);
        if ($hasAny === 0 || trim((string)$message) !== '') {
            ret_run(
                'INSERT INTO mticket_reply (ticket_id, at, by_user, by_name, status, message) VALUES (?,?,?,?,?,?)',
                [$id, now(), $uid, $name, $status, trim((string)$message)]
            );
        }
        return $id;
    });

    return ['ok' => true, 'id' => $id, 'errors' => []];
}

/** Tambah entri riwayat + ubah status tiket sekaligus (dipakai halaman rincian tiket). */
function ret_ticket_reply(int $id, string $status, string $message, ?int $uid): array
{
    $row = ret_ticket_find($id);
    if (!$row) return ['ok' => false, 'errors' => ['Tiket tidak ditemukan.']];
    if (!isset(ret_ticket_statuses()[$status])) return ['ok' => false, 'errors' => ['Status tiket tidak dikenal.']];
    if (trim($message) === '' && $status === (string)$row['status']) {
        return ['ok' => false, 'errors' => ['Tulis catatan dulu atau pilih status yang berbeda.']];
    }
    $u = current_user();
    $name = (string)($u['name'] ?? '');
    ret_tx(function () use ($id, $status, $message, $uid, $name) {
        ret_run(
            'INSERT INTO mticket_reply (ticket_id, at, by_user, by_name, status, message) VALUES (?,?,?,?,?,?)',
            [$id, now(), $uid, $name, $status, trim($message)]
        );
        ret_run(
            'UPDATE mticket SET status = ?, closed_date = ?, closed_by = ?, closed_at = ?, updated_by = ?, updated_at = ?
              WHERE id = ?',
            [$status,
             $status === 'closed' || $status === 'resolved' ? today() : '',
             $status === 'closed' || $status === 'resolved' ? $uid : null,
             $status === 'closed' || $status === 'resolved' ? now() : null,
             $uid, now(), $id]
        );
    });
    return ['ok' => true, 'errors' => []];
}

function ret_ticket_delete(int $id): array
{
    $row = ret_ticket_find($id);
    if (!$row) return ['ok' => false, 'errors' => ['Tiket tidak ditemukan.']];
    ret_tx(function () use ($id) {
        ret_run('DELETE FROM mticket_reply WHERE ticket_id = ?', [$id]);
        ret_run('DELETE FROM mticket WHERE id = ?', [$id]);
    });
    return ['ok' => true, 'errors' => []];
}

/** Kartu ringkasan tiket (untuk dashboard). */
function ret_ticket_stats(): array
{
    $row = ret_one(
        "SELECT COUNT(*) AS total,
                SUM(CASE WHEN status IN ('open','waiting','progress') THEN 1 ELSE 0 END) AS open,
                SUM(CASE WHEN status = 'waiting' THEN 1 ELSE 0 END) AS waiting,
                SUM(CASE WHEN status IN ('resolved','closed') THEN 1 ELSE 0 END) AS closed,
                MIN(CASE WHEN status IN ('open','waiting','progress') THEN opened_date END) AS oldest,
                COALESCE(SUM(CASE WHEN status IN ('resolved','closed') THEN refund_amount END), 0) AS recovered
           FROM mticket"
    ) ?: [];
    $oldest = (string)($row['oldest'] ?? '');
    return [
        'total' => (int)($row['total'] ?? 0),
        'open' => (int)($row['open'] ?? 0),
        'waiting' => (int)($row['waiting'] ?? 0),
        'closed' => (int)($row['closed'] ?? 0),
        'oldest_days' => $oldest !== '' ? ret_age_days($oldest) : 0,
        'oldest_date' => $oldest,
        'recovered' => (float)($row['recovered'] ?? 0),
    ];
}

/** Statistik keterlambatan pengiriman retur (diterima di marketplace vs sampai gudang). */
function ret_delay_stats(): array
{
    $rows = ret_all(
        "SELECT mk_received_date, received_date, resi, marketplace, buyer
           FROM mret
          WHERE mk_received_date <> '' AND received_date <> ''
          ORDER BY (julianday(received_date) - julianday(mk_received_date)) DESC, id DESC
          LIMIT 6"
    );
    $delays = [];
    foreach (ret_all(
        "SELECT mk_received_date, received_date FROM mret
          WHERE mk_received_date <> '' AND received_date <> ''"
    ) as $r) {
        $delays[] = ret_age_days((string)$r['mk_received_date'], (string)$r['received_date']);
    }
    $late = array_values(array_filter($delays, static fn($d) => $d > 0));
    return [
        'rows' => $rows,
        'count' => count($delays),
        'late' => count($late),
        'max' => $late ? max($late) : 0,
        'avg' => $late ? round(array_sum($late) / count($late), 1) : 0,
    ];
}
