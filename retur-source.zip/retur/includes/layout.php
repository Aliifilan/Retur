<?php
declare(strict_types=1);

/* ============================================================
 * Kerangka halaman aplikasi Monitoring Retur Marketplace.
 *
 * Tampilan: kartu kaca (glassmorphism) dengan warna indigo/violet — sama seperti
 * tema VibeCoder. Semua berkas & tautan memakai path RELATIF karena aplikasi
 * dipublikasikan pada subpath (mis. https://…/retur/).
 * ============================================================ */

function ret_nav_items(): array
{
    return [
        ['index.php', 'Dashboard', 'view'],
        ['returns.php', 'Daftar Retur', 'view'],
        ['manual.php', 'Retur Manual', 'view'],
        ['tickets.php', 'Tiket Kendala', 'view'],
        ['export.php', 'Export / Import', 'view'],
    ];
}

function ret_app_name(): string
{
    return 'Monitoring Retur';
}

/**
 * @param array{bare?:bool,width?:string,sub?:string,actions?:string,head?:string,scripts?:string,no_title?:bool} $opt
 */
function ret_page_start(string $title, string $active = '', array $opt = []): void
{
    $u = current_user();
    $bare = !empty($opt['bare']);
    $width = $opt['width'] ?? '1180';
    ?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1<?= $bare ? '' : '' ?>">
<meta name="csrf" content="<?= e(csrf_token()) ?>">
<meta name="theme-color" content="#4F46E5">
<title><?= e($title) ?> — Retur Ramdhini Store</title>
<link rel="icon" href="assets/icon.svg" type="image/svg+xml">
<link rel="stylesheet" href="assets/app.css">
<?= $opt['head'] ?? '' ?>
</head>
<body data-page="<?= e($opt['label'] ?? '') ?>">
<?php if (!$bare): ?>
<header class="topbar">
  <div class="topbar-inner">
    <a class="brand" href="index.php">
      <span class="brand-mark">R</span>
      <span class="brand-text"><strong>Retur Marketplace</strong><small>Ramdhini Store</small></span>
    </a>
    <nav class="nav">
      <?php foreach (ret_nav_items() as [$href, $label, $cap]): ?>
        <?php if (ret_can($cap)): ?>
          <a href="<?= e($href) ?>" class="nav-link <?= $active === $href ? 'is-active' : '' ?>"><?= e($label) ?></a>
        <?php endif; ?>
      <?php endforeach; ?>
      <?php if (ret_can('create')): ?>
        <a href="form.php" class="nav-link nav-add">+ Catat Retur</a>
      <?php endif; ?>
    </nav>
    <div class="who">
      <span class="who-name"><?= e($u['name'] ?? '') ?></span>
      <span class="who-role"><?= e(ret_role_label((string)($u['role'] ?? ''))) ?></span>
      <a class="btn btn-ghost btn-sm" href="logout.php">Keluar</a>
    </div>
  </div>
</header>
<?php endif; ?>
<main class="page" style="--max-w: <?= e($width) ?>px">
<?php
    foreach (take_flashes() as $f) {
        $cls = match ((string)$f['type']) {
            'error' => 'notice-error',
            'warn'  => 'notice-warn',
            'info'  => 'notice-info',
            default => 'notice-ok',
        };
        echo '<div class="notice ' . $cls . '">' . $f['msg'] . '</div>';
    }
    if (empty($opt['no_title'])) {
        echo '<div class="page-head"><h1>' . e($title) . '</h1>';
        if (!empty($opt['sub'])) echo '<p class="page-sub">' . $opt['sub'] . '</p>';
        if (!empty($opt['actions'])) echo '<div class="page-actions">' . $opt['actions'] . '</div>';
        echo '</div>';
    }
}

function ret_page_end(array $opt = []): void
{
    ?>
</main>
<footer class="foot">
  Retur Marketplace <?= e(RETUR_VERSION) ?> • stok &amp; HPP dari aplikasi Inventory
</footer>
<?= ret_cam_overlay() ?>
<?= $opt['scripts'] ?? '' ?>
</body>
</html>
<?php
}

/** Jendela kamera untuk scan barcode/QR (dipakai kolom resi & artikel). */
function ret_cam_overlay(): string
{
    return <<<HTML
<div class="cam-overlay" data-cam-overlay hidden>
  <div class="cam-box">
    <div class="cam-head">
      <strong>Scan dengan kamera</strong>
      <button type="button" class="btn btn-ghost btn-sm" data-cam-close>Tutup</button>
    </div>
    <video data-cam-video playsinline muted></video>
    <p class="cam-status" data-cam-status>Menyalakan kamera…</p>
    <p class="cam-hint">Arahkan kamera ke barcode resi atau kode artikel. Di iPhone/Safari
      fitur ini belum tersedia — pakai scanner Bluetooth/USB atau ketik langsung.</p>
  </div>
</div>
HTML;
}

/** Kotak notifikasi bergaya (dipakai formulir; isi sudah berupa HTML aman). */
function ret_notice(string $html, string $type = 'error'): string
{
    $cls = match ($type) {
        'ok'   => 'notice-ok',
        'warn' => 'notice-warn',
        'info' => 'notice-info',
        default => 'notice-error',
    };
    return '<div class="notice ' . $cls . '">' . $html . '</div>';
}

/** Ikutkan garis tepi bawah pada kartu tabel agar tabel panjang tetap terbaca. */
function ret_table_wrap(string $inner): string
{
    return '<div class="table-wrap">' . $inner . '</div>';
}
