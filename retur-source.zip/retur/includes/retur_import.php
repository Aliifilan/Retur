<?php
declare(strict_types=1);

/* ============================================================
 * Import catatan retur marketplace dari Excel (.xlsx) / CSV.
 *
 * Satu baris file = satu artikel; baris dengan NOMOR RESI yang sama digabung menjadi
 * satu catatan retur. Nomor resi yang sudah ada di aplikasi DILEWATI seluruhnya
 * (tidak ada catatan ganda).
 *
 * Mode uji coba (dry-run) menjalankan seluruh proses di dalam SATU transaksi lokal lalu
 * membatalkannya, dan **tidak pernah menyentuh stok Inventory** (pengiriman stok
 * dilewati saat uji coba) — jadi mencentang uji coba tidak bisa mengubah stok.
 * ============================================================ */

/**
 * Sinyal untuk membatalkan transaksi saat mode uji coba (dry-run).
 * Nama kelasnya sama dengan milik aplikasi Inventory supaya kedua aplikasi bisa
 * memakai pola yang sama; didefinisikan di sini karena aplikasi ini tidak memuat
 * includes/importer.php milik Inventory.
 */
if (!class_exists('DryRunSignal')) {
    class DryRunSignal extends Exception
    {
    }
}

/** Nama kolom yang dikenal (dinormalkan: huruf kecil, tanpa tanda baca). */
function ret_import_columns(): array
{
    return [
        'resi' => ['resi', 'no_resi', 'nomor_resi', 'tracking', 'tracking_number', 'no_waybill', 'waybill', 'awb'],
        'marketplace' => ['marketplace', 'market', 'channel', 'toko'],
        'tanggal_terbit' => ['tanggal_terbit', 'tgl_terbit', 'tanggal_retur_terbit', 'terbit', 'tanggal', 'tgl', 'date', 'doc_date'],
        'tanggal_diterima' => ['tanggal_diterima', 'tgl_diterima', 'tanggal_retur_diterima', 'diterima', 'received_date', 'tanggal_masuk'],
        'sku' => ['sku', 'artikel', 'kode_artikel', 'kode_barang', 'kode'],
        'qty' => ['qty', 'jumlah', 'kuantitas', 'jml', 'quantity'],
        'pembeli' => ['pembeli', 'nama_pembeli', 'buyer', 'customer', 'nama_customer', 'buyer_name'],
        'no_pesanan' => ['no_pesanan', 'nomor_pesanan', 'order', 'order_no', 'order_id', 'no_order'],
        'kurir' => ['kurir', 'courier', 'ekspedisi', 'jasa_kirim'],
        'alasan' => ['alasan', 'alasan_retur', 'reason', 'keterangan_retur'],
        'kondisi' => ['kondisi', 'kondisi_barang', 'condition', 'kondisi_brg'],
        'masuk_stok' => ['masuk_stok', 'to_stock', 'ke_stok', 'stok', 'tambah_stok'],
        'catatan' => ['catatan', 'note', 'notes', 'keterangan'],
    ];
}

/** Kolom yang wajib ada di file (satu di antaranya yang penting). */
function ret_import_required(): array
{
    return ['resi', 'sku', 'qty', 'pembeli'];
}

/** Contoh isi template import (dipakai export.php?type=template dan halaman import). */
function ret_import_template_header(): array
{
    return ['resi', 'marketplace', 'tanggal_terbit', 'tanggal_diterima', 'sku', 'qty',
            'pembeli', 'no_pesanan', 'kurir', 'alasan', 'kondisi', 'masuk_stok', 'catatan'];
}

function ret_import_template_sample(): array
{
    return ['SPXID123456789', 'Shopee', today(), '', 'JK-001', '1', 'Budi Santoso',
            '250101ABCXYZ', 'JNE', 'Salah ukuran', 'Bagus', 'Ya', 'kardus lecet'];
}

/** Normalkan kunci kolom supaya "No. Resi", "no_resi", dan "NO RESI" dianggap sama. */
function ret_import_norm_key(string $key): string
{
    return preg_replace('/[^a-z0-9]/', '', strtolower($key)) ?? '';
}

/** Ambil satu nilai dari baris import memakai daftar nama kolom yang mungkin. */
function ret_import_pick(array $row, string $field): string
{
    $map = [];
    foreach ($row as $k => $v) $map[ret_import_norm_key((string)$k)] = $v;
    foreach (ret_import_columns()[$field] ?? [] as $name) {
        $key = ret_import_norm_key($name);
        if (array_key_exists($key, $map)) {
            $val = $map[$key];
            if (is_array($val)) continue;
            return trim((string)$val);
        }
    }
    return '';
}

/**
 * Tanggal dari file import: menerima tanggal biasa maupun ANGKA SERI EXCEL
 * (mis. 46000 — hasil kolom tanggal yang diformat sebagai angka oleh Excel).
 */
function ret_import_date(string $value): string
{
    $value = trim($value);
    if ($value === '') return '';
    if (preg_match('/^\d{5}(\.\d+)?$/', $value)) {
        $d = xlsx_serial_to_date((float)$value);
        if ($d !== null) return $d;
    }
    if (preg_match('/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/', $value, $m)) {
        return sprintf('%04d-%02d-%02d', (int)$m[3], (int)$m[2], (int)$m[1]);
    }
    return parse_date_flexible($value) ?? '';
}

/** Marketplace dari teks bebas ("Shopee", "TikTok Shop", "tiktok", "Lazada"). */
function ret_import_market(string $value): string
{
    $v = strtolower(trim($value));
    if ($v === '') return '';
    if (str_contains($v, 'shopee') || $v === 'spx') return 'shopee';
    if (str_contains($v, 'tiktok') || str_contains($v, 'tik tok') || $v === 'tt') return 'tiktok';
    if (str_contains($v, 'lazada') || str_contains($v, 'lzd')) return 'lazada';
    return '';
}

/** Kondisi barang dari teks bebas; apa pun yang tidak dikenal = bagus. */
function ret_import_condition(string $value): string
{
    $v = strtolower(trim($value));
    if ($v === '') return 'bagus';
    foreach (ret_conditions() as $code => $label) {
        if ($v === $code || $v === strtolower($label)) return $code;
    }
    /* Urutan penting: "ditukar" diperiksa sebelum "rusak"/"kurang" karena sebagian berkas
       menuliskan keterangan panjang (mis. "barang ditukar, rusak ringan"). */
    if (str_contains($v, 'ditukar') || str_contains($v, 'tukar') || $v === 'exchange' || $v === 'swap') return 'ditukar';
    if (str_contains($v, 'rusak') || $v === 'broken') return 'rusak';
    if (str_contains($v, 'kurang') || str_contains($v, 'tidak lengkap') || $v === 'incomplete') return 'kurang';
    return 'bagus';
}

/** "Ya"/"Tidak"/"1"/"0" → 1/0 untuk kolom "Masuk stok" (kosong dianggap ya). */
function ret_import_flag(string $value): int
{
    $v = strtolower(trim($value));
    if ($v === '') return 1;
    if (in_array($v, ['1', 'y', 'ya', 'yes', 'true', 'masuk', 'ok', 'aktif'], true)) return 1;
    if (in_array($v, ['0', 'n', 'tidak', 'no', 'false', 'jangan', 'skip', 'tidak masuk'], true)) return 0;
    return 1;
}

/**
 * Jalankan import.
 *
 * @param array<int,array<string,string>> $rows baris mentah dari file
 * @param bool $pushInventory false = mode uji coba (stok Inventory tidak disentuh)
 * @return array{groups:int,created:int,updated:int,skipped:int,received:int,errors:array<int,string>,
 *               notes:array<int,string>,columns:array<int,string>}
 */
function ret_import_run(array $rows, ?int $uid, bool $pushInventory = true): array
{
    $report = [
        'groups' => 0, 'created' => 0, 'updated' => 0, 'skipped' => 0,
        'received' => 0, 'errors' => [], 'notes' => [], 'columns' => [],
    ];

    /* 1. Kumpulkan baris per nomor resi (urutan kemunculan dipertahankan). */
    $groups = [];
    $rowNo = 1;
    foreach ($rows as $row) {
        $rowNo++;
        $resi = ret_norm_resi(ret_import_pick($row, 'resi'));
        $sku = ret_norm_sku(ret_import_pick($row, 'sku'));
        $qtyRaw = ret_import_pick($row, 'qty');
        $buyer = ret_import_pick($row, 'pembeli');

        if ($resi === '' && $sku === '' && $buyer === '') continue;   // baris kosong
        if ($resi === '') {
            $report['errors'][] = 'Baris ' . $rowNo . ': nomor resi kosong — baris dilewati.';
            continue;
        }
        if ($sku === '') {
            $report['errors'][] = 'Baris ' . $rowNo . ' (' . $resi . '): kolom artikel/SKU kosong — baris dilewati.';
            continue;
        }
        if ($buyer === '') {
            $report['errors'][] = 'Baris ' . $rowNo . ' (' . $resi . '): nama pembeli kosong — baris dilewati '
                . '(pembeli wajib diisi).';
            continue;
        }
        $qty = $qtyRaw === '' ? 1.0 : parse_num($qtyRaw);
        if ($qty <= 0) {
            $qty = 1.0;
            $report['notes'][] = 'Baris ' . $rowNo . ' (' . $resi . '): jumlah kosong/0 dianggap 1 pcs.';
        }

        if (!isset($groups[$resi])) {
            $groups[$resi] = [
                'resi' => $resi,
                'marketplace' => '',
                'issued_date' => '',
                'received_date' => '',
                'buyer' => '',
                'order_no' => '',
                'courier' => '',
                'reason' => '',
                'note' => '',
                'items' => [],
                'row' => $rowNo,
            ];
        }
        $g = &$groups[$resi];
        /* Data kepala catatan diambil dari baris pertama yang mengisinya. */
        if ($g['marketplace'] === '') $g['marketplace'] = ret_import_market(ret_import_pick($row, 'marketplace'));
        if ($g['issued_date'] === '') $g['issued_date'] = ret_import_date(ret_import_pick($row, 'tanggal_terbit'));
        if ($g['received_date'] === '') $g['received_date'] = ret_import_date(ret_import_pick($row, 'tanggal_diterima'));
        if ($g['buyer'] === '') $g['buyer'] = $buyer;
        if ($g['order_no'] === '') $g['order_no'] = ret_import_pick($row, 'no_pesanan');
        if ($g['courier'] === '') $g['courier'] = ret_import_pick($row, 'kurir');
        if ($g['reason'] === '') $g['reason'] = ret_import_pick($row, 'alasan');
        if ($g['note'] === '') $g['note'] = ret_import_pick($row, 'catatan');
        $cond = ret_import_condition(ret_import_pick($row, 'kondisi'));
        $g['items'][] = [
            'sku' => $sku,
            'qty' => $qty,
            'condition' => $cond,
            'to_stock' => ret_import_flag(ret_import_pick($row, 'masuk_stok')),
        ];
        unset($g);
    }

    if (!$groups) {
        $report['errors'][] = 'Tidak ada baris yang bisa dibaca. Pastikan baris pertama berisi judul kolom '
            . '(minimal: ' . implode(', ', ret_import_required()) . ') dan datanya ada di baris berikutnya.';
        return $report;
    }

    /* 2. Simpan per catatan. */
    foreach ($groups as $resi => $g) {
        $report['groups']++;
        $existing = ret_one("SELECT * FROM mret WHERE UPPER(REPLACE(resi,' ','')) = ?", [$resi]);
        if ($existing) {
            $report['skipped']++;
            $report['notes'][] = 'Nomor resi ' . $resi . ' sudah ada di aplikasi — dilewati (tidak menimpa data).';
            continue;
        }

        /* PENGAMAN STOK GANDA: kalau retur dengan resi ini sudah pernah masuk sebagai dokumen
           retur di aplikasi Inventory (mis. dicatat langsung dari sana), stok TIDAK dikirim lagi —
           kalau tidak, barang yang sama akan menambah stok dua kali. */
        $alreadyInInventory = '';
        if (ret_inv_ready()) {
            $doc = db_one(
                "SELECT doc_no FROM returns WHERE type = 'customer' AND status = 'posted' AND UPPER(REPLACE(ref_doc_no,' ','')) = ? LIMIT 1",
                [$resi]
            );
            if ($doc) $alreadyInInventory = (string)$doc['doc_no'];
        }
        if ($alreadyInInventory !== '') {
            foreach ($g['items'] as &$it) $it['to_stock'] = 0;
            unset($it);
            $report['notes'][] = 'Resi ' . $resi . ': sudah ada dokumen retur ' . $alreadyInInventory
                . ' di Inventory — stoknya TIDAK ditambahkan lagi (hanya dicatat di sini).';
        }

        $market = $g['marketplace'] !== '' ? $g['marketplace'] : 'shopee';
        if ($g['marketplace'] === '') {
            $report['notes'][] = 'Resi ' . $resi . ': marketplace tidak dikenal/kosong — dianggap Shopee.';
        }
        $issued = $g['issued_date'] !== '' ? $g['issued_date'] : today();
        if ($g['issued_date'] === '') {
            $report['notes'][] = 'Resi ' . $resi . ': tanggal terbit kosong — dipakai tanggal hari ini.';
        }

        /* Berkas dari Seller Center belum tentu punya kolom no. pesanan/kurir/alasan.
           Import memakai mode longgar (strict=false) supaya data lama tetap bisa masuk,
           tetapi kekurangannya dilaporkan supaya bisa dilengkapi. */
        $kurang = [];
        foreach (['order_no' => 'no. pesanan', 'courier' => 'kurir', 'reason' => 'alasan retur'] as $key => $label) {
            if (trim((string)$g[$key]) === '') $kurang[] = $label;
        }
        if ($kurang) {
            $report['notes'][] = 'Resi ' . $resi . ': kolom ' . implode(', ', $kurang)
                . ' kosong di berkas — silakan dilengkapi lewat tombol Ubah di halaman rincian.';
        }

        $res = ret_save(null, [
            'marketplace' => $market,
            'resi' => $resi,
            'order_no' => $g['order_no'],
            'buyer' => $g['buyer'],
            'courier' => $g['courier'],
            'reason' => $g['reason'],
            'note' => $g['note'],
            'issued_date' => $issued,
            'received_date' => $g['received_date'],
            'received_date_raw' => $g['received_date'],
        ], $g['items'], $uid, $pushInventory, false);

        if (empty($res['ok'])) {
            $report['errors'][] = 'Resi ' . $resi . ': ' . implode(' ', (array)$res['errors']);
            continue;
        }
        $report['created']++;

        /* "Stok dikirim" dihitung dari barang yang MEMANG ditandai masuk stok,
           bukan sekadar adanya tanggal diterima. */
        $willPush = false;
        foreach ($g['items'] as $it) {
            if ((int)$it['to_stock'] === 1) { $willPush = true; break; }
        }
        if ($willPush) $report['received']++;
        if ($willPush && !$pushInventory) {
            $report['notes'][] = 'Resi ' . $resi . ': pada import sebenarnya stok akan ditambahkan ke Inventory '
                . '(mode uji coba tidak mengubah stok).';
        }

        $push = $res['receive'] ?? null;
        if (is_array($push) && empty($push['ok'])) {
            $report['notes'][] = 'Resi ' . $resi . ': catatan tersimpan tetapi stok BELUM masuk Inventory ('
                . implode(' ', (array)$push['errors']) . ') — pakai tombol Kirim ulang di halaman rincian.';
        } elseif (is_array($push) && !empty($push['ok']) && ($push['state'] ?? '') === RET_INV_POSTED) {
            $report['notes'][] = 'Resi ' . $resi . ': stok masuk Inventory (' . (string)$push['doc_no'] . ').';
        } elseif (is_array($push) && !empty($push['ok']) && ($push['state'] ?? '') === RET_INV_SKIPPED && $willPush) {
            $report['notes'][] = 'Resi ' . $resi . ': stok tidak dikirim (semua artikel ditandai tidak masuk stok).';
        }
    }

    return $report;
}

/**
 * Baca file unggahan menjadi baris asosiatif. Mengembalikan [kind, parsed] atau
 * melempar RuntimeException dengan pesan yang bisa dibaca pengguna.
 */
function ret_import_read_upload(array $file): array
{
    $name = (string)($file['name'] ?? '');
    $kind = sheet_kind($name);
    if ($kind === null) {
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        throw new RuntimeException($ext === 'xls'
            ? 'File .xls (format Excel lama) belum didukung. Buka di Excel lalu Simpan Sebagai → Excel Workbook (.xlsx).'
            : 'Format berkas harus Excel (.xlsx) atau CSV (.csv/.txt). Unduh template di halaman ini untuk contoh formatnya.');
    }
    $tmp = rtrim(sys_get_temp_dir(), '/') . '/retur_import_' . bin2hex(random_bytes(8)) . '.' . ($kind === 'xlsx' ? 'xlsx' : 'csv');
    if (!move_uploaded_file((string)$file['tmp_name'], $tmp)) {
        throw new RuntimeException('Berkas gagal disimpan sementara untuk diproses.');
    }
    $parsed = sheet_read($tmp, $kind);
    @unlink($tmp);
    return [$kind, $parsed];
}
