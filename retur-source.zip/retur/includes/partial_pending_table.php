<?php
declare(strict_types=1);

/* Tabel retur yang belum diterima — dipakai Dashboard & halaman Daftar Retur.
   Variabel yang harus tersedia: $rows (baris mret), $itemsMap (item per id),
   $back (nama halaman asal untuk kembali setelah aksi). */

$rows = $rows ?? [];
$itemsMap = $itemsMap ?? [];
$back = $back ?? 'returns.php';
$canReceive = ret_can('receive');
?>
<div class="table-wrap">
  <table class="table table-rows">
    <thead>
      <tr>
        <th class="age-col">Umur</th>
        <th>Terbit</th>
        <th>Marketplace</th>
        <th>Resi</th>
        <th>Artikel</th>
        <th>Pembeli</th>
        <th class="act-col">Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
        <?php
        $id = (int)$r['id'];
        $age = ret_age_days((string)$r['issued_date']);
        $its = $itemsMap[$id] ?? [];
        ?>
        <tr>
          <td><span class="age <?= e(ret_age_class($age)) ?>"><?= e(ret_age_text($age)) ?></span></td>
          <td><?= e(fmt_date((string)$r['issued_date'])) ?></td>
          <td><?= ret_market_badge((string)$r['marketplace']) ?></td>
          <td>
            <a class="sku" href="view.php?id=<?= $id ?>"><?= e((string)$r['resi']) ?></a>
            <?php if ((string)$r['order_no'] !== ''): ?>
              <div class="muted tiny">Pesanan <?= e((string)$r['order_no']) ?></div>
            <?php endif; ?>
          </td>
          <td><?= ret_items_summary($its) ?></td>
          <td><?= (string)$r['buyer'] !== '' ? e((string)$r['buyer']) : '<span class="muted">—</span>' ?></td>
          <td class="act-cell">
            <a class="btn btn-sm" href="view.php?id=<?= $id ?>">Buka</a>
            <?php if ($canReceive): ?>
              <form method="post" action="action.php" class="inline-form">
                <?= csrf_field() ?>
                <input type="hidden" name="do" value="receive">
                <input type="hidden" name="id" value="<?= $id ?>">
                <input type="hidden" name="back" value="<?= e($back) ?>">
                <button class="btn btn-sm btn-primary" type="submit"
                        data-confirm="<?= e(ret_quick_receive_confirm($r, $its)) ?>">
                  Terima
                </button>
              </form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
