<?php
declare(strict_types=1);

/* ============================================================
 * Bootstrap aplikasi Monitoring Retur Marketplace — Ramdhini Store.
 *
 * Aplikasi ini mencatat retur dari marketplace (Shopee, TikTok Shop, Lazada):
 * tanggal terbit, tanggal diterima, nomor resi, artikel, pembeli, kurir, alasan, dan
 * kondisi barang. Saat retur ditandai DITERIMA, artikel yang ditandai "→ stok"
 * dikirim ke aplikasi Inventory sebagai dokumen Retur dari Customer resmi sehingga
 * stok masuk kembali lewat jalur FIFO Inventory (lihat includes/records.php).
 *
 * Akun pengguna memakai tabel `users` aplikasi Inventory, jadi tidak ada pengguna ganda
 * yang perlu dikelola di sini.
 * ============================================================ */

require_once __DIR__ . '/inventory_bridge.php';

/* Tanpa aplikasi Inventory tidak ada akun, daftar SKU, maupun tempat menambah stok —
   tampilkan penjelasan, jangan halaman putih. */
try {
    ret_inv_boot();
} catch (Throwable $e) {
    http_response_code(503);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="id"><head><meta charset="utf-8">'
       . '<title>Monitoring Retur — Inventory tidak ditemukan</title>'
       . '<style>body{font-family:system-ui,sans-serif;background:#f3f0ff;color:#1f1b3a;padding:8vh 6vw}'
       . 'code{background:#fff;padding:2px 6px;border-radius:6px;border:1px solid #ddd}</style></head><body>'
       . '<h1>Aplikasi Inventory tidak ditemukan</h1>'
       . '<p>Aplikasi Monitoring Retur memakai akun pengguna, daftar artikel (SKU), dan stok dari aplikasi Inventory.</p>'
       . '<p>Pesan sistem: <code>' . e($e->getMessage()) . '</code></p>'
       . '</body></html>';
    exit;
}

require_once __DIR__ . '/retur_db.php';
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/records.php';
require_once __DIR__ . '/layout.php';

const RETUR_VERSION = '1.3.1';   // 1.3.1: tambah kondisi barang "Barang ditukar"
const RETUR_MAX_ITEMS = 60;    // batas baris artikel per catatan retur

ret_session_boot();
ret_db();
ret_ensure_schema();

if (PHP_SAPI !== 'cli') {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
}
