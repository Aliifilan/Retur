<?php
declare(strict_types=1);

/* ============================================================
 * Jembatan ke aplikasi Inventory — aplikasi Monitoring Retur Marketplace.
 *
 * Aplikasi ini memuat KODE aplikasi Inventory (bukan salinannya) supaya saat retur
 * marketplace diterima, stok masuk kembali lewat jalur resmi Inventory:
 * dokumen Retur dari Customer (RTB-…) → post_document('return') → apply_move()
 * → kartu stok (ledger) + FIFO/HPP.
 *
 * TIDAK ada satu baris pun di sini yang menulis products.stock_qty secara langsung.
 * Kalau database Inventory tidak bisa ditulis, retur tetap tercatat di aplikasi ini
 * dengan status "gagal dikirim" + tombol kirim ulang (jangan sampai petugas kehilangan
 * catatan hanya karena masalah hak akses berkas).
 *
 * Untuk pengujian: folder Inventory bisa diarahkan lewat env RETUR_INVENTORY_DIR dan
 * databasenya lewat env INVENTORY_DB (dipakai tests/retur_run.sh).
 * ============================================================ */

function ret_inv_dir(): string
{
    $env = getenv('RETUR_INVENTORY_DIR');
    if (is_string($env) && $env !== '') return rtrim($env, '/');
    return dirname(__DIR__, 2) . '/inventory';
}

/** Muat kode Inventory sekali. Melempar bila folder Inventory tidak ada. */
function ret_inv_boot(): void
{
    static $done = false;
    if ($done) return;
    $dir = ret_inv_dir();
    if (!is_file($dir . '/includes/docs.php')) {
        throw new RuntimeException('Folder aplikasi Inventory tidak ditemukan di ' . $dir);
    }
    require_once $dir . '/includes/helpers.php';
    require_once $dir . '/includes/db.php';
    require_once $dir . '/includes/auth.php';
    require_once $dir . '/includes/fifo.php';
    require_once $dir . '/includes/docs.php';
    /* Penulis & pembaca Excel (.xlsx) milik Inventory dipakai bersama supaya format
       export/import kedua aplikasi sama — jangan menulis penulis xlsx baru di sini. */
    require_once $dir . '/includes/xlsx.php';
    $done = true;
}

/** Apakah database Inventory siap dipakai (ada & punya tabel products)? */
function ret_inv_ready(): bool
{
    static $ok = null;
    if ($ok !== null) return $ok;
    try {
        ret_inv_boot();
        $path = db_path();
        if (!is_file($path)) return $ok = false;
        $n = (int)db_scalar("SELECT COUNT(*) FROM sqlite_master WHERE type = 'table' AND name = 'products'");
        return $ok = $n > 0;
    } catch (Throwable $e) {
        return $ok = false;
    }
}

/** Apakah database Inventory bisa ditulis (syarat stok bisa ditambahkan)? */
function ret_inv_writable(): bool
{
    if (!ret_inv_ready()) return false;
    try {
        $path = db_path();
        if (is_writable($path)) return true;
        return is_file($path . '-wal') && is_writable($path . '-wal');
    } catch (Throwable $e) {
        return false;
    }
}

/**
 * Cari beberapa produk sekaligus berdasarkan SKU (tidak peka huruf besar/kecil).
 * @return array<string,array<string,mixed>> kunci = SKU huruf besar
 */
function ret_prod_lookup(array $skus): array
{
    if (!ret_inv_ready()) return [];
    $clean = [];
    foreach ($skus as $s) {
        $s = strtoupper(trim((string)$s));
        if ($s !== '') $clean[$s] = true;
    }
    if (!$clean) return [];
    $out = [];
    foreach (array_chunk(array_keys($clean), 200) as $chunk) {
        $ph = implode(',', array_fill(0, count($chunk), '?'));
        $rows = db_all(
            "SELECT p.id, p.sku, p.unit, p.size, p.stock_qty, p.sell_price, p.cost_price, p.active,
                    COALESCE(b.name,'') AS brand
               FROM products p LEFT JOIN brands b ON b.id = p.brand_id
              WHERE UPPER(p.sku) IN ($ph)",
            $chunk
        );
        foreach ($rows as $r) $out[strtoupper((string)$r['sku'])] = $r;
    }
    return $out;
}

/** Pencarian SKU untuk saran di kolom Artikel (datalist). */function ret_prod_search(string $q, int $limit = 20): array
{
    if (!ret_inv_ready()) return [];
    $q = trim($q);
    if ($q === '') return [];
    $like = '%' . str_replace(['%', '_'], ['\\%', '\\_'], $q) . '%';
    return db_all(
        "SELECT p.sku, COALESCE(b.name,'') AS brand, p.stock_qty
           FROM products p LEFT JOIN brands b ON b.id = p.brand_id
          WHERE UPPER(p.sku) LIKE UPPER(?) ESCAPE '\\'
             OR UPPER(COALESCE(p.category,'')) LIKE UPPER(?) ESCAPE '\\'
          ORDER BY p.sku LIMIT ?",
        [$like, $like, max(1, min(100, $limit))]
    );
}

/** Nama pengguna aplikasi Inventory (untuk menampilkan "dicatat oleh"/"diterima oleh"). */
function ret_user_name(?int $id): string
{
    static $cache = [];
    $id = (int)$id;
    if ($id <= 0) return '';
    if (array_key_exists($id, $cache)) return $cache[$id];
    $name = '';
    try {
        $name = (string)(db_scalar('SELECT COALESCE(name, username) FROM users WHERE id = ?', [$id]) ?? '');
    } catch (Throwable $e) {
        $name = '';
    }
    return $cache[$id] = $name;
}

/** Tanggal dokumen Inventory yang rapi (terima format bebas, cadangan hari ini). */
function ret_inv_date(string $v): string
{
    $d = parse_date_flexible($v);
    return $d ?: today();
}

/**
 * Kirim retur ke Inventory sebagai dokumen "Retur dari Customer" yang langsung diposting
 * (stok masuk lagi dengan aturan FIFO Inventory: nilai lapisan = HPP rata-rata produk
 * saat itu, BUKAN harga jual — memakai harga jual akan memasukkan laba ke HPP).
 *
 * @param array{uuid?:string,doc_date?:string,party?:string,ref_doc_no?:string,note?:string,
 *              items?:array<int,array{sku?:string,product_id?:int,qty?:float,price?:float}>} $ret
 * @return array{ok:bool,errors:array<int,string>,doc_no:string,return_id:int,already?:bool}
 */
function ret_post_return(array $ret, ?int $userId = null): array
{
    if (!ret_inv_ready()) {
        return ['ok' => false, 'errors' => ['Database Inventory tidak tersedia.'], 'doc_no' => '', 'return_id' => 0];
    }
    $uuid = trim((string)($ret['uuid'] ?? ''));
    try {
        return db_tx(function () use ($ret, $userId, $uuid) {
            /* Kolom penanda agar pengiriman ulang tidak membuat dokumen ganda. */
            ensure_column(db(), 'returns', 'pos_uuid', "TEXT DEFAULT ''");

            if ($uuid !== '') {
                $ex = db_one('SELECT id, doc_no FROM returns WHERE pos_uuid = ?', [$uuid]);
                if ($ex) {
                    return ['ok' => true, 'errors' => [], 'doc_no' => (string)$ex['doc_no'],
                            'return_id' => (int)$ex['id'], 'already' => true];
                }
            }

            $date = ret_inv_date((string)($ret['doc_date'] ?? ''));
            $rows = [];
            $unknown = [];
            foreach ((array)($ret['items'] ?? []) as $it) {
                $sku = strtoupper(trim((string)($it['sku'] ?? '')));
                $p = $sku !== '' ? product_by_sku($sku) : null;
                if (!$p && !empty($it['product_id'])) {
                    $p = db_one('SELECT id, sku, unit, cost_price FROM products WHERE id = ?', [(int)$it['product_id']]);
                }
                if (!$p) { $unknown[] = $sku !== '' ? $sku : ('#' . (int)($it['product_id'] ?? 0)); continue; }
                $qty = (float)($it['qty'] ?? 0);
                if ($qty <= 0) continue;
                $price = round((float)($it['price'] ?? 0), 2);
                if ($price <= 0) $price = round((float)$p['cost_price'], 2);   // nilai stok yang kembali = HPP rata-rata
                $rows[] = ['pid' => (int)$p['id'], 'qty' => $qty, 'price' => $price];
            }
            if ($unknown) {
                throw new RuntimeException('SKU berikut belum terdaftar di Inventory: ' . implode(', ', array_unique($unknown)));
            }
            if (!$rows) {
                throw new RuntimeException('Tidak ada baris barang yang bisa ditambahkan ke stok Inventory.');
            }

            $totalQty = 0.0; $totalAmount = 0.0;
            foreach ($rows as $r) { $totalQty += $r['qty']; $totalAmount += $r['qty'] * $r['price']; }

            $docNo = next_doc_no('return', 'RTB', $date);
            $party = trim((string)($ret['party'] ?? '')) ?: 'Customer marketplace';
            $note = trim((string)($ret['note'] ?? '')) ?: 'Retur marketplace';

            db_run(
                'INSERT INTO returns (doc_no, doc_date, type, party, ref_doc_no, note, status, total_qty, total_amount, created_by, created_at, pos_uuid)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
                [$docNo, $date, 'customer', $party, (string)($ret['ref_doc_no'] ?? ''), $note, 'draft',
                 $totalQty, $totalAmount, $userId, now(), $uuid]
            );
            $id = (int)db()->lastInsertId();
            foreach ($rows as $r) {
                db_run(
                    'INSERT INTO return_items (return_id, product_id, qty, unit_price, subtotal, note) VALUES (?,?,?,?,?,?)',
                    [$id, $r['pid'], $r['qty'], $r['price'], $r['qty'] * $r['price'], '']
                );
            }

            $res = post_document('return', $id);
            if (empty($res['ok'])) {
                throw new RuntimeException(implode('; ', (array)($res['errors'] ?? ['gagal posting dokumen retur'])));
            }
            return ['ok' => true, 'errors' => [], 'doc_no' => $docNo, 'return_id' => $id, 'already' => false];
        });
    } catch (Throwable $ex) {
        return ['ok' => false, 'errors' => [$ex->getMessage()], 'doc_no' => '', 'return_id' => 0];
    }
}

/**
 * Batalkan dokumen retur di Inventory (dipakai saat penerimaan salah dibatalkan).
 * Memakai void_document() resmi Inventory sehingga stok & FIFO dikembalikan seperti
 * sebelum dokumen dibuat — bukan dengan mengubah stock_qty langsung.
 */
function ret_void_return(int $returnId, string $reason, ?int $userId = null): array
{
    if (!ret_inv_ready() || $returnId <= 0) {
        return ['ok' => false, 'errors' => ['Dokumen Inventory tidak ditemukan.']];
    }
    $reason = trim($reason);
    if ($reason === '') $reason = 'Penerimaan retur dibatalkan';
    try {
        $res = void_document('return', $returnId, $reason);
        return ['ok' => !empty($res['ok']), 'errors' => (array)($res['errors'] ?? []), 'doc_no' => (string)($res['doc_no'] ?? '')];
    } catch (Throwable $ex) {
        return ['ok' => false, 'errors' => [$ex->getMessage()]];
    }
}

/**
 * Kesiapan sistem untuk ditampilkan kepada pengguna.
 * @return array<int,array{0:string,1:bool,2:string}> [label, siap, keterangan]
 */
function ret_inv_health(): array
{
    $rows = [];
    $dir = ret_inv_dir();
    $rows[] = ['Folder aplikasi Inventory', is_dir($dir), $dir];
    try {
        ret_inv_boot();
        $rows[] = ['Kode Inventory dapat dimuat', true, 'includes/docs.php'];
    } catch (Throwable $e) {
        $rows[] = ['Kode Inventory dapat dimuat', false, $e->getMessage()];
        return $rows;
    }
    $path = db_path();
    $rows[] = ['Database Inventory ada', is_file($path), $path];
    $ready = ret_inv_ready();
    $rows[] = ['Database Inventory terbaca', $ready, $ready ? 'tabel products ditemukan' : 'tabel products tidak ditemukan'];
    if ($ready) {
        $n = (int)db_scalar('SELECT COUNT(*) FROM products');
        $rows[] = ['Jumlah produk', $n > 0, $n . ' SKU'];
        $w = ret_inv_writable();
        $rows[] = ['Stok bisa ditambahkan ke Inventory', $w, $w
            ? 'retur yang diterima langsung menambah stok'
            : 'periksa hak akses berkas database Inventory'];
    }
    return $rows;
}
