<?php
declare(strict_types=1);

/* ============================================================
 * Sesi & hak akses aplikasi Monitoring Retur Marketplace.
 *
 * Akun pengguna memakai tabel `users` aplikasi Inventory (username + password_hash).
 * Sesi memakai nama sendiri ('retur_sess') dan setiap request user diverifikasi ulang
 * ke tabel users aktif (lewat current_user() Inventory), jadi akun yang dinonaktifkan
 * langsung kehilangan akses.
 *
 * Role mengikuti role Inventory:
 *   admin  → semua, termasuk membatalkan penerimaan (void dokumen Inventory) & menghapus catatan salah
 *   staff  → mencatat, mengubah, dan menerima retur (tidak boleh membatalkan penerimaan)
 *   viewer → hanya melihat daftar & laporan
 * ============================================================ */

function ret_session_boot(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) return;

    /* Sebagian server tidak punya folder sesi bawaan PHP yang bisa ditulis. */
    $savePath = (string)ini_get('session.save_path');
    if (str_contains($savePath, ';')) {
        $parts = explode(';', $savePath);
        $savePath = (string)end($parts);
    }
    if ($savePath === '' || !is_dir($savePath) || !is_writable($savePath)) {
        $alt = rtrim(sys_get_temp_dir(), '/\\') . '/retur_sessions';
        if (!is_dir($alt)) { @mkdir($alt, 0700, true); }
        if (is_dir($alt) && is_writable($alt)) {
            @chmod($alt, 0700);
            session_save_path($alt);
        }
    }

    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => $https,
    ]);
    session_name('retur_sess');
    session_start();
}

/** Kemampuan per role. */
function ret_role_caps(): array
{
    return [
        'admin'  => ['*'],
        'staff'  => ['view', 'create', 'edit', 'receive'],
        'viewer' => ['view'],
    ];
}

function ret_can(string $cap): bool
{
    $u = current_user();
    if (!$u) return false;
    $perms = ret_role_caps()[(string)$u['role']] ?? [];
    return in_array('*', $perms, true) || in_array($cap, $perms, true);
}

function ret_role_label(string $role): string
{
    $map = ['admin' => 'Admin', 'staff' => 'Staf Gudang', 'viewer' => 'Pengamat'];
    return $map[$role] ?? $role;
}

function ret_require_login(): void
{
    if (!current_user()) {
        $back = basename((string)($_SERVER['SCRIPT_NAME'] ?? 'index.php'));
        $qs = (string)($_SERVER['QUERY_STRING'] ?? '');
        $_SESSION['retur_back'] = $back . ($qs !== '' ? '?' . $qs : '');
        redirect('login.php');
    }
}

/** Halaman "tidak diizinkan" (tanpa memaksa pengguna keluar). */
function ret_deny(string $what = ''): void
{
    http_response_code(403);
    $why = $what;
    require __DIR__ . '/../denied.php';
    exit;
}

function ret_require(string $cap, string $what = ''): void
{
    ret_require_login();
    if (!ret_can($cap)) ret_deny($what);
}

/** Masuk memakai akun aplikasi Inventory (fungsi do_login Inventory). */
function ret_login(string $username, string $password): bool
{
    return do_login($username, $password);
}
