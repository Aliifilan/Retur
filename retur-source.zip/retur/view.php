<?php
declare(strict_types=1);

/* ============================================================
 * Rincian satu retur: identitas, artikel, dan keadaan pengiriman stok ke Inventory.
 * ============================================================ */

require_once __DIR__ . '/includes/init.php';
ret_require_login();

$id = (int)get('id', 0);
$row = ret_find($id);
if (!$row) {
    flash('Catatan retur tidak ditemukan.', 'error');
    redirect('returns.php');
}

$items = ret_items($id);
$u = current_user();
$uid = $u ? (int)$u['id'] : null;

$received = (string)$row['status'] === 'received';
$state = (string)$row['inv_state'];
$dupes = ret_duplicate_resi((string)$row['resi'], $id);
$age = ret_age_days(
    (string)$row['issued_date'],
    $received && (string)$row['received_date'] !== '' ? (string)$row['received_date'] : null
);

$headActions = [];
if (!$received && ret_can('receive')) {
    $headActions[] = '<a class="btn" href="#terima">Tandai diterima</a>';
}
if ($received && $state !== RET_INV_POSTED && ret_can('receive')) {
    $headActions[] = '<button class="btn btn-warn" type="submit" form="formRepost">Kirim ulang ke Inventory</button>';
}
if (ret_can('edit')) {
    $headActions[] = '<a class="btn btn-primary" href="form.php?id=' . $id . '">Ubah</a>';
}

ret_page_start('Retur ' . (string)$row['resi'], 'returns.php', [
    'label'   => 'view',
    'sub'     => '<a href="returns.php">← Kembali ke daftar retur</a>',
    'actions' => implode(' ', $headActions),
]);
?>

<?php if ($dupes): ?>
  <?= ret_notice('<strong>Perhatian: nomor resi ini juga tercatat di catatan lain.</strong> Periksa apakah ini retur yang sama '
      . 'yang tercatat dua kali: '
      . implode(', ', array_map(static fn($d) => '<a href="view.php?id=' . (int)$d['id'] . '">' . e((string)$d['resi'])
          . ' — ' . e(ret_market_label((string)$d['marketplace'])) . ' ' . e(fmt_date((string)$d['issued_date'])) . '</a>', $dupes)), 'warn') ?>
<?php endif; ?>

<?php if ($state === RET_INV_BLOCKED): ?>
  <?= ret_notice('Stok untuk retur ini <strong>belum masuk Inventory</strong>: ' . e((string)$row['inv_error'])
      . '. Perbaiki penyebabnya (mis. SKU belum terdaftar di Inventory, atau database Inventory tidak bisa ditulis) '
      . 'lalu gunakan tombol <em>Kirim ulang ke Inventory</em>.', 'error') ?>
<?php endif; ?>

<section class="grid-2">
  <div class="card">
    <div class="card-head">
      <h2>Identitas retur</h2>
      <span>
        <?php if ((int)($row['manual'] ?? 0) === 1): ?>
          <span class="badge badge-muted">Retur manual</span>
        <?php else: ?>
          <?= ret_market_badge((string)$row['marketplace']) ?>
        <?php endif; ?>
        <?= ret_status_badge($row) ?>
        <?= ret_inv_badge($row) ?>
      </span>
    </div>
    <dl class="kv">
      <dt>No. resi</dt>
      <dd class="strong"><?= e((string)$row['resi']) ?></dd>
      <dt>No. pesanan</dt>
      <dd><?= (string)$row['order_no'] !== '' ? e((string)$row['order_no']) : '<span class="muted">—</span>' ?></dd>
      <dt>Tanggal retur terbit</dt>
      <dd><?= e(fmt_date((string)$row['issued_date'])) ?>
        <span class="age <?= e(ret_age_class($age)) ?>"><?= e(ret_age_text($age)) ?></span>
        <?= !$received ? '<span class="muted tiny">(sejak terbit)</span>' : '<span class="muted tiny">(lama menunggu)</span>' ?>
      </dd>
      <dt>Diterima di marketplace</dt>
      <dd><?= (string)$row['mk_received_date'] !== '' ? e(fmt_date((string)$row['mk_received_date'])) : '<span class="muted">—</span>' ?>
        <?= (string)($row['mk_received_date'] ?? '') !== '' ? '<span class="muted tiny">(menurut jasa kirim / marketplace)</span>' : '' ?></dd>
      <dt>Tanggal retur diterima</dt>
      <dd class="strong"><?= $received ? e(fmt_date((string)$row['received_date'])) : '<span class="muted">belum diterima</span>' ?>
        <?= ret_delay_badge(ret_delay_days($row)) ?></dd>
      <dt>Pembeli</dt>
      <dd><?= (string)$row['buyer'] !== '' ? e((string)$row['buyer']) : '<span class="muted">—</span>' ?></dd>
      <dt>Kurir</dt>
      <dd><?= (string)$row['courier'] !== '' ? e((string)$row['courier']) : '<span class="muted">—</span>' ?></dd>
      <dt>Alasan retur</dt>
      <dd><?= (string)$row['reason'] !== ''
        ? e((int)($row['manual'] ?? 0) === 1 ? ret_manual_label((string)$row['reason']) : (string)$row['reason'])
        : '<span class="muted">—</span>' ?></dd>
      <dt>Catatan</dt>
      <dd><?= (string)$row['note'] !== '' ? nl2br(e((string)$row['note'])) : '<span class="muted">—</span>' ?></dd>
    </dl>
  </div>

  <div class="card">
    <div class="card-head"><h2>Jejak pencatatan</h2></div>
    <dl class="kv">
      <dt>Dicatat oleh</dt>
      <dd><?= e(ret_user_name((int)($row['created_by'] ?? 0)) ?: '—') ?> • <?= e(fmt_dt((string)$row['created_at'])) ?></dd>
      <dt>Terakhir diubah</dt>
      <dd><?= (string)$row['updated_at'] !== '' ? e(ret_user_name((int)($row['updated_by'] ?? 0)) ?: '—') . ' • ' . e(fmt_dt((string)$row['updated_at'])) : '<span class="muted">—</span>' ?></dd>
      <dt>Diterima oleh</dt>
      <dd><?= !empty($row['received_at']) ? e(ret_user_name((int)($row['received_by'] ?? 0)) ?: '—') . ' • ' . e(fmt_dt((string)$row['received_at'])) : '<span class="muted">—</span>' ?></dd>
      <?php if (!empty($row['canceled_at'])): ?>
        <dt>Penerimaan dibatalkan</dt>
        <dd class="danger-text"><?= e(ret_user_name((int)($row['canceled_by'] ?? 0)) ?: '—') ?> • <?= e(fmt_dt((string)$row['canceled_at'])) ?>
          <div class="muted small">Alasan: <?= e((string)$row['cancel_reason']) ?></div>
        </dd>
      <?php endif; ?>
      <dt>Stok Inventory</dt>
      <dd>
        <?php if ($state === RET_INV_POSTED): ?>
          Dokumen <strong><?= e((string)$row['inv_doc_no']) ?></strong> sudah diposting di aplikasi Inventory
          (<?= e(fmt_dt((string)$row['inv_at'])) ?>).
        <?php elseif ($state === RET_INV_SKIPPED): ?>
          <span class="muted">Tidak ada artikel yang ditandai masuk stok — Inventory tidak diubah.</span>
        <?php elseif ($state === RET_INV_VOID): ?>
          <span class="muted">Dokumen Inventory untuk retur ini sudah dibatalkan, stok dikembalikan seperti semula.</span>
        <?php elseif ($state === RET_INV_BLOCKED): ?>
          <span class="danger-text">Gagal dikirim: <?= e((string)$row['inv_error']) ?></span>
        <?php else: ?>
          <span class="muted">Belum dikirim (retur belum ditandai diterima).</span>
        <?php endif; ?>
      </dd>
    </dl>
    <?php if ($state !== RET_INV_POSTED && $received && ret_can('receive')): ?>
      <form id="formRepost" method="post" action="action.php" class="inline-form">
        <?= csrf_field() ?>
        <input type="hidden" name="do" value="repost">
        <input type="hidden" name="id" value="<?= $id ?>">
        <input type="hidden" name="back" value="view.php">
      </form>
    <?php endif; ?>
  </div>
</section>

<section class="card">
  <div class="card-head">
    <h2>Artikel yang diretur</h2>
    <span class="muted small">Total <?= fmt_qty((float)$row['qty_total']) ?> artikel</span>
  </div>
  <?php if (!$items): ?>
    <p class="muted">Belum ada artikel pada catatan ini.</p>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table">
        <thead>
          <tr><th>Artikel / SKU</th><th class="num">Jumlah</th><th>Kondisi</th><th>Masuk stok jual</th><th>Ke Inventory</th></tr>
        </thead>
        <tbody>
          <?php foreach ($items as $it): ?>
            <tr>
              <td><a class="sku" href="returns.php?q=<?= urlencode((string)$it['sku']) ?>"><?= e((string)$it['sku']) ?></a></td>
              <td class="num"><?= fmt_qty($it['qty']) ?></td>
              <td><?= ret_cond_badge((string)$it['condition']) ?></td>
              <td><?= (int)$it['to_stock'] === 1 ? '<span class="badge badge-ok">Ya</span>' : '<span class="badge badge-muted">Tidak</span>' ?></td>
              <td><?= ret_known_badge((int)$it['known']) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <p class="muted small">
      <?php if ($received): ?>
        Artikel dengan kondisi <em>barang ditukar</em>, <em>rusak</em>, atau <em>kurang lengkap</em>
        tidak masuk stok jual — itulah yang
        disimpan saat penerimaan. Butuh diubah? Batalkan penerimaannya lebih dulu.
      <?php else: ?>
        Tanda “Masuk stok jual” masih bisa berubah: saat paket sampai, pilihannya diputuskan di bagian
        <a href="#terima">Tandai retur diterima</a> di bawah.
      <?php endif; ?>
    </p>
  <?php endif; ?>
</section>

<?php if ((int)$row['manual'] === 1 && (string)$row['reason'] === 'tukar_size'): ?>
  <section class="card">
    <div class="card-head">
      <h2>Penukaran size / model</h2>
      <span>
        <?php if ((string)$row['swap_state'] !== ''): ?>
          <span class="badge <?= (string)$row['swap_state'] === 'done' ? 'badge-ok' : ((string)$row['swap_state'] === 'canceled' ? 'badge-muted' : 'badge-warn') ?>">
            <?= e(ret_swap_label((string)$row['swap_state'])) ?>
          </span>
        <?php endif; ?>
        <?php if ((string)$row['swap_doc_no'] !== ''): ?>
          <span class="badge badge-ok">Barang keluar <?= e((string)$row['swap_doc_no']) ?></span>
        <?php endif; ?>
      </span>
    </div>
    <p class="explain">
      Barang lama kembali ke gudang (lihat bagian artikel di atas — stoknya bertambah lewat
      <em>Tandai retur diterima</em>). Barang pengganti dikirim lewat tombol di bagian ini: Inventori
      membuat dokumen <strong>Barang Keluar (OUT-…)</strong> resmi sehingga kartu stok &amp; HPP tercatat.
    </p>
    <form method="post" action="action.php" class="row-form">
      <?= csrf_field() ?>
      <input type="hidden" name="do" value="swap_save">
      <input type="hidden" name="id" value="<?= $id ?>">
      <input type="hidden" name="back" value="view.php">
      <label class="field">
        <span>Artikel lama (dikembalikan)</span>
        <input type="text" name="from_sku" value="<?= e((string)$row['swap_from_sku']) ?>" class="sku-input" autocomplete="off" spellcheck="false">
      </label>
      <label class="field">
        <span>Artikel pengganti <b class="req">*</b></span>
        <input type="text" name="to_sku" value="<?= e((string)$row['swap_to_sku']) ?>" class="sku-input" autocomplete="off" spellcheck="false"
               placeholder="mis. JK-001-L">
      </label>
      <label class="field">
        <span>Jumlah</span>
        <input type="text" inputmode="decimal" name="qty" value="<?= e(fmt_qty((float)($row['swap_qty'] ?? 0) > 0 ? (float)$row['swap_qty'] : 1)) ?>">
      </label>
      <button class="btn" type="submit">Simpan data tukar</button>
    </form>
    <?php if ((string)$row['swap_to_sku'] !== '' && !in_array((string)$row['swap_state'], ['sent', 'done', 'canceled'], true)): ?>
      <div class="form-foot" style="margin-top: 14px">
        <form method="post" action="action.php" class="inline-form">
          <?= csrf_field() ?>
          <input type="hidden" name="do" value="swap_send">
          <input type="hidden" name="id" value="<?= $id ?>">
          <input type="hidden" name="back" value="view.php">
          <button class="btn btn-primary" type="submit"
                  data-confirm="Kirim barang pengganti <?= e((string)$row['swap_to_sku']) ?> (<?= e(fmt_qty((float)($row['swap_qty'] ?? 1))) ?> pcs)?
Barang akan keluar dari stok Inventori lewat dokumen Barang Keluar resmi.">
            Kirim barang pengganti
          </button>
        </form>
        <form method="post" action="action.php" class="inline-form">
          <?= csrf_field() ?>
          <input type="hidden" name="do" value="swap_mark">
          <input type="hidden" name="id" value="<?= $id ?>">
          <input type="hidden" name="state" value="done">
          <input type="hidden" name="back" value="view.php">
          <button class="btn" type="submit" data-confirm="Tandai penukaran ini selesai?">Tandai selesai</button>
        </form>
        <form method="post" action="action.php" class="inline-form">
          <?= csrf_field() ?>
          <input type="hidden" name="do" value="swap_mark">
          <input type="hidden" name="id" value="<?= $id ?>">
          <input type="hidden" name="state" value="canceled">
          <input type="hidden" name="back" value="view.php">
          <button class="btn btn-ghost" type="submit" data-confirm="Batalkan penukaran ini? Tidak ada stok yang berubah.">Batalkan tukar</button>
        </form>
      </div>
    <?php elseif ((string)$row['swap_state'] === 'sent'): ?>
      <p class="muted small">Barang pengganti sudah dikirim (dokumen <?= e((string)$row['swap_doc_no']) ?>).
        Tandai <em>selesai</em> setelah pembeli menerimanya.</p>
      <?php if (ret_can('edit')): ?>
        <form method="post" action="action.php" class="inline-form">
          <?= csrf_field() ?>
          <input type="hidden" name="do" value="swap_mark">
          <input type="hidden" name="id" value="<?= $id ?>">
          <input type="hidden" name="state" value="done">
          <input type="hidden" name="back" value="view.php">
          <button class="btn btn-sm" type="submit" data-confirm="Tandai penukaran ini selesai?">Tandai selesai</button>
        </form>
      <?php endif; ?>
    <?php endif; ?>
  </section>
<?php endif; ?>

<?php if (!$received && ret_can('receive')): ?>
  <section class="card" id="terima">
    <div class="card-head">
      <h2>Tandai retur diterima</h2>
      <span class="muted small">Stok Inventory baru ditambahkan di langkah ini</span>
    </div>
    <p class="explain">
      Isi tanggal saat paket <strong>benar-benar sampai di gudang</strong> (bukan tanggal di sistem marketplace),
      lalu tandai artikel mana yang layak <strong>masuk stok jual</strong>. Angka stok akan dikirim ke aplikasi
      Inventory sebagai dokumen retur resmi.
    </p>
    <form method="post" action="action.php" class="receive-form" data-receive>
      <?= csrf_field() ?>
      <input type="hidden" name="do" value="receive">
      <input type="hidden" name="id" value="<?= $id ?>">
      <input type="hidden" name="back" value="view.php">

      <div class="receive-head">
        <label class="field">
          <span>Tanggal retur diterima <b class="req">*</b></span>
          <input type="date" name="date" value="<?= e(today()) ?>" required>
          <span class="hint">Tanggal ini dipakai sebagai tanggal dokumen stok di Inventory.</span>
        </label>
        <div class="receive-summary" data-receive-summary></div>
      </div>

      <?php if (!$items): ?>
        <p class="muted">Catatan ini belum punya artikel, jadi belum bisa diterima.
          <a href="form.php?id=<?= $id ?>">Isi artikelnya dulu</a>.</p>
      <?php else: ?>
        <div class="table-wrap">
          <table class="table receive-table">
            <thead>
              <tr>
                <th>Artikel / SKU</th>
                <th class="num">Jumlah</th>
                <th>Kondisi barang</th>
                <th>Masuk stok jual</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($items as $it): ?>
                <?php $iid = (int)$it['id']; ?>
                <tr>
                  <td>
                    <span class="sku"><?= e((string)$it['sku']) ?></span>
                    <?php if ((int)$it['known'] !== 1): ?>
                      <div class="tiny danger-text">Belum terdaftar di Inventory — stoknya tidak bisa ditambahkan</div>
                    <?php endif; ?>
                  </td>
                  <td class="num"><?= fmt_qty($it['qty']) ?></td>
                  <td>
                    <select name="item_cond[<?= $iid ?>]" class="cond-select">
                      <?php foreach (ret_conditions() as $code => $label): ?>
                        <option value="<?= e($code) ?>" <?= (string)$it['condition'] === $code ? 'selected' : '' ?>><?= e($label) ?></option>
                      <?php endforeach; ?>
                    </select>
                  </td>
                  <td>
                    <input type="hidden" name="item_stock[<?= $iid ?>]" value="0">
                    <label class="chk">
                      <input type="checkbox" name="item_stock[<?= $iid ?>]" value="1" class="stock-check"
                             <?= (int)$it['to_stock'] === 1 ? 'checked' : '' ?>>
                      <span><?= (int)$it['to_stock'] === 1 ? 'Ya' : 'Tidak' ?></span>
                    </label>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <p class="muted small">
          Setelah disimpan, cek <strong>stok &amp; HPP</strong> di aplikasi Inventory.
          Salah tandai? Penerimaan bisa dibatalkan (dokumen Inventory di-void) lalu diulang.
        </p>
      <?php endif; ?>

      <div class="form-foot">
        <button class="btn btn-primary" type="submit" <?= $items ? '' : 'disabled' ?>
                data-confirm="Tandai retur ini DITERIMA dan tambahkan artikel bertanda &quot;Masuk stok jual&quot; ke stok Inventory?">
          Tandai diterima &amp; tambah stok
        </button>
        <span class="muted small">Belum ada paketnya? Biarkan saja — catatan ini tetap tersimpan sebagai “belum diterima”.</span>
      </div>
    </form>
  </section>
<?php endif; ?>

<?php if ($received && ret_can('void')): ?>
  <section class="card">
    <div class="card-head"><h2>Batalkan penerimaan</h2></div>
    <p class="muted small">
      Dipakai bila retur salah ditandai diterima. Kalau stoknya sudah masuk Inventory, dokumen Inventory
      dibatalkan (void) sehingga stok &amp; HPP kembali seperti semula — stok tidak pernah diubah langsung.
    </p>
    <form method="post" action="action.php" class="row-form">
      <?= csrf_field() ?>
      <input type="hidden" name="do" value="cancel">
      <input type="hidden" name="id" value="<?= $id ?>">
      <input type="hidden" name="back" value="view.php">
      <label class="field field-grow">
        <span>Alasan pembatalan</span>
        <input type="text" name="reason" required placeholder="mis. salah paket / salah scan resi">
      </label>
      <button class="btn btn-danger" type="submit"
              data-confirm="Batalkan penerimaan retur ini? Stok yang sudah masuk Inventory akan dikembalikan.">
        Batalkan penerimaan
      </button>
    </form>
  </section>
<?php endif; ?>

<?php if (ret_can('void') && $state !== RET_INV_POSTED): ?>
  <section class="card">
    <div class="card-head"><h2>Hapus catatan</h2></div>
    <p class="muted small">Hanya bisa dihapus bila stoknya belum masuk Inventory. Catatan yang sudah pernah masuk stok
      harus dibatalkan penerimaannya lebih dulu agar jejaknya tetap ada di aplikasi Inventory.</p>
    <form method="post" action="action.php" class="row-form">
      <?= csrf_field() ?>
      <input type="hidden" name="do" value="delete">
      <input type="hidden" name="id" value="<?= $id ?>">
      <input type="hidden" name="back" value="returns.php">
      <button class="btn btn-danger" type="submit"
              data-confirm="Hapus catatan retur <?= e((string)$row['resi']) ?>? Tindakan ini tidak bisa dibatalkan.">
        Hapus catatan ini
      </button>
    </form>
  </section>
<?php endif; ?>

<?php ret_page_end(['scripts' => '<script src="assets/receive.js"></script>']); ?>
