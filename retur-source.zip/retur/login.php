<?php
declare(strict_types=1);

/** Halaman masuk — memakai akun aplikasi Inventory. */

require_once __DIR__ . '/includes/init.php';

if (current_user()) redirect('index.php');

$error = null;
$username = '';
$invMissing = !ret_inv_ready();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $username = trim((string)($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    if ($username === '' || $password === '') {
        $error = 'Nama pengguna dan kata sandi wajib diisi.';
    } elseif ($invMissing) {
        $error = 'Database aplikasi Inventory tidak ditemukan, jadi akun belum bisa diverifikasi.';
    } elseif (!ret_login($username, $password)) {
        $error = 'Nama pengguna atau kata sandi salah, atau akun sedang nonaktif.';
    } else {
        $back = (string)($_SESSION['retur_back'] ?? '');
        unset($_SESSION['retur_back']);
        redirect($back !== '' ? $back : 'index.php');
    }
}

ret_page_start('Masuk', '', ['bare' => true, 'no_title' => true, 'label' => 'login']);
?>
<section class="login-wrap">
  <form class="card login-card" method="post" action="login.php" autocomplete="off">
    <?= csrf_field() ?>
    <span class="brand-mark brand-mark-lg">R</span>
    <h1 class="login-title">Monitoring Retur</h1>
    <p class="muted login-sub">Catatan retur Shopee, TikTok Shop &amp; Lazada — resi, artikel, dan tanggal diterima.</p>

    <?php if ($invMissing): ?>
      <?= ret_notice('Berkas database aplikasi Inventory tidak ditemukan, jadi akun belum bisa diverifikasi. '
          . 'Pastikan aplikasi Inventory masih ada di ruang kerja yang sama.', 'warn') ?>
    <?php endif; ?>
    <?php if ($error !== null): ?>
      <?= ret_notice(e($error)) ?>
    <?php endif; ?>

    <label class="field">
      <span>Nama pengguna</span>
      <input type="text" name="username" value="<?= e($username) ?>" required autofocus
             <?= $invMissing ? 'disabled' : '' ?>>
    </label>
    <label class="field">
      <span>Kata sandi</span>
      <input type="password" name="password" required <?= $invMissing ? 'disabled' : '' ?>>
    </label>

    <button class="btn btn-primary btn-block" type="submit" <?= $invMissing ? 'disabled' : '' ?>>Masuk</button>
    <p class="muted small login-note">Gunakan akun yang sama seperti di aplikasi Inventory.</p>
  </form>
</section>
<?php ret_page_end(); ?>
