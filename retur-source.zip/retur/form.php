<?php
declare(strict_types=1);

/* ============================================================
 * Form catat/ubah retur marketplace.
 *
 * Semua kolom utama bisa diisi dari hasil scan kamera atau scanner Bluetooth/USB
 * (kolom resi & artikel). Sesuai kebiasaan aplikasi Inventory: kalau validasi gagal,
 * halaman TIDAK redirect dan isian TIDAK dihapus — pesan galat ditampilkan di atas form.
 * ============================================================ */

require_once __DIR__ . '/includes/init.php';
ret_require_login();

$id = (int)get('id', 0);
$existing = $id > 0 ? ret_find($id) : null;
if ($id > 0 && !$existing) {
    flash('Catatan retur tidak ditemukan.', 'error');
    redirect('returns.php');
}
if ($existing) {
    ret_require('edit', 'mengubah catatan retur');
} else {
    ret_require('create', 'mencatat retur');
}

$u = current_user();
$uid = $u ? (int)$u['id'] : null;
$locked = $existing && (string)$existing['status'] === 'received';
$errors = [];
$dupes = [];

/** Baris artikel dari data yang sudah tersimpan. */
$rowsFromDb = static function (?array $row): array {
    if (!$row) return [];
    $out = [];
    foreach (ret_items((int)$row['id']) as $it) {
        $out[] = [
            'sku' => (string)$it['sku'],
            'qty' => fmt_qty($it['qty']),
            'cond' => (string)$it['condition'],
            'stock' => (int)$it['to_stock'] === 1,
        ];
    }
    return $out;
};

/** Baris artikel dari input yang baru dikirim (dipakai saat validasi gagal). */
$rowsFromPost = static function (): array {
    $skus = (array)($_POST['item_sku'] ?? []);
    $qtys = (array)($_POST['item_qty'] ?? []);
    $conds = (array)($_POST['item_cond'] ?? []);
    $flags = (array)($_POST['item_stock'] ?? []);
    $keys = array_unique(array_merge(array_keys($skus), array_keys($qtys), array_keys($conds), array_keys($flags)));
    sort($keys, SORT_NUMERIC);
    $out = [];
    foreach ($keys as $i) {
        $sku = trim((string)($skus[$i] ?? ''));
        $qty = trim((string)($qtys[$i] ?? ''));
        if ($sku === '' && $qty === '') continue;
        $out[] = [
            'sku' => $sku,
            'qty' => $qty,
            'cond' => (string)($conds[$i] ?? 'bagus'),
            'stock' => (int)($flags[$i] ?? 0) === 1,
        ];
    }
    return $out;
};

/* ---------------- nilai awal form ---------------- */

$form = [
    'marketplace' => 'shopee',
    'resi' => '',
    'order_no' => '',
    'buyer' => '',
    'courier' => '',
    'reason' => '',
    'note' => '',
    'issued_date' => today(),
    'received_date' => '',
    'mk_received_date' => '',
];
$rows = [];
$postedRawDates = ['issued_date' => '', 'received_date' => '', 'mk_received_date' => ''];

if ($existing) {
    foreach ($form as $k => $_) $form[$k] = (string)($existing[$k] ?? '');
    $rows = $rowsFromDb($existing);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $postedRawDates = [
        'issued_date' => trim((string)post('issued_date')),
        'received_date' => trim((string)post('received_date_raw')),
        'mk_received_date' => trim((string)post('mk_received_date_raw')),
    ];
    $form = [
        'marketplace' => (string)post('marketplace', 'shopee'),
        'resi' => (string)post('resi'),
        'order_no' => (string)post('order_no'),
        'buyer' => (string)post('buyer'),
        'courier' => (string)post('courier'),
        'reason' => (string)post('reason'),
        'note' => (string)post('note'),
        'issued_date' => ret_date_input((string)post('issued_date')) ?: trim((string)post('issued_date')),
        'received_date' => ret_date_input((string)post('received_date_raw')),
    ];
    $items = ret_collect_items(
        (array)post('item_sku', []),
        (array)post('item_qty', []),
        (array)post('item_cond', []),
        (array)post('item_stock', [])
    );
    [$items, $itemErrors] = $items;

    $data = [
        'marketplace' => $form['marketplace'],
        'resi' => ret_norm_resi($form['resi']),
        'order_no' => trim($form['order_no']),
        'buyer' => trim($form['buyer']),
        'courier' => trim($form['courier']),
        'reason' => trim($form['reason']),
        'note' => trim($form['note']),
        'issued_date' => ret_date_input($postedRawDates['issued_date']),
        'received_date' => ret_date_input($postedRawDates['received_date']),
        'received_date_raw' => $postedRawDates['received_date'],
        'mk_received_date_raw' => $postedRawDates['mk_received_date'],
    ];

    $res = ret_save($existing, $data, $items, $uid);
    $errors = array_merge($itemErrors, $res['errors']);

    if (!$errors) {
        $target = 'view.php?id=' . (int)$res['id'];
        $push = $res['receive'] ?? null;
        $msg = 'Retur <strong>' . e($data['resi']) . '</strong> ' . ($existing ? 'diperbarui.' : 'tersimpan.');
        if (is_array($push)) {
            if (!empty($push['ok']) && ($push['state'] ?? '') === RET_INV_POSTED) {
                flash($msg . ' Stok sudah masuk Inventory (' . e((string)$push['doc_no']) . ').');
            } elseif (!empty($push['ok'])) {
                flash($msg . ' Retur tanpa artikel yang masuk stok — Inventory tidak diubah.', 'warn');
            } else {
                flash($msg . ' Namun stok BELUM masuk Inventory: '
                    . e(implode(' ', (array)$push['errors']))
                    . ' Perbaiki lalu pakai tombol <em>Kirim ulang ke Inventory</em> di halaman rincian.', 'error');
            }
        } else {
            flash($msg);
        }
        $dup = ret_duplicate_resi($data['resi'], (int)$res['id']);
        if ($dup) {
            flash('Perhatian: nomor resi <strong>' . e($data['resi']) . '</strong> sudah pernah dicatat '
                . 'di ' . count($dup) . ' catatan lain. Periksa agar tidak dobel.', 'warn');
        }
        redirect($target);
    }

    /* Validasi gagal: pertahankan apa yang sudah diketik. */
    $rows = $rowsFromPost();
    if (!$rows) $rows = $rowsFromDb($existing);
}

/* Selalu sisakan satu baris kosong di bawah supaya pengguna bisa langsung scan lagi.
   Kolom jumlah dibiarkan kosong (= 1 pcs) supaya baris kosong tidak dianggap terisi. */
if (!$locked) $rows[] = ['sku' => '', 'qty' => '', 'cond' => 'bagus', 'stock' => true];
if (!$rows) $rows[] = ['sku' => '', 'qty' => '', 'cond' => 'bagus', 'stock' => true];

$title = $existing ? ('Ubah Retur ' . (string)$existing['resi']) : 'Catat Retur Baru';
$invReady = ret_inv_ready();

/* Kolom "Ke stok" hanya ditampilkan bila tanggal retur diterima sudah terisi — itulah saat
   stok Inventory benar-benar ditambahkan (permintaan pemilik toko: paket sering baru sampai
   gudang beberapa hari setelah marketplace menyatakan diterima). */
$stockVisible = $locked || (string)$form['received_date'] !== '';

ret_page_start($title, 'returns.php', [
    'label' => 'form',
    'sub'   => 'Semua kolom wajib diisi kecuali tanggal retur diterima &amp; catatan. '
        . 'Nomor resi &amp; artikel bisa diisi dari hasil scan kamera HP, scanner Bluetooth/USB, atau ketik manual.',
    'actions' => '<a class="btn" href="' . ($existing ? 'view.php?id=' . $id : 'returns.php') . '">Batal</a>',
]);
?>

<?php if ($invReady === false): ?>
  <?= ret_notice('Database aplikasi Inventory tidak terbaca: artikel tidak bisa dicek dan stok tidak bisa ditambahkan. '
      . 'Catatan retur tetap bisa disimpan.', 'warn') ?>
<?php endif; ?>

<?php foreach ($errors as $err): ?>
  <?= ret_notice(e($err)) ?>
<?php endforeach; ?>

<?php if ($locked): ?>
  <?= ret_notice('Retur ini <strong>sudah diterima</strong> '
      . '(stok di Inventory mengikuti tanggal & artikel yang lama). Tanggal, artikel, dan jumlah dikunci — '
      . 'yang bisa diubah hanya pembeli, kurir, alasan, dan catatan. Untuk membetulkan tanggal/artikel, '
      . 'batalkan dulu penerimaannya dari halaman rincian.', 'info') ?>
<?php endif; ?>

<form method="post" action="form.php<?= $existing ? '?id=' . $id : '' ?>" class="retur-form" data-scan-root>
  <?= csrf_field() ?>

  <section class="card">
    <div class="card-head"><h2>Identitas retur</h2></div>
    <div class="form-grid">
      <label class="field">
        <span>Marketplace <b class="req">*</b></span>
        <select name="marketplace">
          <?php foreach (ret_markets() as $code => $label): ?>
            <option value="<?= e($code) ?>" <?= $form['marketplace'] === $code ? 'selected' : '' ?>><?= e($label) ?></option>
          <?php endforeach; ?>
        </select>
      </label>

      <label class="field">
        <span>No. resi <b class="req">*</b></span>
        <span class="with-btn">
          <input type="text" id="fResi" name="resi" value="<?= e($form['resi']) ?>" autocomplete="off"
                 spellcheck="false" placeholder="Scan barcode resi atau ketik">
          <button type="button" class="btn btn-sm" data-cam-open data-cam-target="#fResi" data-cam-next="last-sku"
                  title="Scan dengan kamera HP">Scan</button>
        </span>
        <span class="row-info" id="resiWarn" data-resi-warn data-ret-id="<?= $id ?>"></span>
      </label>

      <label class="field">
        <span>No. pesanan <b class="req">*</b></span>
        <input type="text" name="order_no" value="<?= e($form['order_no']) ?>" autocomplete="off"
               placeholder="mis. 250101ABCXYZ (ada di halaman pesanan marketplace)">
      </label>

      <label class="field">
        <span>Tanggal retur terbit <b class="req">*</b></span>
        <input type="date" name="issued_date" value="<?= e($form['issued_date']) ?>">
      </label>

      <label class="field">
        <span>Tanggal diterima di marketplace <span class="opt">(opsional)</span></span>
        <input type="date" name="mk_received_date_raw" value="<?= e($form['mk_received_date']) ?>" <?= $locked ? 'disabled' : '' ?>>
        <span class="hint">Tanggal yang tertulis di sistem marketplace / jasa kirim (status &ldquo;diterima&rdquo;).
          Kalau nanti paketnya baru sampai di tanggal lain, selisihnya otomatis dihitung &mdash; dipakai untuk
          mengejar jasa kirim atau klaim.</span>
      </label>

      <label class="field">
        <span>Tanggal paket sampai gudang <span class="opt">(boleh dikosongkan)</span></span>
        <input type="date" name="received_date_raw" value="<?= e($form['received_date']) ?>" <?= $locked ? 'disabled' : '' ?>>
        <span class="hint">Tanggal <strong>nyata</strong> paketnya sampai gudang. Kosongkan bila belum sampai.
          Mengisi tanggal ini yang menambahkan stok ke Inventory.</span>
      </label>

      <label class="field">
        <span>Pembeli <b class="req">*</b></span>
        <input type="text" name="buyer" value="<?= e($form['buyer']) ?>" autocomplete="off"
               placeholder="Nama pembeli (wajib — dipakai untuk rekap pembeli sering retur)">
        <span class="hint">Dipakai untuk laporan “pembeli paling sering retur”.</span>
      </label>

      <label class="field">
        <span>Kurir <b class="req">*</b></span>
        <input type="text" name="courier" value="<?= e($form['courier']) ?>" list="courierList" autocomplete="off" placeholder="JNE / J&T / SiCepat…">
        <datalist id="courierList">
          <?php foreach (ret_couriers() as $c): ?><option value="<?= e($c) ?>"></option><?php endforeach; ?>
        </datalist>
      </label>

      <label class="field">
        <span>Alasan retur <b class="req">*</b></span>
        <input type="text" name="reason" value="<?= e($form['reason']) ?>" list="reasonList" autocomplete="off" placeholder="mis. salah ukuran">
        <datalist id="reasonList">
          <?php foreach (ret_reasons() as $r): ?><option value="<?= e($r) ?>"></option><?php endforeach; ?>
        </datalist>
      </label>

      <label class="field field-wide">
        <span>Catatan <span class="opt">(boleh dikosongkan)</span></span>
        <textarea name="note" rows="2" placeholder="Catatan tambahan, mis. kondisi kardus / permintaan pembeli"><?= e($form['note']) ?></textarea>
      </label>
    </div>
  </section>

  <section class="card">
    <div class="card-head">
      <h2>Artikel yang diretur</h2>
      <span class="muted small">Kolom artikel = SKU di aplikasi Inventory</span>
    </div>

    <p class="explain" data-stock-note <?= $stockVisible ? 'hidden' : '' ?>>
      Paketnya belum sampai? Kolom <em>Ke stok</em> disembunyikan dulu — stok Inventory baru bisa
      ditambahkan setelah <strong>tanggal retur diterima</strong> diisi. Kalau tanggalnya sudah ada
      sekarang, isi kolom tanggal diterima di atas dan pilihan masuk stok akan muncul di sini.
    </p>
    <p class="explain" data-stock-note-on <?= $stockVisible ? '' : 'hidden' ?>>
      Tanggal diterima terisi: tandai artikel mana yang <strong>layak masuk stok jual</strong>.
      Kondisi <em>rusak</em> / <em>kurang lengkap</em> otomatis tidak masuk stok (bisa dicentang ulang),
      dan stoknya dikirim ke Inventory begitu disimpan.
    </p>

    <div class="table-wrap">
      <table class="table item-table<?= $stockVisible ? '' : ' stock-hidden' ?>" data-items>
        <thead>
          <tr>
            <th>Artikel / SKU</th>
            <th class="qty-col">Jumlah</th>
            <th class="cond-col">Kondisi barang</th>
            <th class="stock-col">Ke stok</th>
            <?php if (!$locked): ?><th class="act-col">Baris</th><?php endif; ?>
          </tr>
        </thead>
        <tbody id="itemBody">
          <?php foreach ($rows as $i => $r): ?>
            <tr class="item-row">
              <td class="sku-cell">
                <input type="text" name="item_sku[<?= (int)$i ?>]" class="sku-input sku-input-field" <?= $locked ? 'disabled' : '' ?>
                       value="<?= e((string)$r['sku']) ?>" autocomplete="off" spellcheck="false"
                       placeholder="Scan / ketik artikel">
                <span class="row-info" data-row-info></span>
              </td>
              <td class="qty-cell">
                <?php if ($locked): ?>
                  <span class="qty-plain"><?= e((string)$r['qty']) ?></span>
                <?php else: ?>
                  <span class="qty-group">
                    <button type="button" class="qty-btn" data-qty-step="-1" tabindex="-1" aria-label="Kurangi jumlah">−</button>
                    <input type="text" inputmode="decimal" class="qty-input" name="item_qty[<?= (int)$i ?>]"
                           value="<?= e((string)$r['qty']) ?>" placeholder="1">
                    <button type="button" class="qty-btn" data-qty-step="1" tabindex="-1" aria-label="Tambah jumlah">+</button>
                  </span>
                <?php endif; ?>
              </td>
              <td class="cond-cell">
                <select name="item_cond[<?= (int)$i ?>]" <?= $locked ? 'disabled' : '' ?> class="cond-select">
                  <?php foreach (ret_conditions() as $code => $label): ?>
                    <option value="<?= e($code) ?>" <?= (string)$r['cond'] === $code ? 'selected' : '' ?>><?= e($label) ?></option>
                  <?php endforeach; ?>
                </select>
              </td>
              <td class="stock-cell">
                <input type="hidden" name="item_stock[<?= (int)$i ?>]" value="0">
                <label class="chk">
                  <input type="checkbox" name="item_stock[<?= (int)$i ?>]" value="1" class="stock-check"
                         <?= !empty($r['stock']) ? 'checked' : '' ?> <?= $locked ? 'disabled' : '' ?>>
                  <span>Masuk stok</span>
                </label>
              </td>
              <?php if (!$locked): ?>
                <td class="act-cell">
                  <button type="button" class="btn btn-sm btn-ghost" data-row-remove title="Hapus baris ini">Hapus</button>
                </td>
              <?php endif; ?>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <?php if (!$locked): ?>
      <div class="item-actions">
        <button type="button" class="btn" id="addRow">+ Tambah baris</button>
        <button type="button" class="btn" data-cam-open data-cam-target="last-sku" data-cam-add-row="1">Scan artikel</button>
        <span class="muted small">
          Baris baru otomatis tersedia setelah artikel diisi — cukup lanjut scan barang berikutnya.
          Tanda <em>Masuk stok</em> dimatikan otomatis untuk kondisi <em>barang ditukar</em>,
          <em>rusak</em>, dan <em>kurang lengkap</em>.
        </span>
      </div>
    <?php endif; ?>
  </section>

  <div class="form-foot">
    <button class="btn btn-primary btn-lg" type="submit" data-submit-confirm>Simpan</button>
    <span class="muted small" data-save-hint-muted <?= $stockVisible ? 'hidden' : '' ?>>
      Tersimpan sebagai <strong>belum diterima</strong> — stok Inventory belum berubah.
    </span>
    <span class="muted small" data-save-hint-stock <?= $stockVisible ? '' : 'hidden' ?>>
      Tanggal diterima terisi: artikel bertanda <em>masuk stok</em> langsung ditambahkan ke stok Inventory.
    </span>
  </div>
</form>

<?php if (!$locked): ?>
  <template id="itemTpl">
    <tr class="item-row">
      <td class="sku-cell">
        <input type="text" name="item_sku[__IDX__]" class="sku-input sku-input-field" value="" autocomplete="off"
               spellcheck="false" placeholder="Scan / ketik artikel">
        <span class="row-info" data-row-info></span>
      </td>
      <td class="qty-cell">
        <span class="qty-group">
          <button type="button" class="qty-btn" data-qty-step="-1" tabindex="-1" aria-label="Kurangi jumlah">−</button>
          <input type="text" inputmode="decimal" class="qty-input" name="item_qty[__IDX__]" value="" placeholder="1">
          <button type="button" class="qty-btn" data-qty-step="1" tabindex="-1" aria-label="Tambah jumlah">+</button>
        </span>
      </td>
      <td class="cond-cell">
        <select name="item_cond[__IDX__]" class="cond-select">
          <?php foreach (ret_conditions() as $code => $label): ?>
            <option value="<?= e($code) ?>"><?= e($label) ?></option>
          <?php endforeach; ?>
        </select>
      </td>
      <td class="stock-cell">
        <input type="hidden" name="item_stock[__IDX__]" value="0">
        <label class="chk">
          <input type="checkbox" name="item_stock[__IDX__]" value="1" class="stock-check" checked>
          <span>Masuk stok</span>
        </label>
      </td>
      <td class="act-cell">
        <button type="button" class="btn btn-sm btn-ghost" data-row-remove title="Hapus baris ini">Hapus</button>
      </td>
    </tr>
  </template>
<?php endif; ?>

<?php ret_page_end(['scripts' => '<script src="assets/format.js"></script>'
    . '<script src="assets/app.js"></script><script src="assets/scan.js"></script>']); ?>
