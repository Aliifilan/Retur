<?php
declare(strict_types=1);

/* ============================================================
 * Form tiket kendala baru / ubah tiket.
 * Validasi gagal tidak menghapus isian (aturan wajib aplikasi ini).
 * ============================================================ */

require_once __DIR__ . '/includes/init.php';
ret_require_login();

$id = (int)get('id', 0);
$existing = $id > 0 ? ret_ticket_find($id) : null;
if ($id > 0 && !$existing) {
    flash('Tiket tidak ditemukan.', 'error');
    redirect('tickets.php');
}
if ($existing) ret_require('edit', 'mengubah tiket kendala');
else ret_require('create', 'membuat tiket kendala');

$u = current_user();
$uid = $u ? (int)$u['id'] : null;
$errors = [];

$form = [
    'marketplace' => 'shopee',
    'ticket_no' => '',
    'order_no' => '',
    'resi' => '',
    'buyer' => '',
    'category' => 'dana_ditahan',
    'subject' => '',
    'detail' => '',
    'opened_date' => today(),
    'due_date' => '',
    'status' => 'open',
    'close_note' => '',
    'refund_amount' => '',
];

if ($existing) {
    foreach ($form as $k => $_) $form[$k] = (string)($existing[$k] ?? '');
    $form['refund_amount'] = (string)$existing['refund_amount'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $form = [
        'marketplace' => (string)post('marketplace', 'shopee'),
        'ticket_no' => (string)post('ticket_no'),
        'order_no' => (string)post('order_no'),
        'resi' => (string)post('resi'),
        'buyer' => (string)post('buyer'),
        'category' => (string)post('category', 'lainnya'),
        'subject' => (string)post('subject'),
        'detail' => (string)post('detail'),
        'opened_date' => ret_date_input((string)post('opened_date')) ?: trim((string)post('opened_date')),
        'due_date' => ret_date_input((string)post('due_date')),
        'status' => (string)post('status', 'open'),
        'close_note' => (string)post('close_note'),
        'refund_amount' => (string)post('refund_amount', ''),
    ];
    if (!isset(ret_ticket_categories()[$form['category']])) $form['category'] = 'lainnya';
    if (!isset(ret_ticket_statuses()[$form['status']])) $form['status'] = 'open';

    $data = $form;
    $data['due_date_raw'] = $form['due_date'];
    $data['due_date'] = ret_date_input($form['due_date']);

    $res = ret_ticket_save($existing, $data, (string)post('first_note'), $uid);
    if (!empty($res['ok'])) {
        flash('Tiket kendala <strong>' . e($form['subject']) . '</strong> ' . ($existing ? 'diperbarui.' : 'tercatat. '
            . 'Pantau balasannya di halaman rincian.'));
        redirect('ticket_view.php?id=' . (int)$res['id']);
    }
    $errors = $res['errors'];
}

ret_page_start($existing ? 'Ubah Tiket' : 'Tiket Kendala Baru', 'tickets.php', [
    'label'   => 'tickets',
    'sub'     => 'Catat kendala yang diurus ke marketplace beserta tenggat & no. tiket resminya.',
    'actions' => '<a class="btn" href="tickets.php">Batal</a>',
]);
?>

<?php foreach ($errors as $err): ?>
  <?= ret_notice(e($err)) ?>
<?php endforeach; ?>

<form method="post" action="ticket_form.php<?= $existing ? '?id=' . $id : '' ?>" class="retur-form">
  <?= csrf_field() ?>

  <section class="card">
    <div class="card-head"><h2>Kendala</h2></div>
    <div class="form-grid">
      <label class="field">
        <span>Marketplace <b class="req">*</b></span>
        <select name="marketplace">
          <?php foreach (ret_markets() as $code => $label): ?>
            <option value="<?= e($code) ?>" <?= $form['marketplace'] === $code ? 'selected' : '' ?>><?= e($label) ?></option>
          <?php endforeach; ?>
        </select>
      </label>

      <label class="field">
        <span>Jenis kendala <b class="req">*</b></span>
        <select name="category">
          <?php foreach (ret_ticket_categories() as $code => $label): ?>
            <option value="<?= e($code) ?>" <?= $form['category'] === $code ? 'selected' : '' ?>><?= e($label) ?></option>
          <?php endforeach; ?>
        </select>
      </label>

      <label class="field field-wide">
        <span>Judul kendala <b class="req">*</b></span>
        <input type="text" name="subject" value="<?= e($form['subject']) ?>" autocomplete="off"
               placeholder="mis. Dana pesanan 250101ABC ditahan escrow sejak 01/01" required>
      </label>

      <label class="field field-wide">
        <span>Rincian kendala</span>
        <textarea name="detail" rows="3" placeholder="Kronologi, nomor yang dihubungkan, jawaban dari marketplace…"><?= e($form['detail']) ?></textarea>
      </label>

      <label class="field">
        <span>Tanggal tiket dibuat <b class="req">*</b></span>
        <input type="date" name="opened_date" value="<?= e($form['opened_date']) ?>">
      </label>

      <label class="field">
        <span>Tenggat / target beres <span class="opt">(opsional)</span></span>
        <input type="date" name="due_date" value="<?= e($form['due_date']) ?>">
        <span class="hint">Dipakai untuk melihat tiket yang lewat tenggat di daftar.</span>
      </label>

      <label class="field">
        <span>No. tiket resmi marketplace <span class="opt">(opsional)</span></span>
        <input type="text" name="ticket_no" value="<?= e($form['ticket_no']) ?>" autocomplete="off"
               placeholder="nomor tiket/komplain dari portal toko">
      </label>

      <label class="field">
        <span>No. pesanan <span class="opt">(opsional)</span></span>
        <input type="text" name="order_no" value="<?= e($form['order_no']) ?>" autocomplete="off">
      </label>

      <label class="field">
        <span>No. resi terkait <span class="opt">(opsional)</span></span>
        <input type="text" name="resi" value="<?= e($form['resi']) ?>" autocomplete="off" spellcheck="false">
      </label>

      <label class="field">
        <span>Nama pembeli terkait <span class="opt">(opsional)</span></span>
        <input type="text" name="buyer" value="<?= e($form['buyer']) ?>" autocomplete="off">
      </label>

      <label class="field">
        <span>Nilai dana / klaim (Rp) <span class="opt">(opsional)</span></span>
        <input type="text" inputmode="numeric" name="refund_amount" value="<?= e($form['refund_amount'] !== '' && (float)$form['refund_amount'] > 0 ? (string)(int)$form['refund_amount'] : '') ?>"
               placeholder="mis. 250000">
        <span class="hint">Bila kendalanya dana/klaim — dipakai untuk melihat berapa yang sudah pulih.</span>
      </label>
    </div>
  </section>

  <section class="card">
    <div class="card-head"><h2>Status &amp; catatan pertama</h2></div>
    <div class="form-grid">
      <label class="field">
        <span>Status tiket</span>
        <select name="status">
          <?php foreach (ret_ticket_statuses() as $code => [$label]): ?>
            <option value="<?= e($code) ?>" <?= $form['status'] === $code ? 'selected' : '' ?>><?= e($label) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label class="field field-wide">
        <span>Catatan <span class="opt">(opsional)</span></span>
        <textarea name="first_note" rows="2" placeholder="mis. sudah chat CS 2x, menunggu eskalasi"><?= (string)post('first_note') ?></textarea>
      </label>
    </div>
  </section>

  <div class="form-foot">
    <button class="btn btn-primary btn-lg" type="submit">Simpan tiket</button>
    <span class="muted small">Status &amp; catatan lanjutannya ditambahkan lewat halaman rincian tiket.</span>
  </div>
</form>

<?php ret_page_end(); ?>
