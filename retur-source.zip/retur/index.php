<?php
declare(strict_types=1);

/* ============================================================
 * Dashboard: retur yang belum diterima, umur tunggu, rekap per marketplace,
 * pencarian cepat, dan artikel yang paling sering diretur.
 * ============================================================ */

require_once __DIR__ . '/includes/init.php';
ret_require_login();

$uid = current_user();
$me = $uid ? (int)$uid['id'] : null;

$period = (string)get('p', '30');
if (!isset(ret_period_options()[$period])) $period = '30';
$from = ret_period_from($period);
$filter = ['from' => $from];

$stats  = ret_stats($filter);
$markets = ret_market_stats($filter);
$tops   = ret_top_sku($filter, 6);
$topBuyers = ret_top_buyer($filter, 8);
$pending = ret_pending([], 25);
$ticketStats = ret_ticket_stats();
$delayRows = ret_delay_stats();
$manualCount = (int)(ret_scalar('SELECT COUNT(*) FROM mret WHERE manual = 1') ?? 0);

$maxTotal = 1;
foreach ($markets as $m) $maxTotal = max($maxTotal, $m['total']);

$invReady = ret_inv_ready();
$invWritable = ret_inv_writable();

$actions = '<a class="btn btn-primary" href="form.php">+ Catat Retur</a>'
    . (ret_can('create') ? ' <a class="btn" href="manual.php">+ Retur Manual</a> <a class="btn" href="ticket_form.php">+ Tiket Kendala</a>' : '');

ret_page_start('Dashboard', 'index.php', [
    'label'   => 'dashboard',
    'sub'     => 'Pantau retur marketplace: yang belum diterima, umur tunggu, dan rekap per marketplace.',
    'actions' => $actions,
]);
?>

<?php if (!$invReady): ?>
  <?= ret_notice('<strong>Aplikasi Inventory tidak terbaca.</strong> Akun, daftar artikel, dan penambahan stok
      memerlukan database Inventory. Periksa apakah folder <code>inventory/</code> masih ada.', 'error') ?>
<?php elseif (!$invWritable): ?>
  <?= ret_notice('<strong>Database Inventory tidak bisa ditulis.</strong> Retur tetap bisa dicatat, tetapi stok
      tidak akan bertambah saat retur diterima. Periksa hak akses berkas database Inventory.', 'warn') ?>
<?php endif; ?>

<?php if ($stats['blocked'] > 0): ?>
  <?= ret_notice('Ada <strong>' . $stats['blocked'] . '</strong> retur yang stoknya gagal masuk Inventory. '
      . '<a href="returns.php?inv_problem=1">Lihat daftarnya</a> lalu pakai tombol <em>Kirim ulang</em>.', 'warn') ?>
<?php endif; ?>

<form class="card search-card" method="get" action="returns.php">
  <label class="field field-inline">
    <span>Cari cepat</span>
    <input type="text" name="q" placeholder="No. resi, no. pesanan, artikel/SKU, pembeli…" autocomplete="off">
  </label>
  <button class="btn btn-primary" type="submit">Cari</button>
  <span class="muted small">Bisa sebagian kode (mis. <code>SPX</code>) — hasilnya tampil di halaman daftar retur.</span>
</form>

<form class="card period-card" method="get" action="index.php">
  <label class="field">
    <span>Periode ringkasan &amp; rekap</span>
    <select name="p">
      <?php foreach (ret_period_options() as $key => $label): ?>
        <option value="<?= e($key) ?>" <?= $period === (string)$key ? 'selected' : '' ?>><?= e($label) ?></option>
      <?php endforeach; ?>
    </select>
  </label>
  <button class="btn" type="submit">Tampilkan</button>
  <a class="btn btn-ghost" href="export.php?type=rekap&amp;from=<?= e($from) ?>">Export rekap periode ini</a>
</form>

<section class="tiles">
  <div class="tile">
    <span class="tile-label">Belum diterima</span>
    <strong class="tile-value <?= $stats['pending_all'] > 0 ? 'is-warn' : '' ?>"><?= fmt_num($stats['pending_all']) ?></strong>
    <span class="tile-sub">retur menunggu paket kembali</span>
  </div>
  <div class="tile">
    <span class="tile-label">Terlama menunggu</span>
    <strong class="tile-value <?= $stats['oldest_days'] >= 7 ? 'is-danger' : ($stats['oldest_days'] >= 3 ? 'is-warn' : '') ?>">
      <?= $stats['oldest_date'] !== '' ? e(ret_age_text($stats['oldest_days'])) : '—' ?>
    </strong>
    <span class="tile-sub"><?= $stats['oldest_date'] !== '' ? 'terbit ' . e(fmt_date($stats['oldest_date'])) : 'belum ada tunggakan' ?></span>
  </div>
  <div class="tile">
    <span class="tile-label">Diterima (<?= e(ret_period_options()[$period]) ?>)</span>
    <strong class="tile-value"><?= fmt_num($stats['received']) ?></strong>
    <span class="tile-sub"><?= fmt_qty($stats['qty']) ?> artikel tercatat</span>
  </div>
  <div class="tile">
    <span class="tile-label">Total retur (periode)</span>
    <strong class="tile-value"><?= fmt_num($stats['total']) ?></strong>
    <span class="tile-sub">rata-rata tunggu <?= e(str_replace('.', ',', (string)$stats['avg_days'])) ?> hari</span>
  </div>
  <div class="tile">
    <span class="tile-label">Tidak layak jual</span>
    <strong class="tile-value <?= $stats['bad_qty'] > 0 ? 'is-danger' : '' ?>"><?= fmt_qty($stats['bad_qty']) ?></strong>
    <span class="tile-sub">ditukar / rusak / kurang lengkap</span>
  </div>
  <div class="tile">
    <span class="tile-label">Paket terlambat</span>
    <strong class="tile-value <?= $delayRows['late'] > 0 ? 'is-warn' : '' ?>"><?= fmt_num($delayRows['late']) ?></strong>
    <span class="tile-sub"><?= $delayRows['count'] > 0
        ? 'dari ' . $delayRows['count'] . ' terima, terlambat rata-rata ' . e(str_replace('.', ',', (string)$delayRows['avg'])) . ' hari'
        : 'belum ada yang dibandingkan' ?></span>
  </div>
  <div class="tile">
    <span class="tile-label">Retur manual</span>
    <strong class="tile-value"><?= fmt_num($manualCount) ?></strong>
    <span class="tile-sub">tukar size &amp; kendala tanpa marketplace</span>
  </div>
  <a class="tile tile-link" href="tickets.php">
    <span class="tile-label">Tiket kendala terbuka</span>
    <strong class="tile-value <?= $ticketStats['open'] > 0 ? 'is-warn' : '' ?>"><?= fmt_num($ticketStats['open']) ?></strong>
    <span class="tile-sub"><?= $ticketStats['oldest_date'] !== ''
        ? 'terlama ' . e(ret_age_text($ticketStats['oldest_days'])) . ' • lihat semua'
        : 'belum ada tiket • buat tiket' ?></span>
  </a>
</section>

<section class="grid-2">
  <div class="card">
    <div class="card-head">
      <h2>Rekap per marketplace</h2>
      <span class="muted small"><?= e(ret_period_options()[$period]) ?></span>
    </div>
    <div class="chart">
      <?php foreach ($markets as $m): ?>
        <div class="chart-row">
          <span class="chart-label"><span class="dot <?= e(ret_market_class($m['code'])) ?>"></span><?= e($m['label']) ?></span>
          <span class="chart-track">
            <span class="chart-bar <?= e(ret_market_class($m['code'])) ?>" style="width: <?= (int)round($m['total'] / $maxTotal * 100) ?>%"></span>
          </span>
          <span class="chart-value"><?= fmt_num($m['total']) ?></span>
        </div>
      <?php endforeach; ?>
    </div>
    <div class="table-wrap">
    <table class="table table-compact">
      <thead>
        <tr><th>Marketplace</th><th class="num">Retur</th><th class="num">Diterima</th><th class="num">Belum</th></tr>
      </thead>
      <tbody>
        <?php foreach ($markets as $m): ?>
          <tr>
            <td><?= ret_market_badge($m['code']) ?></td>
            <td class="num"><?= fmt_num($m['total']) ?></td>
            <td class="num"><?= fmt_num($m['received']) ?></td>
            <td class="num <?= $m['pending'] > 0 ? 'is-warn-cell' : '' ?>"><?= fmt_num($m['pending']) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    </div>
    <p class="muted small">Angka "Belum" di atas mengikuti periode; kartu <em>Belum diterima</em> di atas menghitung seluruh tunggakan.</p>
  </div>

  <div class="card">
    <div class="card-head">
      <h2>Artikel paling sering diretur</h2>
      <span class="muted small"><?= e(ret_period_options()[$period]) ?></span>
    </div>
    <?php if (!$tops): ?>
      <p class="muted">Belum ada retur pada periode ini.</p>
    <?php else: ?>
      <div class="table-wrap">
      <table class="table table-compact">
        <thead><tr><th>Artikel / SKU</th><th class="num">Retur</th><th class="num">Qty</th><th>Pembeli yang meretur</th></tr></thead>
        <tbody>
          <?php foreach ($tops as $t): ?>
            <tr>
              <td>
                <a class="sku" href="returns.php?q=<?= urlencode((string)$t['sku']) ?>"><?= e((string)$t['sku']) ?></a>
                <?php if ((int)$t['bad'] > 0): ?>
                  <div class="tiny danger-text"><?= fmt_num((int)$t['bad']) ?>× kondisi tidak layak jual
                    (ditukar/rusak/kurang)</div>
                <?php endif; ?>
              </td>
              <td class="num"><?= fmt_num((int)$t['docs']) ?></td>
              <td class="num"><?= fmt_qty($t['qty']) ?></td>
              <td>
                <?php if (!$t['buyers']): ?>
                  <span class="muted">—</span>
                <?php else: ?>
                  <?php foreach ($t['buyers'] as $b): ?>
                    <a class="chip <?= (int)$b['docs'] >= 2 ? 'chip-hot' : '' ?>"
                       href="returns.php?q=<?= urlencode((string)$b['buyer']) ?>"
                       title="Lihat retur dari pembeli ini"><?= e((string)$b['buyer']) ?> · <?= fmt_num((int)$b['docs']) ?>×</a>
                  <?php endforeach; ?>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      </div>
      <p class="muted small">Nama pembeli ditampilkan supaya kelihatan SKU mana yang bermasalah <em>dan</em> siapa yang
        mengembalikannya berulang kali (tanda merah = 2 kali atau lebih). Klik namanya untuk melihat riwayatnya.</p>
    <?php endif; ?>
  </div>
</section>

<section class="card">
  <div class="card-head">
    <h2>Pembeli paling sering retur</h2>
    <span class="muted small"><?= e(ret_period_options()[$period]) ?></span>
  </div>
  <?php if (!$topBuyers): ?>
    <p class="muted">Belum ada data pembeli pada periode ini.</p>
  <?php else: ?>
    <div class="table-wrap">
    <table class="table table-compact">
      <thead>
        <tr>
          <th class="num">#</th>
          <th>Pembeli</th>
          <th class="num">Jumlah retur</th>
          <th class="num">Artikel</th>
          <th class="num">SKU berbeda</th>
          <th class="num">Rusak</th>
          <th>Retur terakhir</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($topBuyers as $i => $b): ?>
          <tr>
            <td class="num"><?= $i + 1 ?></td>
            <td>
              <a class="buyer" href="returns.php?q=<?= urlencode((string)$b['buyer']) ?>"><?= e((string)$b['buyer']) ?></a>
            </td>
            <td class="num <?= (int)$b['docs'] >= 3 ? 'is-warn-cell' : '' ?>"><?= fmt_num((int)$b['docs']) ?></td>
            <td class="num"><?= fmt_qty($b['qty']) ?></td>
            <td class="num"><?= fmt_num((int)$b['skus']) ?></td>
            <td class="num <?= (int)$b['bad'] > 0 ? 'is-warn-cell' : '' ?>"><?= fmt_num((int)$b['bad']) ?></td>
            <td><?= e(fmt_date((string)$b['last_date'])) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    </div>
    <p class="muted small">
      Gunakan daftar ini untuk mengenali pembeli yang sering mengembalikan barang (mis. sebelum menyetujui
      pesanan berikutnya). Nama yang sama dihitung sebagai satu pembeli, walau huruf besar/kecilnya berbeda.
    </p>
  <?php endif; ?>
</section>

<section class="grid-2">
  <div class="card">
    <div class="card-head">
      <h2>Tiket kendala terbuka</h2>
      <a class="btn btn-sm" href="tickets.php?status=open">Lihat semua</a>
    </div>
    <?php
    $openTickets = ret_ticket_list(['status' => 'open'], 5);
    if (!$openTickets['rows']): ?>
      <p class="muted">Tidak ada tiket kendala yang terbuka. 👍</p>
    <?php else: ?>
      <table class="table table-compact">
        <thead><tr><th>Tiket</th><th>Jenis</th><th>Status</th><th>Tenggat</th></tr></thead>
        <tbody>
          <?php foreach ($openTickets['rows'] as $t): ?>
            <tr>
              <td>
                <a class="sku" href="ticket_view.php?id=<?= (int)$t['id'] ?>"><?= e((string)$t['ticket_no'] !== '' ? (string)$t['ticket_no'] : ('#' . (int)$t['id'])) ?></a>
                <div class="muted tiny"><?= e((string)$t['subject']) ?></div>
              </td>
              <td><?= ret_market_badge((string)$t['marketplace']) ?></td>
              <td><?= ret_ticket_status_badge((string)$t['status']) ?></td>
              <td><?= (string)$t['due_date'] !== ''
                ? e(fmt_date((string)$t['due_date'])) . (ret_age_days((string)$t['due_date']) > 0 ? '<div class="tiny danger-text">lewati</div>' : '')
                : '<span class="muted">—</span>' ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>

  <div class="card">
    <div class="card-head">
      <h2>Pengiriman retur terlambat</h2>
      <a class="btn btn-sm" href="returns.php">Daftar retur</a>
    </div>
    <?php if (!$delayRows['count']): ?>
      <p class="muted">
        Belum ada yang bisa dibandingkan — isi <strong>Tanggal diterima di marketplace</strong> di form catat retur,
        lalu isi tanggal paket sampai gudang. Selisihnya muncul di sini sebagai buahan klaim ke jasa kirim.
      </p>
    <?php else: ?>
      <p class="explain">
        <?= fmt_num($delayRows['late']) ?> dari <?= fmt_num($delayRows['count']) ?> retur terlambat dari
        klaim jasa kirim — terlambat terlama <strong><?= fmt_num($delayRows['max']) ?> hari</strong>
        (rata-rata <?= e(str_replace('.', ',', (string)$delayRows['avg'])) ?> hari).
      </p>
      <table class="table table-compact">
        <thead><tr><th>Resi</th><th>Klaim diterima</th><th>Sampai gudang</th><th>Selisih</th></tr></thead>
        <tbody>
          <?php foreach ($delayRows['rows'] as $d): ?>
            <?php $delay = ret_delay_days($d); ?>
            <tr>
              <td><a class="sku" href="returns.php?q=<?= urlencode((string)$d['resi']) ?>"><?= e((string)$d['resi']) ?></a>
                <div class="muted tiny"><?= ret_market_badge((string)$d['marketplace']) ?></div></td>
              <td><?= e(fmt_date((string)$d['mk_received_date'])) ?></td>
              <td><?= e(fmt_date((string)$d['received_date'])) ?></td>
              <td><?= ret_delay_badge($delay) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</section>

<section class="card">
  <div class="card-head">
    <h2>Belum diterima (terlama lebih dulu)</h2>
    <a class="btn btn-sm" href="returns.php?status=pending">Lihat semua</a>
  </div>

  <?php if (!$pending['rows']): ?>
    <p class="muted">Tidak ada retur yang menunggu — semua paket retur sudah diterima. 👍</p>
  <?php else: ?>
    <?php
    $rows = $pending['rows'];
    $itemsMap = $pending['items'];
    require __DIR__ . '/includes/partial_pending_table.php';
    ?>
  <?php endif; ?>
</section>

<?php ret_page_end(['scripts' => '']); ?>
