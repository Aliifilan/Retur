<?php
declare(strict_types=1);

/* ============================================================
 * Rincian tiket kendala + riwayat + tindakan status.
 * ============================================================ */

require_once __DIR__ . '/includes/init.php';
ret_require_login();

$id = (int)get('id', 0);
$t = ret_ticket_find($id);
if (!$t) {
    flash('Tiket tidak ditemukan.', 'error');
    redirect('tickets.php');
}
$replies = ret_ticket_replies($id);
$age = ret_age_days((string)$t['opened_date']);
$terlambat = (string)$t['due_date'] !== '' && !in_array((string)$t['status'], ['closed', 'resolved'], true)
    && ret_age_days((string)$t['due_date']) > 0;

ret_page_start('Tiket ' . ((string)$t['ticket_no'] !== '' ? (string)$t['ticket_no'] : '#' . $id), 'tickets.php', [
    'label'   => 'tickets',
    'sub'     => '<a href="tickets.php">← Kembali ke daftar tiket</a>',
    'actions' => ret_can('edit')
        ? '<a class="btn btn-primary" href="ticket_form.php?id=' . $id . '">Ubah</a>'
        : '',
]);
?>

<section class="grid-2">
  <div class="card">
    <div class="card-head">
      <h2>Detail kendala</h2>
      <span>
        <?= ret_market_badge((string)$t['marketplace']) ?>
        <?= ret_ticket_category_badge((string)$t['category']) ?>
        <?= ret_ticket_status_badge((string)$t['status']) ?>
      </span>
    </div>
    <dl class="kv">
      <dt>Judul</dt>
      <dd class="strong"><?= e((string)$t['subject']) ?></dd>
      <dt>No. tiket marketplace</dt>
      <dd><?= (string)$t['ticket_no'] !== '' ? e((string)$t['ticket_no']) : '<span class="muted">belum ada</span>' ?></dd>
      <dt>No. pesanan</dt>
      <dd><?= (string)$t['order_no'] !== '' ? e((string)$t['order_no']) : '<span class="muted">—</span>' ?></dd>
      <dt>No. resi terkait</dt>
      <dd><?= (string)$t['resi'] !== '' ? e((string)$t['resi']) : '<span class="muted">—</span>' ?></dd>
      <dt>Pembeli terkait</dt>
      <dd><?= (string)$t['buyer'] !== '' ? e((string)$t['buyer']) : '<span class="muted">—</span>' ?></dd>
      <dt>Tanggal dibuat</dt>
      <dd><?= e(fmt_date((string)$t['opened_date'])) ?>
        <span class="age <?= e(ret_age_class($age)) ?>"><?= e(ret_age_text($age)) ?></span></dd>
      <dt>Tenggat beres</dt>
      <dd>
        <?php if ((string)$t['due_date'] === ''): ?>
          <span class="muted">belum ditetapkan</span>
        <?php else: ?>
          <?= e(fmt_date((string)$t['due_date'])) ?>
          <?php if ($terlambat): ?>
            <span class="age age-danger">lewati tenggat <?= e(ret_age_text(ret_age_days((string)$t['due_date']))) ?></span>
          <?php endif; ?>
        <?php endif; ?>
      </dd>
      <dt>Nilai dana / klaim</dt>
      <dd><?= (float)$t['refund_amount'] > 0 ? '<strong>' . e(fmt_money((float)$t['refund_amount'])) . '</strong>' : '<span class="muted">—</span>' ?></dd>
      <dt>Rincian</dt>
      <dd><?= (string)$t['detail'] !== '' ? nl2br(e((string)$t['detail'])) : '<span class="muted">—</span>' ?></dd>
    </dl>
  </div>

  <div class="card">
    <div class="card-head"><h2>Riwayat tiket</h2></div>
    <?php if (!$replies): ?>
      <p class="muted">Belum ada riwayat.</p>
    <?php else: ?>
      <div class="reply-list">
        <?php foreach ($replies as $r): ?>
          <div class="reply">
            <div class="reply-head">
              <strong><?= e((string)$r['by_name'] !== '' ? (string)$r['by_name'] : 'Sistem') ?></strong>
              <?= ret_ticket_status_badge((string)$r['status']) ?>
              <span class="muted tiny"><?= e(fmt_dt((string)$r['at'])) ?></span>
            </div>
            <?php if ((string)$r['message'] !== ''): ?>
              <p><?= nl2br(e((string)$r['message'])) ?></p>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</section>

<?php if (ret_can('edit')): ?>
<section class="card">
  <div class="card-head">
    <h2>Tambah catatan / ubah status</h2>
    <span class="muted small">Status berubah + catatan tersimpan sebagai riwayat</span>
  </div>
  <form method="post" action="ticket_action.php" class="row-form">
    <?= csrf_field() ?>
    <input type="hidden" name="do" value="reply">
    <input type="hidden" name="id" value="<?= $id ?>">
    <label class="field">
      <span>Status baru</span>
      <select name="status">
        <?php foreach (ret_ticket_statuses() as $code => [$label]): ?>
          <option value="<?= e($code) ?>" <?= (string)$t['status'] === $code ? 'selected' : '' ?>><?= e($label) ?></option>
        <?php endforeach; ?>
      </select>
    </label>
    <label class="field field-grow">
      <span>Catatan <b class="req">*</b></span>
      <input type="text" name="message" required autocomplete="off"
             placeholder="mis. sudah balas chat CS, minta eskalasi ke seller support">
    </label>
    <button class="btn btn-primary" type="submit">Simpan riwayat</button>
  </form>
</section>
<?php endif; ?>

<?php if (ret_can('void')): ?>
<section class="card">
  <div class="card-head"><h2>Hapus tiket</h2></div>
  <p class="muted small">Tiket salah buat / dobel. Riwayatnya ikut terhapus (tiket tidak berkaitan dengan stok).</p>
  <form method="post" action="ticket_action.php" class="row-form">
    <?= csrf_field() ?>
    <input type="hidden" name="do" value="delete">
    <input type="hidden" name="id" value="<?= $id ?>">
    <button class="btn btn-danger" type="submit"
            data-confirm="Hapus tiket <?= e((string)$t['subject']) ?>? Riwayatnya ikut terhapus.">
      Hapus tiket ini
    </button>
  </form>
</section>
<?php endif; ?>

<?php ret_page_end(); ?>
