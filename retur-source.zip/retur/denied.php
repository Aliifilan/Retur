<?php
declare(strict_types=1);

/** Halaman "tidak diizinkan" — dipanggil ret_deny() dari includes/auth.php. */

if (!function_exists('e')) {
    http_response_code(403);
    echo 'Tidak diizinkan.';
    exit;
}

$u = current_user();
$what = isset($why) ? trim((string)$why) : '';

ret_page_start('Tidak diizinkan', '', ['no_title' => true, 'label' => 'denied']);
?>
<section class="card denied-card">
  <h1>Akses ditolak</h1>
  <p class="muted">
    Peran akun Anda (<strong><?= e(ret_role_label((string)($u['role'] ?? ''))) ?></strong>) tidak memiliki
    izin untuk <?= e($what !== '' ? $what : 'tindakan ini') ?>.
  </p>
  <p>Hubungi Admin bila Anda memang perlu mengerjakan bagian ini.</p>
  <div class="page-actions">
    <a class="btn btn-primary" href="index.php">Kembali ke Dashboard</a>
  </div>
</section>
<?php ret_page_end(); ?>
