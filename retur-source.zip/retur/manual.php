<?php
declare(strict_types=1);

/* ============================================================
 * Retur Manual — kendala yang tidak lewat marketplace: tukar size,
 * salah kirim dari gudang, barang rusak saat dikemas, paket hilang,
 * dan sebagainya.
 *
 * Tidak ada nomor resi marketplace yang diwajibkan (nomor ditandai otomatis
 * MANUAL-… kalau dikosongkan). Untuk jenis TUKAR SIZE: artikel lama masuk stok
 * lewat alur penerimaan biasa, dan artikel pengganti keluar stok lewat dokumen
 * Barang Keluar resmi Inventori (OUT-…) yang dikirim manual lewat tombol
 * "Kirim barang pengganti" di halaman rinciannya.
 * ============================================================ */

require_once __DIR__ . '/includes/init.php';
ret_require('create', 'mencatat retur manual');

$u = current_user();
$uid = $u ? (int)$u['id'] : null;
$errors = [];
$rows = [];

$form = [
    'marketplace' => '',
    'resi' => '',
    'order_no' => '',
    'buyer' => '',
    'courier' => '',
    'reason' => 'tukar_size',
    'note' => '',
    'issued_date' => today(),
    'received_date' => '',
    'received_date_raw' => '',
    'mk_received_date_raw' => '',
    'manual' => 1,
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $form = [
        'marketplace' => (string)post('marketplace', ''),
        'resi' => (string)post('resi'),
        'order_no' => (string)post('order_no'),
        'buyer' => (string)post('buyer'),
        'courier' => (string)post('courier'),
        'reason' => (string)post('reason', 'tukar_size'),
        'note' => (string)post('note'),
        'issued_date' => ret_date_input((string)post('issued_date')) ?: trim((string)post('issued_date')),
        'received_date' => ret_date_input((string)post('received_date_raw')),
        'received_date_raw' => trim((string)post('received_date_raw')),
        'mk_received_date_raw' => trim((string)post('mk_received_date_raw')),
        'manual' => 1,
    ];
    $collected = ret_collect_items(
        (array)post('item_sku', []),
        (array)post('item_qty', []),
        (array)post('item_cond', []),
        (array)post('item_stock', [])
    );
    $items = $collected[0];
    $itemErrors = $collected[1];

    if (!isset(ret_manual_types()[$form['reason']])) {
        $errors[] = 'Jenis retur manual belum dipilih.';
    }
    if ($form['issued_date'] === '') {
        $errors[] = 'Tanggal kejadian belum diisi atau formatnya tidak dikenali (contoh: 31/01/2026).';
    }
    $errors = array_merge($errors, $itemErrors);

    if (!$errors) {
        /* Untuk tukar size: barang lama JANGAN otomatis masuk stok — petugas memeriksa
           kondisinya dulu saat barang tiba. Satu-satunya baris menjadi acuan tukar. */
        $isSwap = $form['reason'] === 'tukar_size';
        if ($isSwap && count($items) === 1 && $items[0]['condition'] === 'bagus') {
            $items[0]['to_stock'] = 0;
        }

        $res = ret_save_manual($form, $items, $uid);
        if (!empty($res['ok'])) {
            $target = 'view.php?id=' . (int)$res['id'];
            $push = $res['receive'] ?? null;
            $jenis = ret_manual_label($form['reason']);
            if ($isSwap) {
                flash('Retur manual <strong>' . e($jenis) . '</strong> tersimpan. '
                    . 'Lengkapi artikel penggantinya lewat tombol <em>Ubah</em>, lalu kirim lewat '
                    . '<em>Kirim barang pengganti</em> di halaman rincian.');
            } elseif (is_array($push) && !empty($push['ok']) && ($push['state'] ?? '') === RET_INV_POSTED) {
                flash('Retur manual <strong>' . e($jenis) . '</strong> tersimpan & stok masuk Inventory ('
                    . e((string)$push['doc_no']) . ').');
            } elseif (is_array($push) && !empty($push['ok'])) {
                flash('Retur manual tersimpan. Tidak ada artikel yang masuk stok — Inventory tidak diubah.', 'warn');
            } else {
                flash('Retur manual tersimpan. ' . ($form['received_date_raw'] === ''
                    ? 'Stok akan ditambahkan saat tanggal paket diterima diisi.'
                    : ''), 'warn');
            }
            redirect($target);
        }
        $errors = $res['errors'];
        $rows = (function () {
            $skus = (array)($_POST['item_sku'] ?? []);
            $qtys = (array)($_POST['item_qty'] ?? []);
            $conds = (array)($_POST['item_cond'] ?? []);
            $flags = (array)($_POST['item_stock'] ?? []);
            $keys = array_unique(array_merge(array_keys($skus), array_keys($qtys), array_keys($conds), array_keys($flags)));
            sort($keys, SORT_NUMERIC);
            $out = [];
            foreach ($keys as $i) {
                $sku = trim((string)($skus[$i] ?? ''));
                $qty = trim((string)($qtys[$i] ?? ''));
                if ($sku === '' && $qty === '') continue;
                $out[] = [
                    'sku' => $sku,
                    'qty' => $qty,
                    'cond' => (string)($conds[$i] ?? 'bagus'),
                    'stock' => (int)($flags[$i] ?? 0) === 1,
                ];
            }
            return $out;
        })();
    }
}

if (!$rows) $rows = [['sku' => '', 'qty' => '', 'cond' => 'bagus', 'stock' => true]];
$jenis = ret_manual_types();

ret_page_start('Retur Manual', 'manual.php', [
    'label'   => 'manual',
    'sub'     => 'Kendala yang tidak lewat marketplace: tukar size, salah kirim dari gudang, barang rusak saat dikemas, paket hilang.',
    'actions' => '<a class="btn" href="returns.php?source=manual">Lihat retur manual tercatat</a>',
]);
?>

<?php foreach ($errors as $err): ?>
  <?= ret_notice(e($err)) ?>
<?php endforeach; ?>

<form method="post" action="manual.php" class="retur-form" data-scan-root>
  <?= csrf_field() ?>

  <section class="card">
    <div class="card-head"><h2>Jenis kendala &amp; identitas</h2></div>
    <div class="form-grid">
      <label class="field">
        <span>Jenis retur manual <b class="req">*</b></span>
        <select name="reason" id="fReason">
          <?php foreach ($jenis as $code => $label): ?>
            <option value="<?= e($code) ?>" <?= $form['reason'] === $code ? 'selected' : '' ?>><?= e($label) ?></option>
          <?php endforeach; ?>
        </select>
        <span class="hint" id="reasonHint">Barang lama nanti ditukar dengan artikel pengganti — penggantinya
          dikirim lewat tombol di halaman rincian setelah barang lama diterima.</span>
      </label>

      <label class="field">
        <span>Tanggal kejadian <b class="req">*</b></span>
        <input type="date" name="issued_date" value="<?= e($form['issued_date']) ?>">
        <span class="hint">Hari retur / kendala ini terjadi.</span>
      </label>

      <label class="field">
        <span>Marketplace pesanan <span class="opt">(opsional)</span></span>
        <select name="marketplace">
          <option value="">— bukan dari marketplace / tidak tahu —</option>
          <?php foreach (ret_markets() as $code => $label): ?>
            <option value="<?= e($code) ?>" <?= $form['marketplace'] === $code ? 'selected' : '' ?>><?= e($label) ?></option>
          <?php endforeach; ?>
        </select>
      </label>

      <label class="field">
        <span>No. pesanan</span>
        <input type="text" name="order_no" value="<?= e($form['order_no']) ?>" autocomplete="off"
               placeholder="isi bila ada (mis. pesanan chat langsung)">
      </label>

      <label class="field">
        <span>No. resi <span class="opt">(opsional)</span></span>
        <span class="with-btn">
          <input type="text" id="fResi" name="resi" value="" autocomplete="off" spellcheck="false"
                 placeholder="Kosongkan — nomor otomatis MANUAL-…">
          <button type="button" class="btn btn-sm" data-cam-open data-cam-target="#fResi" data-cam-next="last-sku"
                  title="Scan dengan kamera HP">Scan</button>
        </span>
        <span class="row-info" id="resiWarn" data-resi-warn data-ret-id="0"></span>
      </label>

      <label class="field">
        <span>Nama pihak terkait <b class="req">*</b></span>
        <input type="text" name="buyer" value="<?= e($form['buyer']) ?>" autocomplete="off"
               placeholder="Nama pembeli / kurir / staf yang terlibat">
        <span class="hint">Dipakai juga di laporan “paling sering retur”.</span>
      </label>

      <label class="field">
        <span>Kurir <span class="opt">(opsional)</span></span>
        <input type="text" name="courier" value="<?= e($form['courier']) ?>" list="courierList" autocomplete="off"
               placeholder="isi bila terkait pengiriman">
        <datalist id="courierList">
          <?php foreach (ret_couriers() as $c): ?><option value="<?= e($c) ?>"></option><?php endforeach; ?>
        </datalist>
      </label>

      <label class="field">
        <span>Tanggal barang diterima gudang <span class="opt">(opsional)</span></span>
        <input type="date" name="received_date_raw" value="<?= e($form['received_date']) ?>">
        <span class="hint">Isi bila barangnya sudah langsung diterima hari itu. Stok hanya bertambah
          setelah tanggal ini ada.</span>
      </label>

      <label class="field field-wide">
        <span>Catatan <span class="opt">(opsional)</span></span>
        <textarea name="note" rows="2" placeholder="Detail kendala, kesepakatan dengan pembeli, dll"><?= e($form['note']) ?></textarea>
      </label>
    </div>
  </section>

  <section class="card">
    <div class="card-head">
      <h2>Barang yang diretur / ditukar</h2>
      <span class="muted small">Kolom artikel = SKU di aplikasi Inventory</span>
    </div>
    <p class="explain">
      Untuk <strong>tukar size</strong>: tulis <em>artikel lama</em> di baris ini. Artikel penggantinya
      diisi kemudian di halaman rincian, dan dikirim lewat tombol <em>Kirim barang pengganti</em>.
      Untuk retur manual lain, barang yang masuk kembali gudang ditulis di sini.
    </p>

    <div class="table-wrap">
      <table class="table item-table<?= $form['received_date'] !== '' ? '' : ' stock-hidden' ?>" data-items>
        <thead>
          <tr>
            <th>Artikel / SKU</th>
            <th class="qty-col">Jumlah</th>
            <th class="cond-col">Kondisi barang</th>
            <th class="stock-col">Ke stok</th>
            <th class="act-col">Baris</th>
          </tr>
        </thead>
        <tbody id="itemBody">
          <?php foreach ($rows as $i => $r): ?>
            <tr class="item-row">
              <td class="sku-cell">
                <input type="text" name="item_sku[<?= (int)$i ?>]" class="sku-input sku-input-field"
                       value="<?= e((string)$r['sku']) ?>" autocomplete="off" spellcheck="false"
                       placeholder="Scan / ketik artikel">
                <span class="row-info" data-row-info></span>
              </td>
              <td class="qty-cell">
                <span class="qty-group">
                  <button type="button" class="qty-btn" data-qty-step="-1" tabindex="-1" aria-label="Kurangi jumlah">−</button>
                  <input type="text" inputmode="decimal" class="qty-input" name="item_qty[<?= (int)$i ?>]"
                         value="<?= e((string)$r['qty']) ?>" placeholder="1">
                  <button type="button" class="qty-btn" data-qty-step="1" tabindex="-1" aria-label="Tambah jumlah">+</button>
                </span>
              </td>
              <td class="cond-cell">
                <select name="item_cond[<?= (int)$i ?>]" class="cond-select">
                  <?php foreach (ret_conditions() as $code => $label): ?>
                    <option value="<?= e($code) ?>" <?= (string)$r['cond'] === $code ? 'selected' : '' ?>><?= e($label) ?></option>
                  <?php endforeach; ?>
                </select>
              </td>
              <td class="stock-cell">
                <input type="hidden" name="item_stock[<?= (int)$i ?>]" value="0">
                <label class="chk">
                  <input type="checkbox" name="item_stock[<?= (int)$i ?>]" value="1" class="stock-check"
                         <?= !empty($r['stock']) ? 'checked' : '' ?>>
                  <span>Masuk stok</span>
                </label>
              </td>
              <td class="act-cell">
                <button type="button" class="btn btn-sm btn-ghost" data-row-remove title="Hapus baris ini">Hapus</button>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="item-actions">
      <button type="button" class="btn" id="addRow">+ Tambah baris</button>
      <button type="button" class="btn" data-cam-open data-cam-target="last-sku" data-cam-add-row="1">Scan artikel</button>
    </div>
  </section>

  <div class="form-foot">
    <button class="btn btn-primary btn-lg" type="submit" data-submit-confirm>Simpan retur manual</button>
    <span class="muted small" data-save-hint-muted hidden>
      Tersimpan sebagai <strong>belum diterima</strong> — stok Inventory belum berubah.
    </span>
    <span class="muted small" data-save-hint-stock>
      Tanggal barang diterima terisi: artikel bertanda <em>masuk stok</em> langsung ditambahkan ke Inventory.
    </span>
  </div>
</form>

<?php ret_page_end(['scripts' => '<script src="assets/format.js"></script>'
    . '<script src="assets/app.js"></script><script src="assets/scan.js"></script>']); ?>
