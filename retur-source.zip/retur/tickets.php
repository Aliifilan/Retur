<?php
declare(strict_types=1);

/* ============================================================
 * Tiket Kendala Marketplace — daftar kendala yang diurus ke Shopee /
 * TikTok Shop / Lazada: dana ditahan, klaim hilang/rusak, retur macet,
 * refund belum turun, denda, iklan, akses akun, dan lainnya.
 *
 * Tiap tiket punya riwayat (siapa, kapan, status apa, catatan apa) supaya
 * tahu sudah dijawab marketplace atau belum.
 * ============================================================ */

require_once __DIR__ . '/includes/init.php';
ret_require_login();

$filter = [
    'q' => (string)get('q', ''),
    'marketplace' => (string)get('marketplace', ''),
    'status' => (string)get('status', ''),
    'category' => (string)get('category', ''),
    'from' => ret_date_input((string)get('from', '')) ?: '',
    'to' => ret_date_input((string)get('to', '')) ?: '',
];
if (!isset(ret_markets()[$filter['marketplace']])) $filter['marketplace'] = '';
if (!isset(ret_ticket_categories()[$filter['category']])) $filter['category'] = '';
if ($filter['status'] !== '' && $filter['status'] !== 'open' && !isset(ret_ticket_statuses()[$filter['status']])) {
    $filter['status'] = '';
}

$data = ret_ticket_list($filter, 25);
$stats = ret_ticket_stats();
$activeFilter = $filter['q'] !== '' || $filter['marketplace'] !== '' || $filter['status'] !== ''
    || $filter['category'] !== '' || $filter['from'] !== '' || $filter['to'] !== '';

$actions = ret_can('create') ? '<a class="btn btn-primary" href="ticket_form.php">+ Tiket baru</a>' : '';

ret_page_start('Tiket Kendala Marketplace', 'tickets.php', [
    'label'   => 'tickets',
    'sub'     => 'Kendala yang diurus ke Shopee / TikTok Shop / Lazada beserta riwayatnya — ' . fmt_num($data['total']) . ' tiket sesuai filter.',
    'actions' => $actions,
]);
?>

<section class="tiles">
  <div class="tile">
    <span class="tile-label">Tiket terbuka</span>
    <strong class="tile-value <?= $stats['open'] > 0 ? 'is-warn' : '' ?>"><?= fmt_num($stats['open']) ?></strong>
    <span class="tile-sub">belum selesai diurus</span>
  </div>
  <div class="tile">
    <span class="tile-label">Menunggu marketplace</span>
    <strong class="tile-value"><?= fmt_num($stats['waiting']) ?></strong>
    <span class="tile-sub">balasan terakhir dari kita</span>
  </div>
  <div class="tile">
    <span class="tile-label">Terlama menunggu</span>
    <strong class="tile-value <?= $stats['oldest_days'] >= 7 ? 'is-danger' : ($stats['oldest_days'] >= 3 ? 'is-warn' : '') ?>">
      <?= $stats['oldest_date'] !== '' ? e(ret_age_text($stats['oldest_days'])) : '—' ?>
    </strong>
    <span class="tile-sub"><?= $stats['oldest_date'] !== '' ? 'tiket dibuat ' . e(fmt_date($stats['oldest_date'])) : 'belum ada tiket terbuka' ?></span>
  </div>
  <div class="tile">
    <span class="tile-label">Selesai</span>
    <strong class="tile-value"><?= fmt_num($stats['closed']) ?></strong>
    <span class="tile-sub">dana / klaim pulih <?= e(fmt_money($stats['recovered'])) ?></span>
  </div>
</section>

<form class="card filter-card" method="get" action="tickets.php">
  <label class="field">
    <span>Cari</span>
    <input type="text" name="q" value="<?= e($filter['q']) ?>" placeholder="No. tiket / pesanan / resi / judul" autocomplete="off">
  </label>
  <label class="field">
    <span>Marketplace</span>
    <select name="marketplace">
      <option value="">Semua</option>
      <?php foreach (ret_markets() as $code => $label): ?>
        <option value="<?= e($code) ?>" <?= $filter['marketplace'] === $code ? 'selected' : '' ?>><?= e($label) ?></option>
      <?php endforeach; ?>
    </select>
  </label>
  <label class="field">
    <span>Status</span>
    <select name="status">
      <option value="">Semua</option>
      <option value="open" <?= $filter['status'] === 'open' ? 'selected' : '' ?>>Semua yang terbuka</option>
      <?php foreach (ret_ticket_statuses() as $code => [$label]): ?>
        <option value="<?= e($code) ?>" <?= $filter['status'] === $code ? 'selected' : '' ?>><?= e($label) ?></option>
      <?php endforeach; ?>
    </select>
  </label>
  <label class="field">
    <span>Jenis kendala</span>
    <select name="category">
      <option value="">Semua</option>
      <?php foreach (ret_ticket_categories() as $code => $label): ?>
        <option value="<?= e($code) ?>" <?= $filter['category'] === $code ? 'selected' : '' ?>><?= e($label) ?></option>
      <?php endforeach; ?>
    </select>
  </label>
  <label class="field">
    <span>Dibuat dari</span>
    <input type="date" name="from" value="<?= e($filter['from']) ?>">
  </label>
  <div class="filter-actions">
    <button class="btn btn-primary" type="submit">Terapkan</button>
    <?php if ($activeFilter): ?>
      <a class="btn" href="tickets.php">Bersihkan</a>
    <?php endif; ?>
  </div>
</form>

<section class="card">
  <?php if (!$data['rows']): ?>
    <p class="muted">
      <?= $activeFilter ? 'Tidak ada tiket yang cocok dengan filter ini.' : 'Belum ada tiket kendala yang tercatat.' ?>
      <?php if (ret_can('create')): ?> Mulai dengan <a href="ticket_form.php">membuat tiket baru</a>.<?php endif; ?>
    </p>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table table-rows">
        <thead>
          <tr>
            <th>Terbuka</th>
            <th>Marketplace</th>
            <th>No. tiket</th>
            <th>Jenis</th>
            <th>Judul</th>
            <th>Status</th>
            <th>Tenggat</th>
            <th class="act-col">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($data['rows'] as $t): ?>
            <?php
            $id = (int)$t['id'];
            $due = (string)$t['due_date'];
            $terlambat = $due !== '' && (string)$t['status'] !== 'closed' && (string)$t['status'] !== 'resolved'
                && ret_age_days($due) > 0;
            ?>
            <tr>
              <td><?= e(fmt_date((string)$t['opened_date'])) ?></td>
              <td><?= ret_market_badge((string)$t['marketplace']) ?></td>
              <td>
                <a class="sku" href="ticket_view.php?id=<?= $id ?>"><?= e((string)$t['ticket_no'] !== '' ? (string)$t['ticket_no'] : ('#' . $id)) ?></a>
                <?php if ((string)$t['order_no'] !== ''): ?>
                  <div class="muted tiny"><?= e((string)$t['order_no']) ?></div>
                <?php endif; ?>
              </td>
              <td><?= ret_ticket_category_badge((string)$t['category']) ?></td>
              <td><?= e((string)$t['subject']) ?></td>
              <td><?= ret_ticket_status_badge((string)$t['status']) ?></td>
              <td>
                <?php if ($due === ''): ?>
                  <span class="muted">—</span>
                <?php else: ?>
                  <?= e(fmt_date($due)) ?>
                  <?php if ($terlambat): ?><div class="tiny danger-text">lewati tenggat</div><?php endif; ?>
                <?php endif; ?>
              </td>
              <td class="act-cell"><a class="btn btn-sm" href="ticket_view.php?id=<?= $id ?>">Buka</a></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?= render_pager($data['pager']) ?>
  <?php endif; ?>
</section>

<?php ret_page_end(); ?>
