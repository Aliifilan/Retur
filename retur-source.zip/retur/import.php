<?php
declare(strict_types=1);

/* ============================================================
 * Halaman import catatan retur dari Excel / CSV.
 *
 * Pola mengikuti aplikasi Inventory:
 *   - validasi berkas gagal → flash pesan + kembali ke halaman ini (tidak ada data yang hilang
 *     selain berkas yang memang harus dipilih ulang),
 *   - mode uji coba dijalankan di dalam SATU transaksi lokal lalu dibatalkan, dan
 *     stok Inventory tidak disentuh sama sekali pada mode itu,
 *   - laporan hasil (dibuat/dilewati/galat) ditampilkan apa adanya.
 * ============================================================ */

require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/retur_import.php';
ret_require('create', 'memasukkan data dari berkas');

$report = null;
$dry = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $dry = post('dry_run') === '1';

    if (!isset($_FILES['file']) || !is_uploaded_file($_FILES['file']['tmp_name']) || (int)$_FILES['file']['error'] !== 0) {
        flash('Berkas belum dipilih atau gagal diunggah. Pilih berkas .xlsx/.csv lalu coba lagi.', 'error');
        redirect('export.php#import');
    }

    try {
        [$kind, $parsed] = ret_import_read_upload($_FILES['file']);
    } catch (Throwable $e) {
        flash(e($e->getMessage()), 'error');
        redirect('export.php#import');
    }

    if (!$parsed['rows']) {
        flash('Berkas tidak berisi data yang bisa dibaca. Pastikan baris pertama berisi judul kolom '
            . '(minimal: ' . e(implode(', ', ret_import_required())) . ') dan datanya ada di baris berikutnya.', 'error');
        redirect('export.php#import');
    }

    $u = current_user();
    $uid = $u ? (int)$u['id'] : null;

    if ($dry) {
        /* Uji coba: seluruh proses di dalam satu transaksi lokal, lalu dibatalkan.
           Pengiriman stok ke Inventory DILEWATI (database Inventory bukan bagian transaksi ini,
           jadi rollback tidak bisa membatalkannya). */
        $hold = null;
        try {
            ret_tx(function () use ($parsed, $uid, &$hold) {
                $hold = ret_import_run($parsed['rows'], $uid, false);
                throw new DryRunSignal();
            });
        } catch (DryRunSignal $sig) {
            /* semua perubahan lokal sudah dibatalkan; laporannya tetap ditampilkan */
        } catch (Throwable $e) {
            flash('Import gagal: ' . e($e->getMessage()), 'error');
            redirect('export.php#import');
        }
        $report = $hold;
    } else {
        $report = ret_tx(function () use ($parsed, $uid) {
            return ret_import_run($parsed['rows'], $uid, true);
        });
        if (empty($report['errors']) || $report['created'] > 0) {
            log_activity('import', 'Import retur: ' . $report['created'] . ' catatan dibuat, '
                . $report['skipped'] . ' dilewati, ' . count($report['errors']) . ' galat', 'import', 'retur');
        }
        flash('Import selesai: <strong>' . $report['created'] . '</strong> catatan retur dibuat'
            . ($report['received'] > 0 ? ', <strong>' . $report['received'] . '</strong> di antaranya stoknya dikirim ke Inventory' : '')
            . '. ' . $report['skipped'] . ' resi dilewati karena sudah ada.', $report['errors'] ? 'warn' : 'success');
    }

    $report['dry'] = $dry;
    $report['kind'] = $kind;
    $report['rows'] = count($parsed['rows']);
    $report['columns'] = $parsed['header'];
}

$actions = '<a class="btn" href="returns.php">Lihat daftar retur</a>';

ret_page_start($dry ? 'Hasil Uji Coba Import' : 'Hasil Import', '', [
    'label'   => 'data',
    'sub'     => $dry
        ? 'MODE UJI COBA — tidak ada data yang disimpan dan stok Inventory tidak disentuh.'
        : 'Berkas sudah diproses. Periksa hasilnya di bawah.',
    'actions' => $actions,
]);
?>

<?php if ($dry): ?>
  <?= ret_notice('Mode <strong>uji coba</strong>: seluruh perubahan sudah dibatalkan dan stok Inventory '
      . 'tidak disentuh. Hilangkan centang “Mode uji coba” di halaman Import untuk benar-benar menyimpan.', 'info') ?>
<?php endif; ?>

<section class="card">
  <div class="card-head"><h2>Ringkasan proses</h2></div>
  <dl class="kv">
    <dt>Baris terbaca dari berkas</dt><dd><?= fmt_num((int)$report['rows']) ?></dd>
    <dt>Catatan retur (grup per resi)</dt><dd><?= fmt_num((int)$report['groups']) ?></dd>
    <dt>Dibuat</dt><dd><strong class="<?= (int)$report['created'] > 0 ? 'ok-text' : '' ?>"><?= fmt_num((int)$report['created']) ?></strong></dd>
    <dt>Dilewati (resi sudah ada)</dt><dd><?= fmt_num((int)$report['skipped']) ?></dd>
    <dt>Baris bermasalah</dt><dd class="<?= $report['errors'] ? 'danger-text' : '' ?>"><?= fmt_num(count($report['errors'])) ?></dd>
    <dt>Catatan yang mengirim stok ke Inventory</dt>
    <dd><?= $dry
        ? '<span class="muted">mode uji coba — tidak ada stok yang dikirim (' . fmt_num((int)$report['received']) . ' catatan akan mengirim stok)</span>'
        : fmt_num((int)$report['received']) . ' catatan' ?></dd>
    <dt>Kolom terbaca</dt>
    <dd><?= $report['columns'] ? '<code>' . e(implode('</code>, <code>', (array)$report['columns'])) . '</code>' : '<span class="muted">—</span>' ?></dd>
  </dl>
</section>

<?php if ($report['errors']): ?>
  <section class="card">
    <div class="card-head"><h2>Baris yang dilewati beserta alasannya</h2></div>
    <ul class="msg-list">
      <?php foreach (array_slice((array)$report['errors'], 0, 60) as $err): ?>
        <li><?= e((string)$err) ?></li>
      <?php endforeach; ?>
    </ul>
    <?php if (count($report['errors']) > 60): ?>
      <p class="muted small">…dan <?= fmt_num(count($report['errors']) - 60) ?> pesan lainnya.</p>
    <?php endif; ?>
  </section>
<?php endif; ?>

<?php if ($report['notes']): ?>
  <section class="card">
    <div class="card-head"><h2>Catatan proses</h2></div>
    <ul class="msg-list">
      <?php foreach (array_slice((array)$report['notes'], 0, 60) as $n): ?>
        <li><?= e((string)$n) ?></li>
      <?php endforeach; ?>
    </ul>
  </section>
<?php endif; ?>

<section class="card">
  <div class="card-head"><h2>Lanjutkan</h2></div>
  <div class="tag-list">
    <a class="btn btn-primary" href="export.php#import">Import berkas lain</a>
    <a class="btn" href="returns.php?status=pending">Lihat retur yang belum diterima</a>
    <a class="btn" href="index.php">Kembali ke Dashboard</a>
  </div>
</section>

<?php ret_page_end(); ?>
