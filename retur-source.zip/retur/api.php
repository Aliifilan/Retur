<?php
declare(strict_types=1);

/* ============================================================
 * API kecil (JSON) untuk membantu pengisian form:
 *   ?op=sku&sku=JK-001    → data artikel dari aplikasi Inventory (ada/tidak)
 *   ?op=resi&resi=SPX123  → cek apakah nomor resi sudah pernah dicatat
 *
 * Hanya membaca; tidak ada tindakan yang mengubah data di sini.
 * ============================================================ */

require_once __DIR__ . '/includes/init.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if (!current_user()) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'error' => 'Belum masuk.'], JSON_UNESCAPED_UNICODE);
    exit;
}

$op = (string)get('op', '');
$out = ['ok' => true];

switch ($op) {
    case 'sku':
        $sku = ret_norm_sku((string)get('sku', ''));
        if ($sku === '') { echo json_encode(['ok' => false, 'error' => 'SKU kosong.'], JSON_UNESCAPED_UNICODE); exit; }
        $found = ret_prod_lookup([$sku]);
        $p = $found[$sku] ?? null;
        if (!$p) {
            $out['found'] = false;
            $out['sku'] = $sku;
            $out['message'] = 'SKU ini belum terdaftar di aplikasi Inventory — tetap bisa dicatat, '
                . 'tetapi stoknya tidak bisa ditambahkan.';
        } else {
            $out['found'] = true;
            $out['sku'] = (string)$p['sku'];
            $out['stock_qty'] = (float)$p['stock_qty'];
            $out['stock_text'] = fmt_qty($p['stock_qty']);
            $out['unit'] = (string)$p['unit'];
            $out['size'] = (string)$p['size'];
            $out['brand'] = (string)$p['brand'];
            $out['active'] = (int)$p['active'] === 1;
            $out['sell_price'] = (float)$p['sell_price'];
            $out['price_text'] = fmt_money((float)$p['sell_price']);
        }
        break;

    case 'resi':
        $resi = ret_norm_resi((string)get('resi', ''));
        $exclude = (int)get('id', 0);
        $rows = $resi === '' ? [] : ret_duplicate_resi($resi, $exclude);
        $out['found'] = (bool)$rows;
        $out['items'] = array_map(static fn($r) => [
            'id' => (int)$r['id'],
            'resi' => (string)$r['resi'],
            'marketplace' => ret_market_label((string)$r['marketplace']),
            'issued_date' => fmt_date((string)$r['issued_date']),
            'status' => (string)$r['status'] === 'received' ? 'sudah diterima' : 'belum diterima',
        ], $rows);
        break;

    default:
        http_response_code(400);
        $out = ['ok' => false, 'error' => 'Permintaan tidak dikenal.'];
}

echo json_encode($out, JSON_UNESCAPED_UNICODE);
